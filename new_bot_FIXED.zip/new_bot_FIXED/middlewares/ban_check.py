"""
Middlewares for the bot
"""
from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware, Bot
from aiogram.types import Message, CallbackQuery
from loguru import logger

from services.database import get_db, UserService


class BanCheckMiddleware(BaseMiddleware):
    """Check if user is banned + feature limits"""

    async def __call__(
        self,
        handler: Callable[[Message | CallbackQuery, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any]
    ) -> Any:
        user_id = event.from_user.id

        async with get_db() as session:
            user = await UserService.get_by_telegram_id(session, user_id)

            if user and user.is_banned:
                ban_text = f"🚫 Вы заблокированы!\n\nПричина: {user.ban_reason or 'Не указана'}"
                if isinstance(event, Message):
                    await event.answer(ban_text)
                else:
                    await event.answer(ban_text, show_alert=True)
                return

            # Feature limits
            if user and user.inventory:
                limits = user.inventory.get("_limits", {})
                if limits and isinstance(event, Message) and event.text:
                    text = event.text.lower().strip()
                    limit_map = {
                        "work":     ["раб", "работать", "работа"],
                        "mine":     ["майн", "майнинг", "шахта"],
                        "casino":   ["казино"],
                        "slots":    ["слоты"],
                        "business": ["бизнес", "бизнесы", "купить", "улучшить", "продать"],
                        "cards":    ["карточки", "карты"],
                        "daily":    ["дейли", "ежедневный"],
                    }
                    for feat, triggers in limit_map.items():
                        if feat in limits and any(text.startswith(t) for t in triggers):
                            await event.answer(
                                f"🔒 Функция <b>{feat}</b> вам ограничена.",
                                parse_mode="HTML"
                            )
                            return

        return await handler(event, data)


class LoggingMiddleware(BaseMiddleware):
    """Log user actions to console and optional Telegram log chat"""

    async def __call__(
        self,
        handler: Callable[[Message | CallbackQuery, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any]
    ) -> Any:
        user_id = event.from_user.id
        username = event.from_user.username or "no_username"
        first_name = event.from_user.first_name or ""

        if isinstance(event, Message):
            text = event.text or event.caption or "Media"
            log_line = f"Message from {username} ({user_id}): {text}"
            tg_log = f"💬 <code>@{username}</code> ({user_id}) <b>{first_name}</b>:\n{text[:200]}"
        elif isinstance(event, CallbackQuery):
            log_line = f"Callback from {username} ({user_id}): {event.data}"
            tg_log = f"🔘 <code>@{username}</code> ({user_id}): <code>{event.data[:100]}</code>"
        else:
            log_line = None
            tg_log = None

        if log_line:
            logger.info(log_line)

        if tg_log:
            try:
                from config import settings
                if settings.LOG_CHAT_ID:
                    bot = data.get("bot") or getattr(event, "bot", None)
                    if bot:
                        await bot.send_message(
                            settings.LOG_CHAT_ID,
                            tg_log,
                            parse_mode="HTML"
                        )
            except Exception:
                pass

        return await handler(event, data)


class LogChatMiddleware(BaseMiddleware):
    """Send user messages/actions to a designated Telegram log chat"""

    def __init__(self, bot: Bot, log_chat_id: int | str):
        self.bot = bot
        self.log_chat_id = log_chat_id
        super().__init__()

    async def __call__(
        self,
        handler: Callable[[Message | CallbackQuery, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any]
    ) -> Any:
        try:
            user_id = event.from_user.id
            username = event.from_user.username or "no_username"
            first_name = event.from_user.first_name or ""

            if isinstance(event, Message):
                text = event.text or event.caption or "Media"
                tg_log = (
                    f"💬 <code>@{username}</code> ({user_id}) <b>{first_name}</b>:\n"
                    f"{text[:200]}"
                )
            elif isinstance(event, CallbackQuery):
                tg_log = (
                    f"🔘 <code>@{username}</code> ({user_id}) <b>{first_name}</b>: "
                    f"<code>{event.data[:100]}</code>"
                )
            else:
                tg_log = None

            if tg_log:
                await self.bot.send_message(
                    self.log_chat_id,
                    tg_log,
                    parse_mode="HTML"
                )
        except Exception:
            pass

        return await handler(event, data)
