#!/bin/bash

echo "========================================"
echo "Starting Telegram Gaming Bot"
echo "========================================"
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "ERROR: .env file not found!"
    echo "Please copy .env.example to .env and configure it"
    exit 1
fi

# Start bot
echo "Starting bot..."
python3 main.py
