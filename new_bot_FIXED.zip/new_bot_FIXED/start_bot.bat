@echo off
echo ========================================
echo Starting Telegram Gaming Bot
echo ========================================
echo.

REM Check if .env exists
if not exist .env (
    echo ERROR: .env file not found!
    echo Please copy .env.example to .env and configure it
    pause
    exit /b 1
)

REM Start bot
echo Starting bot...
python main.py

pause
