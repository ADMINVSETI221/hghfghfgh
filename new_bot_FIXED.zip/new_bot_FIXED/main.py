"""
Main bot entry point
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from loguru import logger
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from config import settings, LOGS_DIR
from services.database import init_db, close_db
from middlewares.ban_check import BanCheckMiddleware, LoggingMiddleware, LogChatMiddleware
from handlers import basic, games, business, shop, admin, giveaway, cards, crypto, mining
from handlers.admin_bot import run_admin_bot

# Configure logging
logger.remove()
logger.add(
    sys.stdout,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>",
    level="INFO"
)
logger.add(
    LOGS_DIR / "bot_{time:YYYY-MM-DD}.log",
    rotation="00:00",
    retention="30 days",
    level="DEBUG"
)


async def on_startup():
    logger.info("Starting bot...")
    await init_db()
    logger.success("Database initialized")


async def on_shutdown():
    logger.info("Shutting down bot...")
    await close_db()
    logger.success("Bot stopped")


async def main():
    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    dp = Dispatcher(storage=MemoryStorage())

    dp.message.middleware(LoggingMiddleware())
    dp.callback_query.middleware(LoggingMiddleware())
    dp.message.middleware(BanCheckMiddleware())
    dp.callback_query.middleware(BanCheckMiddleware())

    # Log chat middleware (если задан LOG_CHAT_ID в .env)
    if settings.LOG_CHAT_ID:
        log_bot = Bot(token=settings.BOT_TOKEN)
        dp.message.middleware(LogChatMiddleware(log_bot, settings.LOG_CHAT_ID))
        logger.info(f"Лог-чат включён: {settings.LOG_CHAT_ID}")

    dp.include_router(basic.router)
    dp.include_router(games.router)
    dp.include_router(business.router)
    dp.include_router(crypto.router)
    dp.include_router(shop.router)
    dp.include_router(giveaway.router)
    dp.include_router(cards.router)
    dp.include_router(admin.router)
    dp.include_router(mining.router)

    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    logger.info("Bot started successfully!")
    logger.info(f"Owner ID: {settings.OWNER_ID}")
    logger.info(f"Admin IDs: {settings.all_admin_ids}")
    if settings.LOG_CHAT_ID:
        logger.info(f"Log chat: {settings.LOG_CHAT_ID}")
    if settings.ADMIN_BOT_TOKEN:
        logger.info("Admin bot token found — starting in parallel")

    tasks = [dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())]
    if settings.ADMIN_BOT_TOKEN:
        tasks.append(run_admin_bot())

    try:
        await asyncio.gather(*tasks)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.exception(f"Fatal error: {e}")
        sys.exit(1)
