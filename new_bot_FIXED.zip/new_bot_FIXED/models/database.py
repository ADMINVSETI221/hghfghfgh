"""
Database models using SQLAlchemy 2.0+ async style
"""
from datetime import datetime, timedelta
from typing import Optional
from sqlalchemy import String, Integer, Float, Boolean, DateTime, JSON, Text, ForeignKey, Numeric
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.ext.asyncio import AsyncAttrs

class Base(AsyncAttrs, DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    balance: Mapped[float] = mapped_column(Numeric(precision=20, scale=2, asdecimal=False), default=1000.0)
    experience: Mapped[int] = mapped_column(Integer, default=0)
    level: Mapped[int] = mapped_column(Integer, default=1)

    last_work: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_mine: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_daily: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_psychiatrist: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_casino: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_slots: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_lucky_block: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    vip_until: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    businesses: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    inventory: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    statistics: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    crypto_wallet: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    mining_farms: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)

    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    ban_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    transactions: Mapped[list["Transaction"]] = relationship(back_populates="user", cascade="all, delete-orphan")

    def is_cooldown_active(self, cooldown_type: str, cooldown_seconds: int) -> bool:
        if self.vip_until and datetime.utcnow() < self.vip_until:
            return False
        last_time = getattr(self, f"last_{cooldown_type}", None)
        if last_time is None:
            return False
        return datetime.utcnow() < last_time + timedelta(seconds=cooldown_seconds)

    def get_cooldown_remaining(self, cooldown_type: str, cooldown_seconds: int) -> int:
        last_time = getattr(self, f"last_{cooldown_type}", None)
        if last_time is None:
            return 0
        remaining = (last_time + timedelta(seconds=cooldown_seconds) - datetime.utcnow()).total_seconds()
        return max(0, int(remaining))


class Transaction(Base):
    __tablename__ = "transactions"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    transaction_type: Mapped[str] = mapped_column(String(50))
    amount: Mapped[float] = mapped_column(Numeric(precision=20, scale=2, asdecimal=False))
    balance_before: Mapped[float] = mapped_column(Numeric(precision=20, scale=2, asdecimal=False))
    balance_after: Mapped[float] = mapped_column(Numeric(precision=20, scale=2, asdecimal=False))
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    user: Mapped["User"] = relationship(back_populates="transactions")


class GlobalEvent(Base):
    __tablename__ = "global_events"

    id: Mapped[int] = mapped_column(primary_key=True)
    event_type: Mapped[str] = mapped_column(String(50))
    multiplier: Mapped[float] = mapped_column(Float, default=1.0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    starts_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    ends_at: Mapped[datetime] = mapped_column(DateTime)
    created_by: Mapped[int] = mapped_column(Integer)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


class Giveaway(Base):
    __tablename__ = "giveaways"

    id: Mapped[int] = mapped_column(primary_key=True)
    total_amount: Mapped[float] = mapped_column(Float)
    amount_per_user: Mapped[float] = mapped_column(Float)
    max_participants: Mapped[int] = mapped_column(Integer)
    claimed_users: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    remaining_amount: Mapped[float] = mapped_column(Float)
    message_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    chat_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    created_by: Mapped[int] = mapped_column(Integer)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class CryptoPrice(Base):
    """Live crypto prices stored in DB"""
    __tablename__ = "crypto_prices"

    symbol: Mapped[str] = mapped_column(String(20), primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    emoji: Mapped[str] = mapped_column(String(10), default="🪙")
    price: Mapped[float] = mapped_column(Float)
    volatility: Mapped[float] = mapped_column(Float, default=0.05)
    is_tradeable: Mapped[bool] = mapped_column(Boolean, default=True)
    admin_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    price_history: Mapped[Optional[dict]] = mapped_column(JSON, default=dict)
    change_24h: Mapped[float] = mapped_column(Float, default=0.0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


# ── Default crypto data ────────────────────────────────────────────────────────

CRYPTO_DEFAULTS = {
    "BTC":   {"name": "Bitcoin",    "emoji": "₿",    "price": 95000.0,      "volatility": 0.04, "admin_enabled": True},
    "ETH":   {"name": "Ethereum",   "emoji": "Ξ",    "price": 3500.0,       "volatility": 0.05, "admin_enabled": True},
    "BNB":   {"name": "BNB",        "emoji": "🟡",   "price": 680.0,        "volatility": 0.06, "admin_enabled": True},
    "SOL":   {"name": "Solana",     "emoji": "◎",    "price": 185.0,        "volatility": 0.07, "admin_enabled": True},
    "XRP":   {"name": "XRP",        "emoji": "✕",    "price": 2.5,          "volatility": 0.07, "admin_enabled": True},
    "ADA":   {"name": "Cardano",    "emoji": "₳",    "price": 0.95,         "volatility": 0.08, "admin_enabled": True},
    "DOGE":  {"name": "Dogecoin",   "emoji": "🐕",   "price": 0.38,         "volatility": 0.10, "admin_enabled": True},
    "SHIB":  {"name": "Shiba Inu",  "emoji": "🐕‍🦺", "price": 0.0000265,   "volatility": 0.14, "admin_enabled": True},
    "TON":   {"name": "Toncoin",    "emoji": "💎",   "price": 5.5,          "volatility": 0.07, "admin_enabled": True},
    "NOT":   {"name": "Notcoin",    "emoji": "🔔",   "price": 0.012,        "volatility": 0.12, "admin_enabled": True},
    "PZDTC": {"name": "PZDTC-Coin", "emoji": "💩",   "price": 0.0000000001, "volatility": 0.30, "admin_enabled": False},
}

# ── Mining farms ───────────────────────────────────────────────────────────────

MINING_FARMS = {
    "cpu_rig": {
        "name": "💻 CPU Ферма",
        "description": "Простейшая ферма. Майнит PZDTC-Coin.",
        "crypto": "PZDTC",
        "buy_price": 10_000,
        "base_hourly_rate": 50_000_000.0,
        "upgrade_rate_bonus": 0.50,
        "upgrade_cost_base": 500_000.0,
        "upgrade_cost_exp": 1.8,
    },
    "gpu_doge": {
        "name": "🖥 GPU-Ферма DOGE",
        "description": "GPU-ферма для майнинга Dogecoin.",
        "crypto": "DOGE",
        "buy_price": 50_000,
        "base_hourly_rate": 2.0,
        "upgrade_rate_bonus": 0.40,
        "upgrade_cost_base": 5.0,
        "upgrade_cost_exp": 1.9,
    },
    "asic_btc": {
        "name": "⚡ ASIC-BTC",
        "description": "Мощный ASIC для Bitcoin.",
        "crypto": "BTC",
        "buy_price": 500_000,
        "base_hourly_rate": 0.000015,
        "upgrade_rate_bonus": 0.35,
        "upgrade_cost_base": 0.0001,
        "upgrade_cost_exp": 2.0,
    },
    "asic_eth": {
        "name": "⚡ ASIC-ETH",
        "description": "ASIC для Ethereum.",
        "crypto": "ETH",
        "buy_price": 200_000,
        "base_hourly_rate": 0.0008,
        "upgrade_rate_bonus": 0.40,
        "upgrade_cost_base": 0.005,
        "upgrade_cost_exp": 1.95,
    },
    "sol_farm": {
        "name": "☀️ SOL-Ферма",
        "description": "Специализирована под Solana.",
        "crypto": "SOL",
        "buy_price": 150_000,
        "base_hourly_rate": 0.025,
        "upgrade_rate_bonus": 0.45,
        "upgrade_cost_base": 0.1,
        "upgrade_cost_exp": 1.9,
    },
    "bnb_node": {
        "name": "🟡 BNB-Нода",
        "description": "Валидатор для BNB.",
        "crypto": "BNB",
        "buy_price": 300_000,
        "base_hourly_rate": 0.004,
        "upgrade_rate_bonus": 0.40,
        "upgrade_cost_base": 0.02,
        "upgrade_cost_exp": 2.0,
    },
    "shib_farm": {
        "name": "🐕 SHIB-Ферма",
        "description": "GPU-ферма для Shiba Inu.",
        "crypto": "SHIB",
        "buy_price": 25_000,
        "base_hourly_rate": 500_000.0,
        "upgrade_rate_bonus": 0.50,
        "upgrade_cost_base": 2_000_000.0,
        "upgrade_cost_exp": 1.85,
    },
    "data_center": {
        "name": "🏭 Дата-Центр",
        "description": "Мощный дата-центр. Майнит TON.",
        "crypto": "TON",
        "buy_price": 1_000_000,
        "base_hourly_rate": 0.5,
        "upgrade_rate_bonus": 0.35,
        "upgrade_cost_base": 2.0,
        "upgrade_cost_exp": 2.1,
    },
}

# ── Businesses ─────────────────────────────────────────────────────────────────

BUSINESSES = {
    # base_cost снижена ~35%, base_income снижен ~40%, upgrade_multiplier 1.3 (дешевле прокачка)
    "lemonade_stand":  {"name": "🍋 Лимонадный стенд",   "base_cost": 600,         "base_income": 30,        "cooldown_minutes": 5,    "max_level": 10, "upgrade_multiplier": 1.3},
    "car_wash":        {"name": "🚗 Автомойка",            "base_cost": 3_200,       "base_income": 120,       "cooldown_minutes": 10,   "max_level": 10, "upgrade_multiplier": 1.3},
    "coffee_shop":     {"name": "☕ Кофейня",               "base_cost": 9_500,       "base_income": 300,       "cooldown_minutes": 15,   "max_level": 10, "upgrade_multiplier": 1.3},
    "restaurant":      {"name": "🍽 Ресторан",              "base_cost": 32_000,      "base_income": 900,       "cooldown_minutes": 30,   "max_level": 10, "upgrade_multiplier": 1.3},
    "nightclub":       {"name": "🎵 Ночной клуб",          "base_cost": 130_000,     "base_income": 3_000,     "cooldown_minutes": 60,   "max_level": 10, "upgrade_multiplier": 1.3},
    "hotel":           {"name": "🏨 Отель",                 "base_cost": 320_000,     "base_income": 7_000,     "cooldown_minutes": 120,  "max_level": 10, "upgrade_multiplier": 1.3},
    "casino_biz":      {"name": "🎰 Казино",               "base_cost": 950_000,     "base_income": 20_000,    "cooldown_minutes": 180,  "max_level": 10, "upgrade_multiplier": 1.3},
    "bank":            {"name": "🏦 Банк",                  "base_cost": 3_200_000,   "base_income": 60_000,    "cooldown_minutes": 360,  "max_level": 10, "upgrade_multiplier": 1.3},
    "oil_field":       {"name": "🛢 Нефтяная скважина",    "base_cost": 13_000_000,  "base_income": 240_000,   "cooldown_minutes": 720,  "max_level": 10, "upgrade_multiplier": 1.3},
    "space_station":   {"name": "🚀 Космическая станция",  "base_cost": 65_000_000,  "base_income": 1_200_000, "cooldown_minutes": 1440, "max_level": 10, "upgrade_multiplier": 1.3},
    "tech_startup":    {"name": "💻 Тех-стартап",           "base_cost": 6_500,       "base_income": 180,       "cooldown_minutes": 12,   "max_level": 10, "upgrade_multiplier": 1.3},
    "factory":         {"name": "🏭 Завод",                 "base_cost": 65_000,      "base_income": 1_800,     "cooldown_minutes": 45,   "max_level": 10, "upgrade_multiplier": 1.3},
    "supermarket":     {"name": "🛒 Супермаркет",           "base_cost": 195_000,     "base_income": 4_800,     "cooldown_minutes": 90,   "max_level": 10, "upgrade_multiplier": 1.3},
    "media_company":   {"name": "📺 Медиакомпания",         "base_cost": 520_000,     "base_income": 12_000,    "cooldown_minutes": 150,  "max_level": 10, "upgrade_multiplier": 1.3},
    "crypto_exchange": {"name": "💹 Крипто-биржа",          "base_cost": 1_950_000,   "base_income": 48_000,    "cooldown_minutes": 300,  "max_level": 10, "upgrade_multiplier": 1.3},
    "airline":         {"name": "✈️ Авиакомпания",          "base_cost": 6_500_000,   "base_income": 150_000,   "cooldown_minutes": 480,  "max_level": 10, "upgrade_multiplier": 1.3},
    "pharmaceutical":  {"name": "💊 Фармкомпания",          "base_cost": 32_000_000,  "base_income": 720_000,   "cooldown_minutes": 960,  "max_level": 10, "upgrade_multiplier": 1.3},
    "military_corp":   {"name": "🪖 ВПК",                   "base_cost": 130_000_000, "base_income": 3_000_000, "cooldown_minutes": 1440, "max_level": 10, "upgrade_multiplier": 1.3},
    "real_estate":     {"name": "🏗 Застройщик",            "base_cost": 260_000,     "base_income": 6_000,     "cooldown_minutes": 120,  "max_level": 10, "upgrade_multiplier": 1.3},
    "power_plant":     {"name": "⚡ Электростанция",        "base_cost": 325_000_000, "base_income": 9_000_000, "cooldown_minutes": 2880, "max_level": 10, "upgrade_multiplier": 1.3},
}

SHOP_ITEMS = {
    "energy_drink":     {"name": "⚡ Энергетик",           "description": "Сбрасывает кулдаун работы",               "price": 500,        "consumable": True, "effect": "reset_work_cooldown"},
    "pickaxe":          {"name": "⛏ Кирка",               "description": "Сбрасывает кулдаун майнинга",              "price": 1_000,      "consumable": True, "effect": "reset_mine_cooldown"},
    "casino_token":     {"name": "🎰 Казино-жетон",        "description": "Сбрасывает кулдаун казино/слотов",         "price": 2_000,      "consumable": True, "effect": "reset_casino_cooldown"},
    "lucky_coin":       {"name": "🍀 Монета удачи",        "description": "+20% к выигрышу в следующей игре",         "price": 5_000,      "consumable": True, "effect": "luck_boost"},
    "experience_boost": {"name": "📚 Книга знаний",        "description": "x2 опыта на 1 час",                        "price": 8_000,      "consumable": True, "effect": "exp_boost_1h"},
    "income_boost":     {"name": "💰 Золотая руна",        "description": "x2 доход от бизнесов на 1 час",            "price": 15_000,     "consumable": True, "effect": "income_boost_1h"},
    "mining_boost":     {"name": "🔋 Майнинг-буст",        "description": "x3 добыча крипты на 2 часа",               "price": 50_000,     "consumable": True, "effect": "mining_boost_2h"},
    "crypto_analyzer":  {"name": "📊 Крипто-анализатор",   "description": "Показывает следующий тренд цены",          "price": 25_000,     "consumable": True, "effect": "crypto_signal"},
    "tax_shield":       {"name": "🛡 Налоговый щит",       "description": "0% налог на переводы (24ч)",               "price": 20_000,     "consumable": True, "effect": "tax_shield_24h"},
    "jackpot_ticket":   {"name": "🎟 Джекпот-тикет",       "description": "Гарантированный джекпот в слотах",         "price": 500_000,    "consumable": True, "effect": "slots_jackpot"},
    "business_license": {"name": "📋 Бизнес-лицензия",     "description": "+25% к доходу бизнесов на 6ч",             "price": 75_000,     "consumable": True, "effect": "biz_boost_6h"},
    "farm_accelerator": {"name": "🚀 Акселератор фермы",   "description": "Мгновенный сбор со всех майнинг-ферм",     "price": 100_000,    "consumable": True, "effect": "instant_farm_collect"},
    "market_insider":   {"name": "📈 Инсайдер рынка",      "description": "Следующая покупка крипты -10%",            "price": 200_000,    "consumable": True, "effect": "crypto_discount"},
    "vip_card_1d":      {"name": "👑 VIP 1 день",          "description": "Снимает все кулдауны на 24 часа",          "price": 9_000_000,  "consumable": True, "effect": "vip_24h"},
    "vip_card_7d":      {"name": "💎 VIP 7 дней",          "description": "Снимает все кулдауны на 7 дней",           "price": 50_000_000, "consumable": True, "effect": "vip_7d"},
    "vip_card_30d":     {"name": "👑💎 VIP 30 дней",       "description": "Снимает все кулдауны на 30 дней",          "price": 180_000_000,"consumable": True, "effect": "vip_30d"},
}
