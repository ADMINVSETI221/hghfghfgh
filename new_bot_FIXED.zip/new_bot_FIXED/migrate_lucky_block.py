"""
Migration script to add last_lucky_block field to users table
"""
import sqlite3
from datetime import datetime


def migrate_database():
    """Add last_lucky_block column if it doesn't exist"""
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    
    try:
        # Проверяем, существует ли колонка
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'last_lucky_block' not in columns:
            print("Adding last_lucky_block column...")
            cursor.execute("ALTER TABLE users ADD COLUMN last_lucky_block TIMESTAMP")
            conn.commit()
            print("✅ Migration completed successfully!")
        else:
            print("✅ Column already exists, no migration needed.")
    
    except Exception as e:
        print(f"❌ Error during migration: {e}")
        conn.rollback()
    
    finally:
        conn.close()


if __name__ == "__main__":
    migrate_database()
