"""
Flask Web Admin Panel
"""
import asyncio
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from functools import wraps
from datetime import datetime

from config import settings, TEMPLATES_DIR, STATIC_DIR
from services.database import get_db, UserService, TransactionService, AsyncSessionLocal


app = Flask(
    __name__,
    template_folder=str(TEMPLATES_DIR),
    static_folder=str(STATIC_DIR)
)
app.config['SECRET_KEY'] = settings.SECRET_KEY

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


class AdminUser(UserMixin):
    def __init__(self, id):
        self.id = id


@login_manager.user_loader
def load_user(user_id):
    return AdminUser(user_id)


def async_route(f):
    """Decorator to run async functions in Flask routes"""
    @wraps(f)
    def wrapper(*args, **kwargs):
        return asyncio.run(f(*args, **kwargs))
    return wrapper


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == settings.ADMIN_USERNAME and password == settings.ADMIN_PASSWORD:
            user = AdminUser(id=1)
            login_user(user)
            flash('Вход выполнен успешно!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Неверный логин или пароль!', 'error')
    
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    """Logout"""
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))


@app.route('/')
@login_required
@async_route
async def index():
    """Dashboard"""
    async with AsyncSessionLocal() as session:
        user_count = await UserService.get_user_count(session)
        all_users = await UserService.get_all_users(session)
        
        total_balance = sum(u.balance for u in all_users)
        banned_count = sum(1 for u in all_users if u.is_banned)
        avg_level = sum(u.level for u in all_users) / user_count if user_count > 0 else 0
        
        stats = {
            'user_count': user_count,
            'total_balance': total_balance,
            'banned_count': banned_count,
            'avg_level': avg_level
        }
    
    return render_template('index.html', stats=stats)


@app.route('/users')
@login_required
@async_route
async def users():
    """Users list"""
    async with AsyncSessionLocal() as session:
        all_users = await UserService.get_all_users(session)
    
    return render_template('users.html', users=all_users)


@app.route('/user/<int:telegram_id>')
@login_required
@async_route
async def user_detail(telegram_id):
    """User detail page"""
    async with AsyncSessionLocal() as session:
        user = await UserService.get_by_telegram_id(session, telegram_id)
        if not user:
            flash('Пользователь не найден!', 'error')
            return redirect(url_for('users'))
        
        transactions = await TransactionService.get_user_transactions(session, user.id, limit=50)
    
    return render_template('user_detail.html', user=user, transactions=transactions)


@app.route('/user/<int:telegram_id>/edit', methods=['GET', 'POST'])
@login_required
@async_route
async def edit_user(telegram_id):
    """Edit user"""
    async with AsyncSessionLocal() as session:
        user = await UserService.get_by_telegram_id(session, telegram_id)
        if not user:
            flash('Пользователь не найден!', 'error')
            return redirect(url_for('users'))
        
        if request.method == 'POST':
            user.balance = float(request.form.get('balance', user.balance))
            user.level = int(request.form.get('level', user.level))
            user.experience = int(request.form.get('experience', user.experience))
            
            await session.commit()
            flash('Пользователь обновлен!', 'success')
            return redirect(url_for('user_detail', telegram_id=telegram_id))
    
    return render_template('edit_user.html', user=user)


@app.route('/user/<int:telegram_id>/ban', methods=['POST'])
@login_required
@async_route
async def ban_user(telegram_id):
    """Ban user"""
    reason = request.form.get('reason', 'Не указана')
    
    async with AsyncSessionLocal() as session:
        success = await UserService.ban_user(session, telegram_id, reason)
        
        if success:
            flash('Пользователь заблокирован!', 'success')
        else:
            flash('Ошибка при блокировке!', 'error')
    
    return redirect(url_for('user_detail', telegram_id=telegram_id))


@app.route('/user/<int:telegram_id>/unban', methods=['POST'])
@login_required
@async_route
async def unban_user(telegram_id):
    """Unban user"""
    async with AsyncSessionLocal() as session:
        success = await UserService.unban_user(session, telegram_id)
        
        if success:
            flash('Пользователь разблокирован!', 'success')
        else:
            flash('Ошибка при разблокировке!', 'error')
    
    return redirect(url_for('user_detail', telegram_id=telegram_id))


@app.route('/transactions')
@login_required
@async_route
async def transactions():
    """Transactions list"""
    async with AsyncSessionLocal() as session:
        all_transactions = await TransactionService.get_all_transactions(session, limit=100)
    
    return render_template('transactions.html', transactions=all_transactions)


@app.template_filter('datetime')
def format_datetime(value):
    """Format datetime for templates"""
    if value is None:
        return ''
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    return value.strftime('%Y-%m-%d %H:%M:%S')


@app.template_filter('balance')
def format_balance(value):
    """Format balance for templates"""
    return f"${value:,.2f}".replace(",", " ")


if __name__ == '__main__':
    app.run(host=settings.WEB_HOST, port=settings.WEB_PORT, debug=True)
