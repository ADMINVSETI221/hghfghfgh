#!/usr/bin/env python3
"""
Database Migration Script
Migrates economy_bot.db to new bot structure
"""
import sqlite3
import json
from datetime import datetime
import shutil

def migrate_database(old_db_path, new_db_path):
    """Migrate old database to new format"""
    
    print("🔄 Начинаем миграцию базы данных...")
    
    # Backup old database
    backup_path = old_db_path + '.backup'
    shutil.copy2(old_db_path, backup_path)
    print(f"✅ Создан бэкап: {backup_path}")
    
    # Connect to databases
    old_conn = sqlite3.connect(old_db_path)
    old_conn.row_factory = sqlite3.Row
    old_cursor = old_conn.cursor()
    
    new_conn = sqlite3.connect(new_db_path)
    new_cursor = new_conn.cursor()
    
    # Create new tables if they don't exist
    print("\n📋 Создаем структуру новой базы данных...")
    
    # Users table with new structure
    new_cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id BIGINT UNIQUE NOT NULL,
        username VARCHAR(255),
        first_name VARCHAR(255),
        balance FLOAT DEFAULT 100.0,
        experience INTEGER DEFAULT 0,
        level INTEGER DEFAULT 1,
        last_work DATETIME,
        last_mine DATETIME,
        last_daily DATETIME,
        last_psychiatrist DATETIME,
        last_casino DATETIME,
        last_slots DATETIME,
        vip_until DATETIME,
        businesses JSON,
        inventory JSON,
        statistics JSON,
        is_banned BOOLEAN DEFAULT 0,
        ban_reason TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Transactions table
    new_cursor.execute('''
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        transaction_type VARCHAR(50),
        amount FLOAT,
        balance_before FLOAT,
        balance_after FLOAT,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )
    ''')
    
    # Global events table
    new_cursor.execute('''
    CREATE TABLE IF NOT EXISTS global_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type VARCHAR(50),
        multiplier FLOAT DEFAULT 1.0,
        is_active BOOLEAN DEFAULT 1,
        starts_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        ends_at DATETIME,
        created_by INTEGER,
        description TEXT
    )
    ''')
    
    print("✅ Структура создана")
    
    # Migrate users
    print("\n👥 Мигрируем пользователей...")
    old_cursor.execute("SELECT * FROM users")
    users = old_cursor.fetchall()
    
    migrated_count = 0
    for user in users:
        try:
            # Parse JSON fields safely
            businesses = user['businesses'] if user['businesses'] else '{}'
            inventory = user['inventory'] if user['inventory'] else '{}'
            statistics = user['statistics'] if user['statistics'] else '{}'
            
            # Parse JSON strings
            if isinstance(businesses, str):
                try:
                    businesses = json.loads(businesses)
                except:
                    businesses = {}
            
            if isinstance(inventory, str):
                try:
                    inventory = json.loads(inventory)
                except:
                    inventory = {}
            
            if isinstance(statistics, str):
                try:
                    statistics = json.loads(statistics)
                except:
                    statistics = {}
            
            # Merge old statistics into new format
            new_statistics = {
                'work_count': statistics.get('works_done', 0),
                'mine_count': 0,  # Not tracked in old DB
                'psychiatrist_marks': statistics.get('psychiatrist_marks', 0),
                'slots_played': 0,
                'casino_played': 0,
                'slots_wins': 0,
                'slots_losses': 0,
                'casino_wins': 0,
                'casino_losses': 0,
                'total_earned': statistics.get('total_earned', 0),
                'total_spent': statistics.get('total_spent', 0),
            }
            
            # Convert VIP expiration to vip_until
            vip_until = user['vip_expires'] if user['vip_expires'] else None
            
            # Insert into new database
            new_cursor.execute('''
            INSERT INTO users (
                telegram_id, username, first_name, balance, experience, level,
                last_work, last_mine, last_daily, last_psychiatrist,
                last_casino, last_slots, vip_until,
                businesses, inventory, statistics,
                is_banned, ban_reason, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user['telegram_id'],
                user['username'],
                user['first_name'],
                user['balance'],
                user['experience'],
                user['level'],
                user['last_work'],
                user['last_mine'],
                user['last_daily'],
                user['last_psychiatrist'],
                None,  # last_casino
                None,  # last_slots
                vip_until,
                json.dumps(businesses),
                json.dumps(inventory),
                json.dumps(new_statistics),
                user['is_banned'],
                user['ban_reason'],
                user['created_at']
            ))
            
            migrated_count += 1
            print(f"  ✓ {user['username'] or user['first_name']} (ID: {user['telegram_id']})")
            
        except Exception as e:
            print(f"  ✗ Ошибка при миграции пользователя {user['telegram_id']}: {e}")
    
    print(f"\n✅ Мигрировано пользователей: {migrated_count}/{len(users)}")
    
    # Migrate transactions (if needed)
    print("\n💳 Мигрируем транзакции...")
    try:
        old_cursor.execute("SELECT * FROM transactions ORDER BY created_at DESC LIMIT 1000")
        transactions = old_cursor.fetchall()
        
        trans_count = 0
        for trans in transactions:
            # Get user_id from new database
            new_cursor.execute("SELECT id FROM users WHERE telegram_id = (SELECT telegram_id FROM users WHERE id = ?)", (trans['user_id'],))
            result = new_cursor.fetchone()
            if result:
                new_user_id = result[0]
                
                new_cursor.execute('''
                INSERT INTO transactions (
                    user_id, transaction_type, amount, balance_before, balance_after,
                    description, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    new_user_id,
                    trans['type'],
                    trans['amount'],
                    0,  # balance_before not tracked in old DB
                    0,  # balance_after not tracked in old DB
                    trans['description'],
                    trans['created_at']
                ))
                trans_count += 1
        
        print(f"✅ Мигрировано транзакций: {trans_count}")
    except Exception as e:
        print(f"⚠️ Ошибка при миграции транзакций: {e}")
    
    # Commit and close
    new_conn.commit()
    old_conn.close()
    new_conn.close()
    
    print("\n" + "="*50)
    print("✅ МИГРАЦИЯ ЗАВЕРШЕНА УСПЕШНО!")
    print("="*50)
    print(f"\n📊 Статистика:")
    print(f"  👥 Пользователей: {migrated_count}")
    print(f"  💳 Транзакций: {trans_count}")
    print(f"\n📁 Файлы:")
    print(f"  🔹 Старая БД: {old_db_path}")
    print(f"  🔹 Бэкап: {backup_path}")
    print(f"  🔹 Новая БД: {new_db_path}")
    print(f"\n💡 Рекомендации:")
    print(f"  1. Проверьте новую БД: sqlite3 {new_db_path}")
    print(f"  2. Запустите бота с новой БД")
    print(f"  3. Проверьте команду 'профиль' для нескольких пользователей")
    print(f"  4. Если все работает - удалите бэкап")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 3:
        print("Использование: python migrate_db.py <старая_бд> <новая_бд>")
        print("Пример: python migrate_db.py economy_bot.db bot.db")
        sys.exit(1)
    
    old_db = sys.argv[1]
    new_db = sys.argv[2]
    
    migrate_database(old_db, new_db)
