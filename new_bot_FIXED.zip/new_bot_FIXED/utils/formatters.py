"""
Formatting utilities
"""
from decimal import Decimal, ROUND_DOWN, InvalidOperation


# Форматы отображения баланса (ключ сохраняется в user.statistics["balance_format"])
BALANCE_FORMATS = {
    "smart":   "🤖 Умный (1.23млрд$)",
    "full":    "🔢 Полный (1234567890.00$)",
    "short":   "📊 Короткий (1.23B$)",
    "russian": "🇷🇺 Русский (1.23 млрд ₽)",
    "coins":   "🪙 Монеты (1 234 567 890 монет)",
}


def format_balance(amount, fmt: str = "smart") -> str:
    """Format balance. fmt: smart | full | short | russian | coins"""
    try:
        d = Decimal(str(amount))
        amount_f = float(d)
    except (InvalidOperation, ValueError, OverflowError):
        amount_f = float(amount)

    abs_val = abs(amount_f)
    sign = "-" if amount_f < 0 else ""

    if fmt == "full":
        # Полный формат с разделителями тысяч
        if abs_val >= 1:
            formatted = f"{abs_val:,.2f}".replace(",", " ")
        else:
            formatted = f"{abs_val:.6f}".rstrip("0").rstrip(".")
        return f"{sign}{formatted}$"

    elif fmt == "short":
        # Короткий английский (B/M/K)
        if abs_val >= 1_000_000_000_000:
            return f"{sign}{abs_val/1_000_000_000_000:.2f}T$"
        elif abs_val >= 1_000_000_000:
            return f"{sign}{abs_val/1_000_000_000:.2f}B$"
        elif abs_val >= 1_000_000:
            return f"{sign}{abs_val/1_000_000:.2f}M$"
        elif abs_val >= 1_000:
            return f"{sign}{abs_val/1_000:.2f}K$"
        else:
            return f"{sign}{abs_val:.2f}$"

    elif fmt == "russian":
        # Русский с рублём
        if abs_val >= 1_000_000_000_000_000:
            return f"{sign}{abs_val/1_000_000_000_000_000:.2f} квадрлн ₽"
        elif abs_val >= 1_000_000_000_000:
            return f"{sign}{abs_val/1_000_000_000_000:.2f} трлн ₽"
        elif abs_val >= 1_000_000_000:
            return f"{sign}{abs_val/1_000_000_000:.2f} млрд ₽"
        elif abs_val >= 1_000_000:
            return f"{sign}{abs_val/1_000_000:.2f} млн ₽"
        elif abs_val >= 1_000:
            return f"{sign}{abs_val/1_000:.2f} тыс ₽"
        else:
            return f"{sign}{abs_val:.2f} ₽"

    elif fmt == "coins":
        # Монеты с разделителями
        coins = int(abs_val)
        formatted = f"{coins:,}".replace(",", " ")
        return f"{sign}{formatted} монет"

    else:
        # smart — умный русский (по умолчанию)
        if abs_val >= 1_000_000_000_000_000:
            return f"{sign}{abs_val/1_000_000_000_000_000:.2f}квадрлн$"
        elif abs_val >= 1_000_000_000_000:
            return f"{sign}{abs_val/1_000_000_000_000:.2f}трлн$"
        elif abs_val >= 1_000_000_000:
            return f"{sign}{abs_val/1_000_000_000:.2f}млрд$"
        elif abs_val >= 1_000_000:
            return f"{sign}{abs_val/1_000_000:.2f}млн$"
        elif abs_val >= 1_000:
            return f"{sign}{abs_val/1_000:.2f}к$"
        else:
            return f"{sign}{abs_val:.2f}$"


def fmt_bal(user, amount=None) -> str:
    """Format balance using user's preferred format.
    If amount is None, formats user.balance.
    """
    val = amount if amount is not None else float(user.balance)
    fmt = (user.statistics or {}).get("balance_format", "smart")
    return format_balance(val, fmt)


def parse_amount(text: str) -> float:
    """
    Parse amount from user input. Supports:
    - Plain numbers: 1000, 1000.50
    - K/M/B/T suffixes: 1k, 1.5m, 2b, 3t (русские тоже: к, м, млн, млрд, трлн)
    - Raises ValueError on invalid input
    """
    text = text.strip().lower().replace(",", ".").replace(" ", "")
    if not text:
        raise ValueError("Пустая сумма")

    multiplier = 1.0
    suffixes = [
        (["квадрлн", "q"], 1_000_000_000_000_000),
        (["трлн", "t"], 1_000_000_000_000),
        (["млрд", "b"], 1_000_000_000),
        (["млн", "m", "м"], 1_000_000),
        (["тыс", "k", "к"], 1_000),
    ]
    for keys, mult in suffixes:
        for key in keys:
            if text.endswith(key):
                multiplier = mult
                text = text[:-len(key)]
                break
        else:
            continue
        break

    try:
        value = float(text) * multiplier
    except ValueError:
        raise ValueError(f"Не могу распознать число: {text}")

    if value < 0:
        raise ValueError("Сумма не может быть отрицательной")

    return value


def format_time(seconds: int) -> str:
    """Format time in human-readable format"""
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60

    parts = []
    if hours > 0:
        parts.append(f"{hours}ч")
    if minutes > 0:
        parts.append(f"{minutes}м")
    if secs > 0 or not parts:
        parts.append(f"{secs}с")

    return " ".join(parts)


def format_number(num: int) -> str:
    """Format large numbers with K, M, B suffixes"""
    if num >= 1_000_000_000:
        return f"{num / 1_000_000_000:.1f}B"
    elif num >= 1_000_000:
        return f"{num / 1_000_000:.1f}M"
    elif num >= 1_000:
        return f"{num / 1_000:.1f}K"
    else:
        return str(num)


def is_user_specific_callback(callback_data: str) -> bool:
    personal_prefixes = ['buy_', 'upgrade_', 'claim_']
    for prefix in personal_prefixes:
        if callback_data.startswith(prefix):
            return True
    return False
