"""
Run Flask Admin Panel
"""
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from admin_panel.app import app
from config import settings

if __name__ == '__main__':
    print(f"🌐 Starting web admin panel on http://{settings.WEB_HOST}:{settings.WEB_PORT}")
    print(f"👤 Login: {settings.ADMIN_USERNAME}")
    print(f"🔑 Password: {settings.ADMIN_PASSWORD}")
    app.run(host=settings.WEB_HOST, port=settings.WEB_PORT, debug=True)
