"""
Business command handlers
"""
from datetime import datetime, timedelta
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import settings
from services.database import get_db, UserService
from models.database import BUSINESSES
from utils.formatters import format_balance, format_time


router = Router()


@router.message(Command("business"))
@router.message(F.text.lower() == "бизнес")
async def cmd_business(message: Message):
    """Show user's businesses"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        if not user.businesses or len(user.businesses) == 0:
            # Show available businesses to buy
            text = "🏢 <b>ДОСТУПНЫЕ БИЗНЕСЫ</b>\n\n"
            text += "У вас еще нет бизнесов. Вот что вы можете купить:\n\n"
            
            builder = InlineKeyboardBuilder()
            
            for business_id, business in BUSINESSES.items():
                cost = business["base_cost"]
                income = business["base_income"]
                interval = business["income_interval"] // 3600
                
                text += (
                    f"{business['name']}\n"
                    f"💰 Цена: {format_balance(cost)}\n"
                    f"📈 Доход: {format_balance(income)}/час\n"
                    f"⏰ Сбор каждые {interval} час(а)\n\n"
                )
                
                builder.button(
                    text=f"Купить {business['name']}", 
                    callback_data=f"buy_business_{business_id}"
                )
            
            builder.adjust(1)
            builder.button(text="◀️ Назад", callback_data="back_to_menu")
            await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())
        else:
            # Show owned businesses
            text = "🏢 <b>ВАШИ БИЗНЕСЫ</b>\n\n"
            
            total_income = 0
            builder = InlineKeyboardBuilder()
            
            for business_id, data in user.businesses.items():
                business = BUSINESSES.get(business_id)
                if not business:
                    continue
                
                level = data.get("level", 1)
                last_collect = data.get("last_collect")
                
                # Calculate income
                income = business["base_income"] * (business["upgrade_multiplier"] ** (level - 1))
                interval = business["income_interval"]
                
                # Calculate available income
                if last_collect:
                    last_collect_dt = datetime.fromisoformat(last_collect) if isinstance(last_collect, str) else last_collect
                    time_passed = (datetime.utcnow() - last_collect_dt).total_seconds()
                    periods = int(time_passed / interval)
                    available = income * periods
                else:
                    available = income
                
                total_income += available
                
                # Upgrade cost
                upgrade_cost = business["base_cost"] * (business["upgrade_multiplier"] ** level)
                
                text += (
                    f"{business['name']} (ур. {level})\n"
                    f"💰 Доступно: {format_balance(available)}\n"
                    f"📈 Доход: {format_balance(income)}/час\n"
                    f"⬆️ Улучшение: {format_balance(upgrade_cost)}\n\n"
                )
                
                # Buttons for each business
                if level < business["max_level"]:
                    builder.button(
                        text=f"⬆️ {business['name']}", 
                        callback_data=f"upgrade_business_{business_id}"
                    )
            
            text += f"💵 Общий доступный доход: {format_balance(total_income)}\n\n"
            text += "Используйте команду 'собрать' для сбора прибыли"
            
            if builder.buttons:
                builder.adjust(1)
                builder.button(text="◀️ Назад", callback_data="back_to_menu")
                await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())
            else:
                # Если нет кнопок улучшения, добавляем только кнопку Назад
                builder.button(text="◀️ Назад", callback_data="back_to_menu")
                await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())


@router.callback_query(F.data.startswith("buy_business_"))
async def buy_business_callback(callback: CallbackQuery):
    """Handle business purchase"""
    business_id = callback.data.split("_", 2)[2]
    business = BUSINESSES.get(business_id)
    
    if not business:
        await callback.answer("❌ Бизнес не найден!", show_alert=True)
        return
    
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=callback.from_user.id,
            username=callback.from_user.username,
            first_name=callback.from_user.first_name
        )
        
        cost = business["base_cost"]
        
        if user.balance < cost:
            await callback.answer(
                f"❌ Недостаточно средств! Нужно: {format_balance(cost)}",
                show_alert=True
            )
            return
        
        # Check if already owns
        if business_id in user.businesses:
            await callback.answer("❌ У вас уже есть этот бизнес!", show_alert=True)
            return
        
        # Purchase business
        from sqlalchemy.orm.attributes import flag_modified
        user.balance -= cost
        # Ensure businesses is a dictionary
        if user.businesses is None or isinstance(user.businesses, list):
            user.businesses = {}
        user.businesses[business_id] = {
            "level": 1,
            "last_collect": datetime.utcnow().isoformat(),
            "total_earned": 0
        }
        flag_modified(user, "businesses")
        
        await UserService.update_balance(
            session, user, 0, "business_purchase",
            f"Покупка бизнеса: {business['name']}"
        )
        
        builder = InlineKeyboardBuilder()
        builder.button(text="🏢 Мои бизнесы", callback_data="my_businesses")
        builder.button(text="◀️ Назад", callback_data="back_to_menu")
        builder.adjust(1)
        
        await callback.message.edit_text(
            f"✅ <b>Бизнес приобретен!</b>\n\n"
            f"{business['name']}\n"
            f"💰 Потрачено: {format_balance(cost)}\n"
            f"💼 Баланс: {format_balance(user.balance)}\n\n"
            f"Используйте 'бизнес' для управления",
            parse_mode="HTML",
            reply_markup=builder.as_markup()
        )
        await callback.answer()


@router.callback_query(F.data.startswith("upgrade_business_"))
async def upgrade_business_callback(callback: CallbackQuery):
    """Handle business upgrade"""
    business_id = callback.data.split("_", 2)[2]
    business = BUSINESSES.get(business_id)
    
    if not business:
        await callback.answer("❌ Бизнес не найден!", show_alert=True)
        return
    
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=callback.from_user.id,
            username=callback.from_user.username,
            first_name=callback.from_user.first_name
        )
        
        if business_id not in user.businesses:
            await callback.answer("❌ У вас нет этого бизнеса!", show_alert=True)
            return
        
        current_level = user.businesses[business_id].get("level", 1)
        
        if current_level >= business["max_level"]:
            await callback.answer("❌ Максимальный уровень достигнут!", show_alert=True)
            return
        
        upgrade_cost = business["base_cost"] * (business["upgrade_multiplier"] ** current_level)
        
        if user.balance < upgrade_cost:
            await callback.answer(
                f"❌ Недостаточно средств! Нужно: {format_balance(upgrade_cost)}",
                show_alert=True
            )
            return
        
        # Upgrade business
        from sqlalchemy.orm.attributes import flag_modified
        user.balance -= upgrade_cost
        user.businesses[business_id]["level"] = current_level + 1
        flag_modified(user, "businesses")
        
        await UserService.update_balance(
            session, user, 0, "business_upgrade",
            f"Улучшение бизнеса: {business['name']}"
        )
        
        new_income = business["base_income"] * (business["upgrade_multiplier"] ** current_level)
        
        builder = InlineKeyboardBuilder()
        builder.button(text="🏢 Мои бизнесы", callback_data="my_businesses")
        builder.button(text="◀️ Назад", callback_data="back_to_menu")
        builder.adjust(1)
        
        await callback.message.edit_text(
            f"⬆️ <b>Бизнес улучшен!</b>\n\n"
            f"{business['name']}\n"
            f"📈 Новый уровень: {current_level + 1}\n"
            f"💰 Потрачено: {format_balance(upgrade_cost)}\n"
            f"📊 Новый доход: {format_balance(new_income)}/час\n"
            f"💼 Баланс: {format_balance(user.balance)}",
            parse_mode="HTML",
            reply_markup=builder.as_markup()
        )
        await callback.answer()


@router.message(Command("collect"))
@router.message(F.text.lower() == "собрать")
async def cmd_collect(message: Message):
    """Collect income from all businesses"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        if not user.businesses:
            await message.answer("❌ У вас нет бизнесов!")
            return
        
        total_collected = 0
        details = []
        
        for business_id, data in user.businesses.items():
            business = BUSINESSES.get(business_id)
            if not business:
                continue
            
            level = data.get("level", 1)
            last_collect = data.get("last_collect")
            
            # Calculate income
            income = business["base_income"] * (business["upgrade_multiplier"] ** (level - 1))
            interval = business["income_interval"]
            
            # Calculate available income
            if last_collect:
                last_collect_dt = datetime.fromisoformat(last_collect) if isinstance(last_collect, str) else last_collect
                time_passed = (datetime.utcnow() - last_collect_dt).total_seconds()
                periods = int(time_passed / interval)
                available = income * periods
                
                if available > 0:
                    from sqlalchemy.orm.attributes import flag_modified
                    total_collected += available
                    details.append(f"{business['name']}: {format_balance(available)}")
                    
                    # Update last collect time
                    user.businesses[business_id]["last_collect"] = datetime.utcnow().isoformat()
                    user.businesses[business_id]["total_earned"] = data.get("total_earned", 0) + available
                    flag_modified(user, "businesses")
        
        if total_collected > 0:
            # Add money
            await UserService.update_balance(
                session, user, total_collected, "business_income",
                "Сбор прибыли с бизнесов"
            )
            
            text = (
                f"💰 <b>ПРИБЫЛЬ СОБРАНА!</b>\n\n"
                + "\n".join(details) + "\n\n"
                f"💵 Всего получено: {format_balance(total_collected)}\n"
                f"💼 Баланс: {format_balance(user.balance)}"
            )
            await message.answer(text, parse_mode="HTML")
        else:
            await message.answer("⏳ Прибыль еще не накопилась!")


@router.callback_query(F.data == "my_businesses")
async def show_my_businesses_callback(callback: CallbackQuery):
    """Show user's businesses from callback"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=callback.from_user.id,
            username=callback.from_user.username,
            first_name=callback.from_user.first_name
        )
        
        # Ensure businesses is a dictionary
        if user.businesses is None or isinstance(user.businesses, list):
            user.businesses = {}
            from sqlalchemy.orm.attributes import flag_modified
            flag_modified(user, "businesses")
            await session.commit()
        
        if not user.businesses or len(user.businesses) == 0:
            # Show available businesses to buy
            text = "🏢 <b>ДОСТУПНЫЕ БИЗНЕСЫ</b>\n\n"
            text += "У вас еще нет бизнесов. Вот что вы можете купить:\n\n"
            
            builder = InlineKeyboardBuilder()
            
            for business_id, business in BUSINESSES.items():
                cost = business["base_cost"]
                income = business["base_income"]
                interval = business["income_interval"] // 3600
                
                text += (
                    f"{business['name']}\n"
                    f"💰 Цена: {format_balance(cost)}\n"
                    f"📈 Доход: {format_balance(income)}/час\n"
                    f"⏰ Сбор каждые {interval} час(а)\n\n"
                )
                
                builder.button(
                    text=f"Купить {business['name']}", 
                    callback_data=f"buy_business_{business_id}"
                )
            
            builder.adjust(1)
            builder.button(text="◀️ Назад", callback_data="back_to_menu")
            await callback.message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())
        else:
            # Show owned businesses
            text = "🏢 <b>ВАШИ БИЗНЕСЫ</b>\n\n"
            
            total_income = 0
            builder = InlineKeyboardBuilder()
            
            for business_id, data in user.businesses.items():
                business = BUSINESSES.get(business_id)
                if not business:
                    continue
                
                level = data.get("level", 1)
                last_collect = data.get("last_collect")
                
                # Calculate income
                income = business["base_income"] * (business["upgrade_multiplier"] ** (level - 1))
                interval = business["income_interval"]
                
                # Calculate available income
                if last_collect:
                    last_collect_dt = datetime.fromisoformat(last_collect) if isinstance(last_collect, str) else last_collect
                    time_passed = (datetime.utcnow() - last_collect_dt).total_seconds()
                    periods = int(time_passed / interval)
                    available = income * periods
                else:
                    available = income
                
                total_income += available
                
                # Upgrade cost
                upgrade_cost = business["base_cost"] * (business["upgrade_multiplier"] ** level)
                
                text += (
                    f"{business['name']} (ур. {level})\n"
                    f"💰 Доступно: {format_balance(available)}\n"
                    f"📈 Доход: {format_balance(income)}/час\n"
                    f"⬆️ Улучшение: {format_balance(upgrade_cost)}\n\n"
                )
                
                # Buttons for each business
                if level < business["max_level"]:
                    builder.button(
                        text=f"⬆️ {business['name']}", 
                        callback_data=f"upgrade_business_{business_id}"
                    )
            
            text += f"💵 Общий доступный доход: {format_balance(total_income)}\n\n"
            text += "Используйте команду 'собрать' для сбора прибыли"
            
            builder.adjust(1)
            builder.button(text="◀️ Назад", callback_data="back_to_menu")
            await callback.message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())
    
    await callback.answer()


@router.callback_query(F.data == "back_to_menu")
async def back_to_menu_callback(callback: CallbackQuery):
    """Handle back to menu button"""
    text = (
        "🎮 <b>Главное меню</b>\n\n"
        "Используйте команды для игры:\n"
        "💼 раб / работать - Заработать деньги\n"
        "⛏ майн - Майнинг\n"
        "🎁 дейли - Ежедневный бонус\n"
        "🎰 слоты [ставка] - Слоты\n"
        "🎲 казино [ставка] - Казино\n"
        "👤 профиль - Ваш профиль\n"
        "🏆 топ - Топы игроков\n"
        "🏪 магазин - Магазин предметов\n"
        "🏢 бизнес - Ваши бизнесы"
    )
    
    try:
        await callback.message.edit_text(text, parse_mode="HTML")
    except:
        await callback.message.answer(text, parse_mode="HTML")
    
    await callback.answer()
