"""
Database service layer with async SQLAlchemy
"""
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional, List
from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker

from config import settings
from models.database import Base, User, Transaction, GlobalEvent, Giveaway


# Create async engine
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=False,
    future=True
)

# Create session maker
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)


@asynccontextmanager
async def get_db():
    """Get database session"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def init_db():
    """Initialize database"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db():
    """Close database connections"""
    await engine.dispose()


class UserService:
    """User service layer"""
    
    @staticmethod
    async def get_or_create(
        session: AsyncSession,
        telegram_id: int,
        username: Optional[str] = None,
        first_name: Optional[str] = None
    ) -> User:
        """Get existing user or create new one"""
        result = await session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        user = result.scalar_one_or_none()
        
        if user:
            # Update user info if changed
            if username and user.username != username:
                user.username = username
            if first_name and user.first_name != first_name:
                user.first_name = first_name
            
            # Convert old businesses format (list) to new format (dict)
            if user.businesses and isinstance(user.businesses, list):
                from sqlalchemy.orm.attributes import flag_modified
                old_businesses = user.businesses
                new_businesses = {}
                
                # Map old business IDs to new business keys
                business_id_map = {
                    1: "lemonade_stand",
                    2: "car_wash",
                    3: "coffee_shop",
                    4: "restaurant",
                    5: "casino",
                    6: "hotel"
                }
                
                for business in old_businesses:
                    if isinstance(business, dict) and 'id' in business:
                        business_key = business_id_map.get(business['id'])
                        if business_key:
                            new_businesses[business_key] = {
                                "level": business.get('level', 1),
                                "last_collect": business.get('last_collect', datetime.utcnow().isoformat()),
                                "total_earned": business.get('total_earned', 0)
                            }
                
                user.businesses = new_businesses
                flag_modified(user, "businesses")
                await session.commit()
                await session.refresh(user)
            
            # Convert old inventory format (list) to new format (dict) if needed
            if user.inventory and isinstance(user.inventory, list):
                from sqlalchemy.orm.attributes import flag_modified
                user.inventory = {}
                flag_modified(user, "inventory")
                await session.commit()
                await session.refresh(user)
            
            return user
        
        # Create new user
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            balance=settings.START_BALANCE,
            statistics={},
            businesses={},
            inventory={}
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return user
    
    @staticmethod
    async def get_by_telegram_id(session: AsyncSession, telegram_id: int) -> Optional[User]:
        """Get user by telegram ID"""
        result = await session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()
    
    @staticmethod
    async def update_balance(
        session: AsyncSession,
        user: User,
        amount: float,
        transaction_type: str,
        description: str = ""
    ) -> User:
        """Update user balance and create transaction"""
        balance_before = user.balance
        user.balance += amount
        balance_after = user.balance
        
        # Create transaction record
        transaction = Transaction(
            user_id=user.id,
            transaction_type=transaction_type,
            amount=amount,
            balance_before=balance_before,
            balance_after=balance_after,
            description=description
        )
        session.add(transaction)
        
        # Update statistics
        if amount > 0:
            user.statistics["total_earned"] = user.statistics.get("total_earned", 0) + amount
        else:
            user.statistics["total_spent"] = user.statistics.get("total_spent", 0) + abs(amount)
        
        await session.commit()
        await session.refresh(user)
        return user
    
    @staticmethod
    async def add_experience(session: AsyncSession, user: User, exp: int) -> bool:
        """Add experience and check for level up"""
        user.experience += exp
        
        # Calculate required experience for next level
        required_exp = user.level * 100
        
        level_up = False
        while user.experience >= required_exp:
            user.experience -= required_exp
            user.level += 1
            level_up = True
            required_exp = user.level * 100
        
        await session.commit()
        await session.refresh(user)
        return level_up
    
    @staticmethod
    async def get_top_by_balance(session: AsyncSession, limit: int = 10) -> List[User]:
        """Get top users by balance"""
        result = await session.execute(
            select(User)
            .where(User.is_banned == False)
            .order_by(desc(User.balance))
            .limit(limit)
        )
        return list(result.scalars().all())
    
    @staticmethod
    async def get_top_by_level(session: AsyncSession, limit: int = 10) -> List[User]:
        """Get top users by level"""
        result = await session.execute(
            select(User)
            .where(User.is_banned == False)
            .order_by(desc(User.level), desc(User.experience))
            .limit(limit)
        )
        return list(result.scalars().all())
    
    @staticmethod
    async def get_top_by_psychiatrist(session: AsyncSession, limit: int = 10) -> List[User]:
        """Get top users by psychiatrist marks"""
        result = await session.execute(
            select(User)
            .where(User.is_banned == False)
        )
        users = list(result.scalars().all())
        
        # Sort by psychiatrist marks in statistics
        users.sort(key=lambda u: u.statistics.get('psychiatrist_marks', 0), reverse=True)
        
        return users[:limit]
    
    @staticmethod
    async def get_all_users(session: AsyncSession) -> List[User]:
        """Get all users"""
        result = await session.execute(select(User))
        return list(result.scalars().all())
    
    @staticmethod
    async def get_user_count(session: AsyncSession) -> int:
        """Get total user count"""
        result = await session.execute(select(func.count(User.id)))
        return result.scalar_one()
    
    @staticmethod
    async def ban_user(session: AsyncSession, telegram_id: int, reason: str) -> bool:
        """Ban user"""
        user = await UserService.get_by_telegram_id(session, telegram_id)
        if not user:
            return False
        
        user.is_banned = True
        user.ban_reason = reason
        await session.commit()
        return True
    
    @staticmethod
    async def unban_user(session: AsyncSession, telegram_id: int) -> bool:
        """Unban user"""
        user = await UserService.get_by_telegram_id(session, telegram_id)
        if not user:
            return False
        
        user.is_banned = False
        user.ban_reason = None
        await session.commit()
        return True


class TransactionService:
    """Transaction service layer"""
    
    @staticmethod
    async def get_user_transactions(
        session: AsyncSession,
        user_id: int,
        limit: int = 10
    ) -> List[Transaction]:
        """Get user transaction history"""
        result = await session.execute(
            select(Transaction)
            .where(Transaction.user_id == user_id)
            .order_by(desc(Transaction.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())
    
    @staticmethod
    async def get_all_transactions(
        session: AsyncSession,
        limit: int = 100
    ) -> List[Transaction]:
        """Get all transactions"""
        result = await session.execute(
            select(Transaction)
            .order_by(desc(Transaction.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())
