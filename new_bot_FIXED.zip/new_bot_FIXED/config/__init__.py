from .settings import settings, LOGS_DIR, BACKUPS_DIR, STATIC_DIR, TEMPLATES_DIR

__all__ = ["settings", "LOGS_DIR", "BACKUPS_DIR", "STATIC_DIR", "TEMPLATES_DIR"]
