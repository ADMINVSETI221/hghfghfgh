"""
Configuration management using Pydantic Settings
"""
from pathlib import Path
from typing import List
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings with validation"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    # Paths
    BASE_DIR: Path = Path(__file__).parent.parent
    
    # Telegram Bot
    BOT_TOKEN: str = Field(..., description="Bot token from @BotFather")
    OWNER_ID: int = Field(..., description="Bot owner Telegram ID")
    ADMIN_IDS: str = Field(default="", description="Comma-separated admin IDs")
    
    # Admin Bot & Log Chat
    ADMIN_BOT_TOKEN: str = Field(default="", description="Separate bot token for admin panel bot")
    LOG_CHAT_ID: int = Field(default=0, description="Telegram chat ID for bot logs")
    
    @field_validator("ADMIN_IDS", mode="before")
    @classmethod
    def validate_admin_ids(cls, v):
        """Convert admin IDs to string format"""
        if isinstance(v, list):
            return ",".join(map(str, v))
        if isinstance(v, (int, str)):
            return str(v)
        return ""
    
    # Database
    DATABASE_URL: str = Field(
        default="sqlite+aiosqlite:///./bot.db",
        description="Database connection URL"
    )
    
    # Web Server
    WEB_HOST: str = Field(default="0.0.0.0")
    WEB_PORT: int = Field(default=5000)
    SECRET_KEY: str = Field(..., description="Secret key for sessions")
    
    # Admin Panel
    ADMIN_USERNAME: str = Field(default="admin")
    ADMIN_PASSWORD: str = Field(default="admin123")
    
    # Game Settings
    START_BALANCE: float = Field(default=100.0)
    WORK_COOLDOWN: int = Field(default=300)
    MINE_COOLDOWN: int = Field(default=600)
    DAILY_COOLDOWN: int = Field(default=86400)
    PSYCHIATRIST_COOLDOWN: int = Field(default=14400)
    CASINO_COOLDOWN: int = Field(default=5)
    SLOTS_COOLDOWN: int = Field(default=5)
    TAX_RATE: float = Field(default=0.05)
    
    # Casino Settings
    MIN_CASINO_BET: int = Field(default=1)
    MAX_CASINO_BET: int = Field(default=999999999)
    CASINO_WIN_MULTIPLIERS: str = Field(default="0,1.25,2,5,10")
    CASINO_WIN_WEIGHTS: str = Field(default="40,30,20,8,2")  # Probabilities for each multiplier
    
    # Slots Settings
    MIN_SLOTS_BET: int = Field(default=1)
    MAX_SLOTS_BET: int = Field(default=999999999)
    
    @property
    def admin_ids_list(self) -> List[int]:
        """Get admin IDs as list"""
        if isinstance(self.ADMIN_IDS, list):
            return self.ADMIN_IDS
        if not self.ADMIN_IDS or self.ADMIN_IDS == "":
            return []
        return [int(x.strip()) for x in str(self.ADMIN_IDS).split(",") if x.strip()]
    
    @property
    def all_admin_ids(self) -> List[int]:
        """Get all admin IDs including owner"""
        return list(set([self.OWNER_ID] + self.admin_ids_list))
    
    @property
    def casino_multipliers(self) -> List[float]:
        """Get casino win multipliers as list"""
        return [float(x.strip()) for x in self.CASINO_WIN_MULTIPLIERS.split(",")]
    
    @property
    def casino_weights(self) -> List[int]:
        """Get casino win weights as list"""
        return [int(x.strip()) for x in self.CASINO_WIN_WEIGHTS.split(",")]


# Global settings instance
settings = Settings()

# Create necessary directories
LOGS_DIR = settings.BASE_DIR / "logs"
BACKUPS_DIR = settings.BASE_DIR / "backups"
STATIC_DIR = settings.BASE_DIR / "admin_panel" / "static"
TEMPLATES_DIR = settings.BASE_DIR / "admin_panel" / "templates"

for directory in [LOGS_DIR, BACKUPS_DIR, STATIC_DIR, TEMPLATES_DIR]:
    directory.mkdir(exist_ok=True, parents=True)
# patch — добавляем поля для лог-чата и админ-бота (применяется при импорте)
