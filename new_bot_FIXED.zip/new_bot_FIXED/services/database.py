"""
Database service layer with async SQLAlchemy
"""
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional, List
from sqlalchemy import select, func, desc, event, text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import NullPool

from config import settings
from models.database import Base, User, Transaction, GlobalEvent, Giveaway, CryptoPrice, CRYPTO_DEFAULTS


# Create async engine — NullPool для SQLite (нет смысла держать пул, только конфликты)
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=False,
    future=True,
    poolclass=NullPool,
    connect_args={
        "timeout": 30,          # ждать до 30с при блокировке
        "check_same_thread": False,
    }
)


@event.listens_for(engine.sync_engine, "connect")
def set_wal_mode(dbapi_conn, connection_record):
    """Включаем WAL-mode — параллельные читатели не блокируют запись"""
    dbapi_conn.execute("PRAGMA journal_mode=WAL")
    dbapi_conn.execute("PRAGMA synchronous=NORMAL")
    dbapi_conn.execute("PRAGMA busy_timeout=30000")  # 30 секунд ожидания
    dbapi_conn.execute("PRAGMA cache_size=-64000")   # 64MB кеш


# Create session maker
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)


@asynccontextmanager
async def get_db():
    """Get database session"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def init_db():
    """Initialize database"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    # Seed crypto prices
    async with AsyncSessionLocal() as session:
        from services.crypto_service import seed_crypto_prices
        await seed_crypto_prices(session)


async def close_db():
    """Close database connections"""
    await engine.dispose()


class UserService:
    """User service layer"""
    
    @staticmethod
    async def get_or_create(
        session: AsyncSession,
        telegram_id: int,
        username: Optional[str] = None,
        first_name: Optional[str] = None
    ) -> User:
        """Get existing user or create new one"""
        result = await session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        user = result.scalar_one_or_none()
        
        if user:
            # Update user info if changed
            if username and user.username != username:
                user.username = username
            if first_name and user.first_name != first_name:
                user.first_name = first_name
            
            # Convert old businesses format (list) to new format (dict)
            if user.businesses and isinstance(user.businesses, list):
                from sqlalchemy.orm.attributes import flag_modified
                old_businesses = user.businesses
                new_businesses = {}
                
                # Map old business IDs to new business keys
                business_id_map = {
                    1: "lemonade_stand",
                    2: "car_wash",
                    3: "coffee_shop",
                    4: "restaurant",
                    5: "casino",
                    6: "hotel"
                }
                
                for business in old_businesses:
                    if isinstance(business, dict) and 'id' in business:
                        business_key = business_id_map.get(business['id'])
                        if business_key:
                            new_businesses[business_key] = {
                                "level": business.get('level', 1),
                                "last_collect": business.get('last_collect', datetime.utcnow().isoformat()),
                                "total_earned": business.get('total_earned', 0)
                            }
                
                user.businesses = new_businesses
                flag_modified(user, "businesses")
                await session.commit()
                await session.refresh(user)
            
            # Convert old inventory format (list) to new format (dict) if needed
            if user.inventory and isinstance(user.inventory, list):
                from sqlalchemy.orm.attributes import flag_modified
                user.inventory = {}
                flag_modified(user, "inventory")
                await session.commit()
                await session.refresh(user)
            
            return user
        
        # Create new user
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            balance=settings.START_BALANCE,
            statistics={},
            businesses={},
            inventory={}
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return user
    
    @staticmethod
    async def get_by_telegram_id(session: AsyncSession, telegram_id: int) -> Optional[User]:
        """Get user by telegram ID"""
        result = await session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()
    
    @staticmethod
    async def update_balance(
        session: AsyncSession,
        user: User,
        amount: float,
        transaction_type: str,
        description: str = "",
        allow_negative: bool = False
    ) -> tuple[User, bool]:
        """Update user balance and create transaction
        
        Args:
            session: Database session
            user: User object
            amount: Amount to add/subtract (negative for spending)
            transaction_type: Type of transaction
            description: Transaction description
            allow_negative: Allow balance to go negative (default: False)
            
        Returns:
            tuple[User, bool]: (user, success)
            - success=True if operation completed
            - success=False if balance would become negative and allow_negative=False
        """
        balance_before = float(user.balance)
        new_balance = float(user.balance) + float(amount)
        
        # Check if balance would become negative
        if not allow_negative and new_balance < 0:
            return user, False  # Reject operation
        
        user.balance = round(new_balance, 2)
        balance_after = float(user.balance)
        
        # Create transaction record
        transaction = Transaction(
            user_id=user.id,
            transaction_type=transaction_type,
            amount=amount,
            balance_before=balance_before,
            balance_after=balance_after,
            description=description
        )
        session.add(transaction)
        
        # Update statistics
        if amount > 0:
            user.statistics["total_earned"] = user.statistics.get("total_earned", 0) + amount
        else:
            user.statistics["total_spent"] = user.statistics.get("total_spent", 0) + abs(amount)
        
        await session.commit()
        await session.refresh(user)
        return user, True
    
    @staticmethod
    async def add_experience(session: AsyncSession, user: User, exp: int) -> bool:
        """Add experience and check for level up. Harder formula at high levels."""
        user.experience += exp

        def _req(lvl: int) -> int:
            # Level 1-10: ~500-5000 XP, Level 50: ~260k XP, Level 100: ~1M+ XP
            return max(500, int(lvl ** 2 * 100 + lvl * 200))

        level_up = False
        required_exp = _req(user.level)
        while user.experience >= required_exp:
            user.experience -= required_exp
            user.level += 1
            level_up = True
            required_exp = _req(user.level)

        await session.commit()
        await session.refresh(user)
        return level_up
    
    @staticmethod
    async def get_top_by_balance(session: AsyncSession, limit: int = 10) -> List[User]:
        """Get top users by balance"""
        result = await session.execute(
            select(User)
            .where(User.is_banned == False)
            .order_by(desc(User.balance))
            .limit(limit)
        )
        return list(result.scalars().all())
    
    @staticmethod
    async def get_top_by_level(session: AsyncSession, limit: int = 10) -> List[User]:
        """Get top users by level"""
        result = await session.execute(
            select(User)
            .where(User.is_banned == False)
            .order_by(desc(User.level), desc(User.experience))
            .limit(limit)
        )
        return list(result.scalars().all())
    
    @staticmethod
    async def get_top_by_psychiatrist(session: AsyncSession, limit: int = 10) -> List[User]:
        """Get top users by psychiatrist marks"""
        result = await session.execute(
            select(User)
            .where(User.is_banned == False)
        )
        users = list(result.scalars().all())
        
        # Sort by psychiatrist marks in statistics
        users.sort(key=lambda u: u.statistics.get('psychiatrist_marks', 0), reverse=True)
        
        return users[:limit]
    
    @staticmethod
    async def get_all_users(session: AsyncSession) -> List[User]:
        """Get all users"""
        result = await session.execute(select(User))
        return list(result.scalars().all())
    
    @staticmethod
    async def get_user_count(session: AsyncSession) -> int:
        """Get total user count"""
        result = await session.execute(select(func.count(User.id)))
        return result.scalar_one()
    
    @staticmethod
    async def ban_user(session: AsyncSession, telegram_id: int, reason: str) -> bool:
        """Ban user"""
        user = await UserService.get_by_telegram_id(session, telegram_id)
        if not user:
            return False
        
        user.is_banned = True
        user.ban_reason = reason
        await session.commit()
        return True
    
    @staticmethod
    async def unban_user(session: AsyncSession, telegram_id: int) -> bool:
        """Unban user"""
        user = await UserService.get_by_telegram_id(session, telegram_id)
        if not user:
            return False
        
        user.is_banned = False
        user.ban_reason = None
        await session.commit()
        return True


class TransactionService:
    """Transaction service layer"""
    
    @staticmethod
    async def get_user_transactions(
        session: AsyncSession,
        user_id: int,
        limit: int = 10
    ) -> List[Transaction]:
        """Get user transaction history"""
        result = await session.execute(
            select(Transaction)
            .where(Transaction.user_id == user_id)
            .order_by(desc(Transaction.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())
    
    @staticmethod
    async def get_all_transactions(
        session: AsyncSession,
        limit: int = 100
    ) -> List[Transaction]:
        """Get all transactions"""
        result = await session.execute(
            select(Transaction)
            .order_by(desc(Transaction.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())
