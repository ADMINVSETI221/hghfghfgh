"""
Динамические цены — можно менять через админ-бот без рестарта.
Хранятся в памяти (сбрасываются при рестарте), но можно сохранить в файл.
"""
import json
from pathlib import Path
from copy import deepcopy
from models.database import BUSINESSES, SHOP_ITEMS

PRICES_FILE = Path(__file__).parent.parent / "prices_override.json"

# Runtime overrides
_business_overrides: dict = {}   # {biz_id: {base_cost, base_income, ...}}
_shop_overrides: dict = {}       # {item_id: {price}}
_game_overrides: dict = {}       # {work_min, work_max, mine_min, mine_max, daily_amount}

DEFAULT_GAME = {
    "work_min": 50,
    "work_max": 150,
    "mine_min": 100,
    "mine_max": 300,
    "daily_min": 500,
    "daily_max": 2000,
}


def _load():
    global _business_overrides, _shop_overrides, _game_overrides
    if PRICES_FILE.exists():
        try:
            data = json.loads(PRICES_FILE.read_text())
            _business_overrides = data.get("businesses", {})
            _shop_overrides = data.get("shop", {})
            _game_overrides = data.get("game", {})
        except Exception:
            pass


def _save():
    try:
        PRICES_FILE.write_text(json.dumps({
            "businesses": _business_overrides,
            "shop": _shop_overrides,
            "game": _game_overrides,
        }, ensure_ascii=False, indent=2))
    except Exception:
        pass


_load()


def get_business(biz_id: str) -> dict:
    base = deepcopy(BUSINESSES.get(biz_id, {}))
    base.update(_business_overrides.get(biz_id, {}))
    return base


def get_all_businesses() -> dict:
    result = {}
    for bid in BUSINESSES:
        result[bid] = get_business(bid)
    return result


def set_business_price(biz_id: str, field: str, value) -> bool:
    if biz_id not in BUSINESSES:
        return False
    if biz_id not in _business_overrides:
        _business_overrides[biz_id] = {}
    _business_overrides[biz_id][field] = value
    _save()
    return True


def get_shop_item(item_id: str) -> dict:
    from models.database import SHOP_ITEMS
    base = deepcopy(SHOP_ITEMS.get(item_id, {}))
    base.update(_shop_overrides.get(item_id, {}))
    return base


def set_shop_price(item_id: str, price: int) -> bool:
    from models.database import SHOP_ITEMS
    if item_id not in SHOP_ITEMS:
        return False
    _shop_overrides[item_id] = {"price": price}
    _save()
    return True


def get_game_setting(key: str):
    return _game_overrides.get(key, DEFAULT_GAME.get(key))


def set_game_setting(key: str, value) -> bool:
    if key not in DEFAULT_GAME:
        return False
    _game_overrides[key] = value
    _save()
    return True


def reset_all():
    global _business_overrides, _shop_overrides, _game_overrides
    _business_overrides = {}
    _shop_overrides = {}
    _game_overrides = {}
    _save()
