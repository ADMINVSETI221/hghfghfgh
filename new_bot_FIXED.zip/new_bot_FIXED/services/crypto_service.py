"""
Crypto & Mining service layer
"""
import random
import math
from datetime import datetime, timedelta
from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified

from models.database import CryptoPrice, CRYPTO_DEFAULTS, MINING_FARMS, User


# ── Crypto price helpers ───────────────────────────────────────────────────────

async def seed_crypto_prices(session: AsyncSession):
    """Seed default crypto prices if not present"""
    for symbol, data in CRYPTO_DEFAULTS.items():
        result = await session.execute(select(CryptoPrice).where(CryptoPrice.symbol == symbol))
        if result.scalar_one_or_none() is None:
            cp = CryptoPrice(
                symbol=symbol,
                name=data["name"],
                emoji=data["emoji"],
                price=data["price"],
                volatility=data["volatility"],
                is_tradeable=True,
                admin_enabled=data["admin_enabled"],
                price_history={"prices": [data["price"]] * 12},
                change_24h=0.0,
            )
            session.add(cp)
    await session.commit()


async def get_all_prices(session: AsyncSession) -> list[CryptoPrice]:
    result = await session.execute(select(CryptoPrice).order_by(CryptoPrice.symbol))
    return list(result.scalars().all())


async def get_price(session: AsyncSession, symbol: str) -> Optional[CryptoPrice]:
    result = await session.execute(select(CryptoPrice).where(CryptoPrice.symbol == symbol.upper()))
    return result.scalar_one_or_none()


def _fmt_price(price: float) -> str:
    """Format crypto price for display"""
    if price >= 10_000:
        return f"{price:,.2f}$"
    if price >= 100:
        return f"{price:.2f}$"
    if price >= 1:
        return f"{price:.4f}$"
    if price >= 0.0001:
        return f"{price:.6f}$"
    if price >= 0.000001:
        return f"{price:.8f}$"
    return f"{price:.10f}$"


def _fmt_amount(amount: float) -> str:
    """Format crypto amount"""
    if amount == 0:
        return "0"
    if amount >= 1_000_000:
        return f"{amount:,.0f}"
    if amount >= 1:
        return f"{amount:.4f}"
    if amount >= 0.000001:
        return f"{amount:.8f}"
    return f"{amount:.10f}"


def make_price_chart(history: list[float], symbol: str) -> str:
    """Generate a simple ASCII price chart"""
    if len(history) < 2:
        return "📉 Недостаточно данных"

    prices = history[-24:] if len(history) > 24 else history
    if not prices:
        return "📉 Нет данных"

    mn, mx = min(prices), max(prices)
    if mn == mx:
        mn *= 0.999
        mx *= 1.001

    rows = 6
    chart_lines = []
    for row in range(rows - 1, -1, -1):
        threshold = mn + (mx - mn) * row / (rows - 1)
        line = ""
        for p in prices:
            if p >= threshold:
                line += "█"
            else:
                line += " "
        chart_lines.append(line)

    change = ((prices[-1] - prices[0]) / prices[0]) * 100 if prices[0] != 0 else 0
    arrow = "📈" if change >= 0 else "📉"

    chart = "\n".join(f"`{l}`" for l in chart_lines)
    return f"{arrow} {symbol}  {change:+.2f}%\n{chart}"


async def fluctuate_price(session: AsyncSession, cp: CryptoPrice, side: str = "neutral"):
    """Apply random price fluctuation. side='buy' -> slight up, 'sell' -> slight down"""
    v = cp.volatility
    if side == "buy":
        pct = random.uniform(0, v * 0.5)
    elif side == "sell":
        pct = random.uniform(-v * 0.5, 0)
    else:
        pct = random.uniform(-v, v)

    new_price = max(cp.price * (1 + pct), 1e-15)
    old_price = cp.price

    # Update history
    hist = (cp.price_history or {}).get("prices", [])
    hist.append(new_price)
    if len(hist) > 48:
        hist = hist[-48:]

    cp.price = new_price
    cp.price_history = {"prices": hist}
    change = ((new_price - old_price) / old_price) * 100 if old_price else 0
    cp.change_24h = change
    cp.updated_at = datetime.utcnow()
    await session.commit()


# ── Mining helpers ─────────────────────────────────────────────────────────────

def farm_hourly_rate(farm_cfg: dict, level: int) -> float:
    """Calculate current hourly rate for a farm at given level"""
    base = farm_cfg["base_hourly_rate"]
    bonus = farm_cfg["upgrade_rate_bonus"]
    return base * ((1 + bonus) ** (level - 1))


def farm_upgrade_cost(farm_cfg: dict, current_level: int) -> float:
    """Cost (in mined crypto) to upgrade farm from current_level to current_level+1"""
    base = farm_cfg["upgrade_cost_base"]
    exp = farm_cfg["upgrade_cost_exp"]
    return base * (exp ** (current_level - 1))


def calc_farm_pending(farm_data: dict, farm_cfg: dict) -> float:
    """Calculate pending crypto from last collect until now"""
    last_str = farm_data.get("last_collect")
    level = farm_data.get("level", 1)
    if last_str:
        try:
            last = datetime.fromisoformat(last_str)
        except Exception:
            last = datetime.utcnow()
    else:
        last = datetime.utcnow()

    hours_passed = (datetime.utcnow() - last).total_seconds() / 3600.0
    rate = farm_hourly_rate(farm_cfg, level)
    return hours_passed * rate


# ── Top by crypto ──────────────────────────────────────────────────────────────

async def get_top_by_crypto_value(session: AsyncSession, limit: int = 10) -> list[tuple[User, float]]:
    """Get top users ranked by total crypto portfolio value in USD"""
    all_prices = await get_all_prices(session)
    price_map = {cp.symbol: cp.price for cp in all_prices}

    result = await session.execute(select(User).where(User.is_banned == False))
    users = list(result.scalars().all())

    ranked = []
    for u in users:
        wallet = u.crypto_wallet or {}
        total_usd = sum(wallet.get(sym, 0) * price_map.get(sym, 0) for sym in wallet)
        ranked.append((u, total_usd))

    ranked.sort(key=lambda x: x[1], reverse=True)
    return ranked[:limit]
