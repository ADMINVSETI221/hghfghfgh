"""
Event service - check and apply active global events
"""
from datetime import datetime
from sqlalchemy import select
from models.database import GlobalEvent


async def get_active_events(session) -> list:
    """Return all currently active events"""
    stmt = (
        select(GlobalEvent)
        .where(GlobalEvent.is_active == True)
        .where(GlobalEvent.ends_at > datetime.utcnow())
    )
    result = await session.execute(stmt)
    return result.scalars().all()


async def get_event_multiplier(session, event_type: str) -> float:
    """
    Return combined multiplier for the given event type.
    If multiple events of same type are active - multiply them together.
    Returns 1.0 if no matching event is active.
    """
    events = await get_active_events(session)
    combined = 1.0
    for event in events:
        if event.event_type == event_type:
            combined *= event.multiplier
    return combined


async def has_active_event(session, event_type: str) -> bool:
    """Check if there is at least one active event of the given type"""
    events = await get_active_events(session)
    return any(e.event_type == event_type for e in events)
