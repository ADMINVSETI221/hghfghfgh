"""
🎴 Коллекционные карточки — новая фича!

Игрок может получать случайные карточки через работу/майнинг (5% шанс).
Карточки 5 редкостей: Обычная, Редкая, Эпическая, Легендарная, Мифическая.
Каждая карточка даёт пассивный бонус пока находится в инвентаре.
Команды: карточки, продать_карту [id]
"""
import random
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm.attributes import flag_modified

from services.database import get_db, UserService
from utils.formatters import format_balance

router = Router()

CARD_RARITIES = {
    "common":    {"name": "⬜ Обычная",    "color": "⬜", "bonus_pct": 0.01, "sell_price": 500},
    "rare":      {"name": "🟦 Редкая",     "color": "🟦", "bonus_pct": 0.03, "sell_price": 2000},
    "epic":      {"name": "🟣 Эпическая",  "color": "🟣", "bonus_pct": 0.07, "sell_price": 8000},
    "legendary": {"name": "🟡 Легендарная","color": "🟡", "bonus_pct": 0.15, "sell_price": 30000},
    "mythic":    {"name": "🔴 Мифическая", "color": "🔴", "bonus_pct": 0.30, "sell_price": 150000},
}

CARDS_POOL = [
    # id, name, rarity
    ("card_worker",    "👷 Трудяга",         "common"),
    ("card_miner",     "⛏️ Шахтёр",          "common"),
    ("card_trader",    "📦 Торговец",         "common"),
    ("card_gambler",   "🎲 Игрок",            "rare"),
    ("card_investor",  "📈 Инвестор",         "rare"),
    ("card_hacker",    "💻 Хакер",            "rare"),
    ("card_magnate",   "🏭 Магнат",           "epic"),
    ("card_king",      "👑 Король",           "epic"),
    ("card_dragon",    "🐉 Дракон",           "legendary"),
    ("card_phoenix",   "🦅 Феникс",          "legendary"),
    ("card_zeus",      "⚡ Зевс",             "mythic"),
    ("card_infinity",  "♾️ Бесконечность",   "mythic"),
]

RARITY_WEIGHTS = {
    "common": 50,
    "rare": 25,
    "epic": 15,
    "legendary": 8,
    "mythic": 2,
}


def get_random_card():
    """Pick a random card weighted by rarity."""
    rarities = list(RARITY_WEIGHTS.keys())
    weights = [RARITY_WEIGHTS[r] for r in rarities]
    chosen_rarity = random.choices(rarities, weights=weights, k=1)[0]
    pool = [(cid, cname, cr) for cid, cname, cr in CARDS_POOL if cr == chosen_rarity]
    return random.choice(pool) if pool else None


def get_card_bonus(inventory: dict) -> float:
    """Calculate total income bonus from all cards in inventory."""
    total_bonus = 0.0
    for key, data in inventory.items():
        if not key.startswith("card_"):
            continue
        rarity = data.get("rarity", "common")
        rarity_info = CARD_RARITIES.get(rarity, CARD_RARITIES["common"])
        total_bonus += rarity_info["bonus_pct"]
    return total_bonus


async def try_give_card(session, user, source: str = "work") -> tuple:
    """5% chance to give a card. Returns (card_tuple_or_None, level_up)."""
    if random.random() > 0.05:
        return None, False

    card = get_random_card()
    if not card:
        return None, False

    card_id, card_name, rarity = card
    if user.inventory is None:
        user.inventory = {}

    # Give unique slot
    slot = 1
    while f"{card_id}_{slot}" in user.inventory:
        slot += 1
    slot_key = f"{card_id}_{slot}"

    user.inventory[slot_key] = {
        "card_id": card_id,
        "name": card_name,
        "rarity": rarity,
        "obtained_at": datetime.utcnow().isoformat(),
        "source": source,
    }
    flag_modified(user, "inventory")

    # XP for rare cards
    xp_map = {"common": 5, "rare": 15, "epic": 40, "legendary": 100, "mythic": 250}
    level_up = await UserService.add_experience(session, user, xp_map.get(rarity, 5))
    await session.commit()
    await session.refresh(user)
    return (slot_key, card_name, rarity), level_up


@router.message(Command("cards"))
@router.message(F.text.lower().in_(["карточки", "карты", "карта"]))
async def cmd_cards(message: Message):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        inv = user.inventory or {}
        cards = {k: v for k, v in inv.items() if k.startswith("card_")}

        total_bonus = get_card_bonus(inv)
        builder = InlineKeyboardBuilder()

        if not cards:
            text = (
                "🎴 <b>КОЛЛЕКЦИОННЫЕ КАРТОЧКИ</b>\n\n"
                "У вас пока нет карточек.\n\n"
                "Карточки выпадают с <b>5% шансом</b> при работе и майнинге.\n"
                "Каждая карточка даёт бонус к доходу!\n\n"
                "Редкости и бонусы:\n"
                "⬜ Обычная — +1%\n"
                "🟦 Редкая — +3%\n"
                "🟣 Эпическая — +7%\n"
                "🟡 Легендарная — +15%\n"
                "🔴 Мифическая — +30%"
            )
        else:
            # Sort by rarity value
            rarity_order = ["mythic", "legendary", "epic", "rare", "common"]
            sorted_cards = sorted(cards.items(), key=lambda x: rarity_order.index(x[1].get("rarity", "common")))

            text = (
                f"🎴 <b>КОЛЛЕКЦИОННЫЕ КАРТОЧКИ</b>\n\n"
                f"📦 Карточек: {len(cards)}\n"
                f"💹 Общий бонус к доходу: +{total_bonus*100:.0f}%\n\n"
            )
            for slot_key, data in sorted_cards[:15]:  # Show max 15
                rarity = data.get("rarity", "common")
                rarity_info = CARD_RARITIES.get(rarity, CARD_RARITIES["common"])
                card_name = data.get("name", "Карточка")
                text += (
                    f"{rarity_info['color']} {card_name}\n"
                    f"  Бонус: +{rarity_info['bonus_pct']*100:.0f}%  "
                    f"Продажа: {format_balance(rarity_info['sell_price'])}\n"
                )
                builder.button(
                    text=f"💸 {rarity_info['color']} {card_name}",
                    callback_data=f"sellcard_{slot_key}"
                )
            if len(cards) > 15:
                text += f"\n...и ещё {len(cards) - 15} карточек\n"
            builder.adjust(1)

        builder.button(text="🏠 Меню", callback_data="back_to_menu")
        await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())


@router.callback_query(F.data.startswith("sellcard_"))
async def sell_card_cb(callback: CallbackQuery):
    slot_key = callback.data[len("sellcard_"):]
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        inv = user.inventory or {}
        if slot_key not in inv:
            await callback.answer("❌ Карточка не найдена!", show_alert=True)
            return

        card_data = inv[slot_key]
        rarity = card_data.get("rarity", "common")
        rarity_info = CARD_RARITIES.get(rarity, CARD_RARITIES["common"])
        sell_price = rarity_info["sell_price"]
        card_name = card_data.get("name", "Карточка")

        del user.inventory[slot_key]
        flag_modified(user, "inventory")
        user, _ = await UserService.update_balance(session, user, sell_price, "card_sale", f"Продажа карточки: {card_name}")
        await session.commit()

        await callback.answer(f"💸 Продано за {format_balance(sell_price)}!", show_alert=True)
        # Refresh the cards list
        await cmd_cards.__wrapped__(callback.message) if hasattr(cmd_cards, '__wrapped__') else None
