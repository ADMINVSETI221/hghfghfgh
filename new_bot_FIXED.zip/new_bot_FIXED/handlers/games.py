"""
Game command handlers (slots, casino, dice)
Fixed slots: outcome determined by our RNG, dice used for animation only.
"""
import random
import asyncio
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import settings
from services.database import get_db, UserService
from services.event_service import get_event_multiplier, has_active_event
from utils.formatters import format_balance, parse_amount, fmt_bal, BALANCE_FORMATS

router = Router()
dice_challenges = {}

# ── Telegram slot machine dice value → outcome mapping ─────────────────────────
# Telegram emoji="🎰" dice values 1-64 (официальная таблица Telegram):
#
# Барабаны: каждый принимает значения 0-3 (4 символа).
# value = reel1 + reel2*4 + reel3*16 + 1  (1-indexed)
# Символы:  0=BAR, 1=🍇, 2=🍋, 3=7️⃣
#
# Известные тройные комбинации:
#   1  = BAR BAR BAR      (0+0+0+1)
#   22 = 🍇🍇🍇           (1+1*4+1*16+1)
#   43 = 🍋🍋🍋           (2+2*4+2*16+1)
#   64 = 7️⃣7️⃣7️⃣         (3+3*4+3*16+1)  ← это реальный джекпот 7s
#
# Пары (первые два символа совпадают, третий — нет):
#   BAR BAR + *:  2-4   (reel1=0, reel2=0, reel3=1/2/3)
#   🍇🍇  + *:   5-7   (reel1=1, reel2=1, reel3=0/2/3 — кроме 22)
#   🍋🍋  + *:   ...   см. формулу
#
# Для простоты и надёжности декодируем вручную через формулу:
def _decode_reels(value: int):
    """Декодирует значение кубика 🎰 (1-64) в три символа барабанов."""
    v = value - 1          # 0-63
    r1 = v & 3             # биты 0-1
    r2 = (v >> 2) & 3      # биты 2-3
    r3 = (v >> 4) & 3      # биты 4-5
    return r1, r2, r3      # 0=BAR, 1=🍇, 2=🍋, 3=7️⃣

_REEL_EMOJI = {0: "BAR", 1: "🍇", 2: "🍋", 3: "7️⃣"}

def _parse_dice_outcome(dice_value: int, force_jackpot: bool = False):
    """Возвращает (multiplier, result_text) по значению кубика Telegram."""
    if force_jackpot:
        return 100, "🎊 СУПЕР ДЖЕКПОТ! 7️⃣7️⃣7️⃣ 🎊"

    r1, r2, r3 = _decode_reels(dice_value)
    icons = " ".join(_REEL_EMOJI[r] for r in (r1, r2, r3))

    if r1 == r2 == r3:
        # Тройное совпадение
        if r1 == 3:
            return 100, f"🎊 ДЖЕКПОТ! {icons} 🎊"
        if r1 == 0:
            return 50,  f"💎 BAR-ДЖЕКПОТ! {icons} 💎"
        if r1 == 1:
            return 8,   f"🍇🍇🍇 Тройной виноград! {icons}"
        if r1 == 2:
            return 4,   f"🍋🍋🍋 Тройной лимон! {icons}"

    if r1 == r2:
        # Совпадение первых двух
        if r1 == 3:
            return 3, f"7️⃣7️⃣ Почти джекпот! {icons}"
        if r1 == 0:
            return 3, f"BAR BAR — два бара! {icons}"
        if r1 == 1:
            return 2, f"🍇🍇 Два винограда! {icons}"
        if r1 == 2:
            return 2, f"🍋🍋 Два лимона! {icons}"

    if r2 == r3:
        # Совпадение последних двух
        if r2 == 3:
            return 2, f"Два 7️⃣! {icons}"
        if r2 == 1:
            return 2, f"Два 🍇! {icons}"
        if r2 == 2:
            return 2, f"Два 🍋! {icons}"

    return 0, f"😔 Не повезло... {icons}"


@router.message(Command("slots", "slot"))
@router.message(F.text.lower().startswith("слоты"))
async def cmd_slots(message: Message):
    parts = message.text.split()
    if len(parts) < 2:
        await message.answer(
            f"🎰 <b>СЛОТЫ</b>\n\n"
            f"Использование: <code>слоты [ставка]</code>\n\n"
            f"💵 Мин. ставка: {format_balance(settings.MIN_SLOTS_BET)}\n"
            f"💰 Макс. ставка: {format_balance(settings.MAX_SLOTS_BET)}\n\n"
            f"<b>Выплаты:</b>\n"
            f"2 одинаковых — x2-x3\n"
            f"3 вишни/лимона — x4-x5\n"
            f"🍇🍇🍇 Виноград — x8\n"
            f"⭐⭐⭐ Звёзды — x15\n"
            f"💎💎💎 Алмазы — x30\n"
            f"🔔🔔🔔 Колокола — x50\n"
            f"7️⃣7️⃣7️⃣ ДЖЕКПОТ — x100",
            parse_mode="HTML"
        )
        return

    try:
        bet = parse_amount(parts[-1])
    except (ValueError, IndexError):
        await message.answer("❌ Укажите корректную ставку!")
        return

    if bet < settings.MIN_SLOTS_BET:
        await message.answer(f"❌ Минимальная ставка: {format_balance(settings.MIN_SLOTS_BET)}")
        return
    if bet > settings.MAX_SLOTS_BET:
        await message.answer(f"❌ Максимальная ставка: {format_balance(settings.MAX_SLOTS_BET)}")
        return

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, message.from_user.id,
            message.from_user.username, message.from_user.first_name
        )

        nocooldown = await has_active_event(session, "nocooldown")
        if not nocooldown and user.is_cooldown_active("slots", settings.SLOTS_COOLDOWN):
            rem = user.get_cooldown_remaining("slots", settings.SLOTS_COOLDOWN)
            await message.answer(f"⏳ Подождите ещё {rem} сек!")
            return

        if user.balance < bet:
            await message.answer(f"❌ Недостаточно средств! Баланс: {format_balance(user.balance)}")
            return

        # Check jackpot ticket
        from sqlalchemy.orm.attributes import flag_modified
        inv = user.inventory or {}
        force_jackpot = False
        if "jackpot_ticket" in inv and inv["jackpot_ticket"].get("quantity", 0) > 0:
            force_jackpot = True
            inv["jackpot_ticket"]["quantity"] -= 1
            if inv["jackpot_ticket"]["quantity"] <= 0:
                del inv["jackpot_ticket"]
            flag_modified(user, "inventory")

        # Deduct bet and set cooldown
        user.balance -= bet
        user.last_slots = datetime.utcnow()

        # Отправляем кубик и ждём анимации
        dice_msg = await message.answer_dice(emoji="🎰")
        await asyncio.sleep(3)

        # Результат берём из реального значения кубика Telegram
        dice_value = dice_msg.dice.value
        multiplier, result_text = _parse_dice_outcome(dice_value, force_jackpot)

        # luck_boost: при проигрыше даём перебросок по нашей таблице шансов
        luck_active = "luck_boost" in inv and inv["luck_boost"].get("quantity", 0) > 0
        if luck_active and multiplier == 0:
            # Рандомный выигрышный исход как компенсация
            luck_outcomes = [(50, 2, "🍋🍋 Монета удачи: два лимона!"),
                             (30, 3, "🍇🍇 Монета удачи: два винограда!"),
                             (15, 4, "🍋🍋🍋 Монета удачи: тройной лимон!"),
                             (5,  8, "🍇🍇🍇 Монета удачи: тройной виноград!")]
            weights_l = [r[0] for r in luck_outcomes]
            chosen = random.choices(luck_outcomes, weights=weights_l, k=1)[0]
            multiplier, result_text = chosen[1], chosen[2]
            inv["luck_boost"]["quantity"] -= 1
            if inv["luck_boost"]["quantity"] <= 0:
                del inv["luck_boost"]
            flag_modified(user, "inventory")

        if multiplier > 0:
            win_amount = bet * multiplier
            money_mult = await get_event_multiplier(session, "money")
            luck_mult  = await get_event_multiplier(session, "luck")
            ev_mult = money_mult * luck_mult
            win_amount *= ev_mult
            user.balance += win_amount
            profit = win_amount - bet

            exp = int(multiplier * 2)
            level_up = await UserService.add_experience(session, user, exp)

            user.statistics = user.statistics or {}
            user.statistics["slots_played"] = user.statistics.get("slots_played", 0) + 1
            user.statistics["slots_wins"]   = user.statistics.get("slots_wins",   0) + 1
            flag_modified(user, "statistics")

            await UserService.update_balance(session, user, 0, "slots_win", f"Слоты x{multiplier}")

            ev_str = f"\n🎉 Ивент x{ev_mult:.1f}!" if ev_mult != 1.0 else ""
            jp_str = "\n🎟 Использован джекпот-тикет!" if force_jackpot else ""
            response = (
                f"🎰 <b>РЕЗУЛЬТАТ</b>\n\n"
                f"{result_text}\n\n"
                f"💰 Ставка: {format_balance(bet)}\n"
                f"🎁 Выигрыш: {format_balance(win_amount)} (x{multiplier})\n"
                f"📈 Прибыль: +{format_balance(profit)}\n"
                f"⭐ Опыт: +{exp}\n"
                f"💼 Баланс: {format_balance(user.balance)}"
                + ev_str + jp_str
            )
            if level_up:
                response += f"\n\n🎉 <b>Новый уровень: {user.level}!</b>"
        else:
            user.statistics = user.statistics or {}
            user.statistics["slots_played"] = user.statistics.get("slots_played", 0) + 1
            user.statistics["slots_losses"] = user.statistics.get("slots_losses", 0) + 1
            flag_modified(user, "statistics")
            await UserService.update_balance(session, user, 0, "slots_loss", "Проигрыш в слоты")
            response = (
                f"🎰 <b>РЕЗУЛЬТАТ</b>\n\n"
                f"{result_text}\n\n"
                f"💸 Проигрыш: -{format_balance(bet)}\n"
                f"💼 Баланс: {format_balance(user.balance)}\n\n"
                f"🍀 Попробуйте ещё раз!"
            )

        await message.answer(response, parse_mode="HTML")


# ── Casino ────────────────────────────────────────────────────────────────────

@router.message(Command("casino"))
@router.message(F.text.lower().startswith("казино"))
async def cmd_casino(message: Message):
    parts = message.text.split()

    if len(parts) < 2:
        await message.answer(
            f"🎲 <b>КАЗИНО</b>\n\n"
            f"Использование: <code>казино [ставка]</code> или <code>казино все</code>\n\n"
            f"💵 Мин. ставка: {format_balance(settings.MIN_CASINO_BET)}\n"
            f"💰 Макс. ставка: {format_balance(settings.MAX_CASINO_BET)}\n\n"
            f"<b>Множители:</b>\n"
            f"❌ x0 — полный проигрыш\n"
            f"😐 x1.25 — маленький выигрыш\n"
            f"😊 x2 — удвоение\n"
            f"😃 x5 — большой выигрыш\n"
            f"🤑 x10 — СУПЕР!",
            parse_mode="HTML"
        )
        return

    bet_all = parts[-1].lower() in ("все", "всё", "all")
    bet = 0.0
    if not bet_all:
        try:
            bet = parse_amount(parts[-1])
        except (ValueError, IndexError):
            await message.answer("❌ Укажите корректную ставку!")
            return

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, message.from_user.id,
            message.from_user.username, message.from_user.first_name
        )

        if bet_all:
            bet = user.balance
            if bet < settings.MIN_CASINO_BET:
                await message.answer(f"❌ Мин. ставка: {format_balance(settings.MIN_CASINO_BET)}")
                return

        if bet < settings.MIN_CASINO_BET:
            await message.answer(f"❌ Мин. ставка: {format_balance(settings.MIN_CASINO_BET)}")
            return
        if not bet_all and bet > settings.MAX_CASINO_BET:
            await message.answer(f"❌ Макс. ставка: {format_balance(settings.MAX_CASINO_BET)}")
            return

        nocooldown = await has_active_event(session, "nocooldown")
        if not nocooldown and user.is_cooldown_active("casino", settings.CASINO_COOLDOWN):
            await message.answer("⏳ Казино доступно каждые 5 секунд.")
            return

        if user.balance < bet:
            await message.answer(f"❌ Недостаточно средств! Баланс: {format_balance(user.balance)}")
            return

        user.balance -= bet
        user.last_casino = datetime.utcnow()

        multiplier = random.choices(settings.casino_multipliers, weights=settings.casino_weights)[0]

        if multiplier >= 1:
            win_amount = bet * multiplier
            money_mult = await get_event_multiplier(session, "money")
            luck_mult  = await get_event_multiplier(session, "luck")
            ev_mult = money_mult * luck_mult
            win_amount *= ev_mult
            user.balance += win_amount
            profit = win_amount - bet

            from sqlalchemy.orm.attributes import flag_modified
            user.statistics = user.statistics or {}
            user.statistics["casino_played"] = user.statistics.get("casino_played", 0) + 1
            user.statistics["casino_wins"]   = user.statistics.get("casino_wins",   0) + 1
            flag_modified(user, "statistics")

            exp = int(multiplier * 3)
            level_up = await UserService.add_experience(session, user, exp)
            await UserService.update_balance(session, user, 0, "casino_win", f"Казино x{multiplier}")

            emoji = "😇" if multiplier < 2 else "😃" if multiplier < 5 else "🤑"
            ev_str = f"\n🎉 Ивент x{ev_mult:.1f}!" if ev_mult != 1.0 else ""
            response = (
                f"🎲 Выигрыш {format_balance(win_amount)} (x{multiplier}) {emoji}\n\n"
                f"💼 Баланс: {format_balance(user.balance)}" + ev_str
            )
            if level_up:
                response += f"\n🎉 Новый уровень: {user.level}!"
        else:
            from sqlalchemy.orm.attributes import flag_modified
            user.statistics = user.statistics or {}
            user.statistics["casino_played"] = user.statistics.get("casino_played", 0) + 1
            user.statistics["casino_losses"] = user.statistics.get("casino_losses", 0) + 1
            flag_modified(user, "statistics")
            await UserService.update_balance(session, user, 0, "casino_loss", "Казино — проигрыш")
            response = (
                f"🎲 Проигрыш ставки! 💸😔\n"
                f"💔 Потеряно: -{format_balance(bet)}\n\n"
                f"💼 Баланс: {format_balance(user.balance)}"
            )

        await message.answer(response)


# ── Dice duel ─────────────────────────────────────────────────────────────────

@router.message(Command("dice"))
@router.message(F.text.lower().startswith("кубик"))
async def cmd_dice_game(message: Message):
    if not message.reply_to_message:
        await message.answer(
            f"🎲 <b>ИГРА В КУБИК</b>\n\n"
            f"Ответьте на сообщение игрока: <code>кубик [ставка]</code>\n\n"
            f"🎯 Правила:\n"
            f"1. Вызов принимается за 3 минуты\n"
            f"2. Оба бросают кубик 🎲\n"
            f"3. Больше = победитель забирает всё\n"
            f"4. Ничья — деньги возвращаются\n\n"
            f"💵 Мин. ставка: {format_balance(settings.MIN_CASINO_BET)}",
            parse_mode="HTML"
        )
        return

    parts = message.text.split()
    if len(parts) < 2:
        await message.answer("❌ Укажите ставку!")
        return
    try:
        bet = parse_amount(parts[-1])
    except (ValueError, IndexError):
        await message.answer("❌ Некорректная ставка!")
        return

    if bet < settings.MIN_CASINO_BET:
        await message.answer(f"❌ Мин. ставка: {format_balance(settings.MIN_CASINO_BET)}")
        return

    challenger_id = message.from_user.id
    challenged_id = message.reply_to_message.from_user.id

    if challenger_id == challenged_id:
        await message.answer("❌ Нельзя играть с самим собой!")
        return
    if challenged_id in dice_challenges:
        await message.answer("❌ У этого игрока уже есть активный вызов!")
        return

    async with get_db() as session:
        challenger = await UserService.get_or_create(
            session, challenger_id, message.from_user.username, message.from_user.first_name
        )
        if challenger.balance < bet:
            await message.answer(f"❌ Недостаточно средств! Баланс: {format_balance(challenger.balance)}")
            return

        challenged = await UserService.get_or_create(
            session, challenged_id,
            message.reply_to_message.from_user.username,
            message.reply_to_message.from_user.first_name
        )
        if challenged.balance < bet:
            await message.answer(f"❌ У противника не хватает средств! {format_balance(challenged.balance)}")
            return

        builder = InlineKeyboardBuilder()
        builder.row(
            InlineKeyboardButton(text="✅ Принять", callback_data=f"dice_accept_{challenger_id}_{bet}"),
            InlineKeyboardButton(text="❌ Отклонить", callback_data=f"dice_decline_{challenger_id}")
        )

        c_name = challenger.first_name or f"User_{challenger_id}"
        t_name = challenged.first_name or f"User_{challenged_id}"
        sent = await message.answer(
            f"🎲 <b>ВЫЗОВ НА ДУЭЛЬ!</b>\n\n"
            f"🥊 {c_name} вызывает {t_name}!\n"
            f"💰 Ставка: {format_balance(bet)}\n\n"
            f"⏰ {t_name} — 3 минуты на ответ!",
            reply_markup=builder.as_markup(), parse_mode="HTML"
        )

        dice_challenges[challenged_id] = {
            "challenger_id": challenger_id,
            "bet": bet,
            "message_id": sent.message_id,
            "timestamp": datetime.utcnow(),
            "chat_id": message.chat.id
        }
        asyncio.create_task(_auto_cancel(challenged_id, sent.message_id, message.bot, message.chat.id))


async def _auto_cancel(challenged_id, msg_id, bot, chat_id):
    await asyncio.sleep(180)
    if challenged_id in dice_challenges and dice_challenges[challenged_id]["message_id"] == msg_id:
        del dice_challenges[challenged_id]
        try:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=msg_id,
                text="⏰ <b>Время вышло!</b> Вызов отменён.", parse_mode="HTML"
            )
        except Exception:
            pass


@router.callback_query(F.data.startswith("dice_accept_"))
async def handle_dice_accept(callback: CallbackQuery):
    if callback.from_user.id not in dice_challenges:
        await callback.answer("❌ Этот вызов не для вас!", show_alert=True)
        return

    challenge = dice_challenges.pop(callback.from_user.id)
    challenger_id = challenge["challenger_id"]
    bet = challenge["bet"]

    async with get_db() as session:
        challenger = await UserService.get_by_telegram_id(session, challenger_id)
        challenged = await UserService.get_by_telegram_id(session, callback.from_user.id)

        if not challenger or not challenged or challenger.balance < bet or challenged.balance < bet:
            await callback.message.edit_text("❌ <b>Игра отменена!</b> Недостаточно средств.", parse_mode="HTML")
            await callback.answer()
            return

        challenger.balance -= bet
        challenged.balance -= bet
        await session.commit()

        c_name = challenger.first_name or f"User_{challenger_id}"
        t_name = challenged.first_name or f"User_{callback.from_user.id}"

        await callback.message.edit_text(
            f"🎲 <b>ИГРА НАЧАЛАСЬ!</b>\n\n"
            f"🥊 {c_name} VS {t_name}\n"
            f"💰 Банк: {format_balance(bet * 2)}\n\n"
            f"📢 Оба игрока — отправьте 🎲 в чат!",
            parse_mode="HTML"
        )

        dice_challenges[f"game_{challenger_id}_{callback.from_user.id}"] = {
            "challenger_id": challenger_id,
            "challenged_id": callback.from_user.id,
            "bet": bet,
            "challenger_roll": None,
            "challenged_roll": None,
            "timestamp": datetime.utcnow()
        }

    await callback.answer("✅ Принято! Бросайте 🎲", show_alert=True)


@router.callback_query(F.data.startswith("dice_decline_"))
async def handle_dice_decline(callback: CallbackQuery):
    if callback.from_user.id not in dice_challenges:
        await callback.answer("❌ Этот вызов не для вас!", show_alert=True)
        return
    dice_challenges.pop(callback.from_user.id, None)
    await callback.message.edit_text("❌ <b>Вызов отклонён!</b>", parse_mode="HTML")
    await callback.answer("Вы отклонили вызов")


@router.message(F.dice)
async def handle_dice_roll(message: Message):
    user_id = message.from_user.id
    active_game = None
    game_key = None

    for key, game in dice_challenges.items():
        if key.startswith("game_") and (game["challenger_id"] == user_id or game["challenged_id"] == user_id):
            active_game = game
            game_key = key
            break

    if not active_game:
        return

    dice_value = message.dice.value

    if user_id == active_game["challenger_id"]:
        if active_game["challenger_roll"] is not None:
            await message.answer("❌ Вы уже бросали кубик!")
            return
        active_game["challenger_roll"] = dice_value
    elif user_id == active_game["challenged_id"]:
        if active_game["challenged_roll"] is not None:
            await message.answer("❌ Вы уже бросали кубик!")
            return
        active_game["challenged_roll"] = dice_value

    if active_game["challenger_roll"] is not None and active_game["challenged_roll"] is not None:
        await asyncio.sleep(4)
        cr = active_game["challenger_roll"]
        tr = active_game["challenged_roll"]
        bet = active_game["bet"]

        async with get_db() as session:
            challenger = await UserService.get_by_telegram_id(session, active_game["challenger_id"])
            challenged = await UserService.get_by_telegram_id(session, active_game["challenged_id"])
            c_name = challenger.first_name or f"User_{challenger.telegram_id}"
            t_name = challenged.first_name or f"User_{challenged.telegram_id}"

            res = (
                f"🎲 <b>РЕЗУЛЬТАТЫ</b>\n\n"
                f"🎯 {c_name}: {cr}\n"
                f"🎯 {t_name}: {tr}\n\n"
            )

            if cr > tr:
                challenger.balance += bet * 2
                res += f"🏆 <b>Победитель: {c_name}!</b>\n💰 Выигрыш: {format_balance(bet*2)}"
                await UserService.add_experience(session, challenger, 20)
            elif tr > cr:
                challenged.balance += bet * 2
                res += f"🏆 <b>Победитель: {t_name}!</b>\n💰 Выигрыш: {format_balance(bet*2)}"
                await UserService.add_experience(session, challenged, 20)
            else:
                challenger.balance += bet
                challenged.balance += bet
                res += f"🤝 <b>НИЧЬЯ!</b>\nСтавки возвращены."

            await session.commit()

        await message.answer(res, parse_mode="HTML")
        dice_challenges.pop(game_key, None)
