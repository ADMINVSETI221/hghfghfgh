"""
Basic command handlers for the bot
"""
import random
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import settings
from services.database import get_db, UserService
from services.event_service import get_event_multiplier, has_active_event
from utils.formatters import format_balance, format_time, parse_amount, fmt_bal, BALANCE_FORMATS


router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    """Handle /start command"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        welcome_text = (
            f"👋 Добро пожаловать, {message.from_user.first_name}!\n\n"
            f"💰 Ваш стартовый баланс: {fmt_bal(user)}\n"
            f"⭐ Уровень: {user.level}\n\n"
            f"🎮 Используйте команды для игры:\n"
            f"💼 раб — работать\n"
            f"⛏ майн — майнинг\n"
            f"🎁 дейли — ежедневный бонус\n"
            f"🎰 слоты [ставка] — игровые автоматы\n"
            f"💹 рынок — криптовалютный рынок\n"
            f"🏭 фермы — майнинг-фермы крипты\n"
            f"👤 профиль — ваш профиль\n"
            f"📋 помощь — все команды"
        )
        
        await message.answer(welcome_text)


@router.message(Command("help"))
@router.message(F.text.lower() == "помощь")
async def cmd_help(message: Message):
    """Show help message"""
    help_text = """
🎮 <b>КОМАНДЫ БОТА</b>

💰 <b>Экономика:</b>
💼 раб / работать — Заработать (5 мин кд)
⛏ майн — Майнинг (10 мин кд)
🎁 дейли — Ежедневный бонус (24ч)
💸 перевод [reply] [сумма] — Перевести деньги

🎯 <b>Игры:</b>
🎰 слоты [ставка] — Слоты (x2 до x100)
🎲 казино [ставка / все] — Казино
🎲 кубик [reply] [ставка] — Дуэль на кубиках

👤 <b>Профиль:</b>
профиль / п — Ваш профиль
🏆 топ — Рейтинги игроков
🧠 псих — Психиатр (4ч)

🏢 <b>Бизнес:</b>
бизнес — Мои бизнесы
собрать — Собрать прибыль

💹 <b>Криптовалюта:</b>
рынок — Крипто-рынок (11 монет)
курс [символ] — График + детали (напр. курс BTC)
купить крипту [символ] [сумма] — Купить крипту
продать крипту [символ] [кол-во / все] — Продать
кошелёк — Ваш крипто-портфель
топ крипто — Топ по портфелю

🏭 <b>Майнинг-фермы:</b>
фермы — Мои фермы
фермы магазин — Купить ферму
собрать крипту — Собрать намайненную крипту

🏪 <b>Магазин:</b>
магазин — Предметы (15 видов)
купить [название] — Купить предмет
инвентарь — Ваши предметы

🎴 <b>Прочее:</b>
карточки — Коллекция
ивенты — Активные ивенты
донат — Поддержать (1 ⭐ = 15 000 монет)
"""
    await message.answer(help_text, parse_mode="HTML")


@router.message(Command("balance", "bal", "b"))
@router.message(F.text.lower().in_(["баланс", "бал"]))
async def cmd_balance(message: Message):
    """Show user balance"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        text = (
            f"💰 <b>Ваш баланс:</b>\n\n"
            f"💵 Деньги: {fmt_bal(user)}\n"
            f"⭐ Уровень: {user.level} (опыт: {user.experience})"
        )
        
        await message.answer(text, parse_mode="HTML")


@router.message(Command("work", "w"))
@router.message(F.text.lower().in_(["раб", "работать", "работа"]))
async def cmd_work(message: Message):
    """Work command to earn money"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        # Check cooldown
        nocooldown_active = await has_active_event(session, "nocooldown")
        if not nocooldown_active and user.is_cooldown_active("work", settings.WORK_COOLDOWN):
            remaining = user.get_cooldown_remaining("work", settings.WORK_COOLDOWN)
            await message.answer(
                f"⏳ Вы уже работали недавно!\n"
                f"⏰ Попробуйте через: {format_time(remaining)}"
            )
            return
        
        # Calculate earnings
        base_amount = random.randint(50, 150)
        level_bonus = user.level * 5
        total_amount = base_amount + level_bonus
        
        # Apply card bonus
        from handlers.cards import get_card_bonus
        card_bonus = get_card_bonus(user.inventory or {})
        if card_bonus > 0:
            total_amount = int(total_amount * (1 + card_bonus))
        
        # Apply money event
        money_mult = await get_event_multiplier(session, "money")
        if money_mult != 1.0:
            total_amount = int(total_amount * money_mult)
        
        # Update balance
        user, _ = await UserService.update_balance(
            session, user, total_amount, "work", "Заработок на работе"
        )
        user.last_work = datetime.utcnow()
        
        # Add experience (with event multiplier + exp_boost item)
        exp_mult = await get_event_multiplier(session, "exp")
        # Check exp_boost item
        inv = user.inventory or {}
        exp_boost_active = False
        if "experience_boost" in inv:
            until_str = inv["experience_boost"].get("exp_boost_until")
            if until_str:
                try:
                    until_dt = datetime.fromisoformat(until_str)
                    if datetime.utcnow() < until_dt:
                        exp_mult *= 2.0
                        exp_boost_active = True
                except Exception:
                    pass
        exp_gained = int(random.randint(10, 30) * exp_mult)
        level_up = await UserService.add_experience(session, user, exp_gained)
        
        # Update statistics - use flag_modified for JSON fields
        from sqlalchemy.orm.attributes import flag_modified
        user.statistics["work_count"] = user.statistics.get("work_count", 0) + 1
        flag_modified(user, "statistics")
        await session.commit()
        await session.refresh(user)
        
        # Try to give a card (5% chance)
        from handlers.cards import try_give_card
        card_drop, card_level_up = await try_give_card(session, user, "work")
        if card_level_up:
            level_up = True
        
        needed_xp = user.level * 100
        event_info = f"\n🎉 <b>Ивент x{money_mult:.1f}!</b>" if money_mult != 1.0 else ""
        card_info = ""
        if card_drop:
            from models.database import BUSINESSES
            from handlers.cards import CARD_RARITIES
            _, cname, crarity = card_drop[0], card_drop[1], card_drop[2]
            rinfo = CARD_RARITIES.get(crarity, CARD_RARITIES["common"])
            card_info = f"\n\n🎴 <b>Выпала карточка!</b> {rinfo['color']} {cname} (+{rinfo['bonus_pct']*100:.0f}% к доходу)"
        response = (
            f"💼 <b>Работа выполнена!</b>\n\n"
            f"💰 Заработано: +{format_balance(total_amount)}\n"
            f"⭐ Опыт: +{exp_gained}  [{user.experience}/{needed_xp} XP]\n"
            f"💵 Баланс: {fmt_bal(user)}"
            + event_info + card_info
        )
        
        if level_up:
            response += f"\n\n🎉 <b>Поздравляем! Новый уровень: {user.level}</b>"
        
        await message.answer(response, parse_mode="HTML")


@router.message(Command("mine", "m"))
@router.message(F.text.lower().in_(["майн", "майнинг", "шахта"]))
async def cmd_mine(message: Message):
    """Mining command to earn money"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        # Check cooldown
        nocooldown_active = await has_active_event(session, "nocooldown")
        if not nocooldown_active and user.is_cooldown_active("mine", settings.MINE_COOLDOWN):
            remaining = user.get_cooldown_remaining("mine", settings.MINE_COOLDOWN)
            await message.answer(
                f"⏳ Майнинг уже идет!\n"
                f"⏰ Попробуйте через: {format_time(remaining)}"
            )
            return
        
        # Calculate earnings
        base_amount = random.randint(100, 300)
        level_bonus = user.level * 10
        total_amount = base_amount + level_bonus
        
        # Apply money event
        money_mult = await get_event_multiplier(session, "money")
        if money_mult != 1.0:
            total_amount = int(total_amount * money_mult)
        
        # Update balance
        user, _ = await UserService.update_balance(
            session, user, total_amount, "mine", "Майнинг криптовалюты"
        )
        user.last_mine = datetime.utcnow()
        
        # Add experience (with event multiplier)
        exp_mult = await get_event_multiplier(session, "exp")
        exp_gained = int(random.randint(20, 50) * exp_mult)
        level_up = await UserService.add_experience(session, user, exp_gained)
        
        # Update statistics
        from sqlalchemy.orm.attributes import flag_modified
        user.statistics["mine_count"] = user.statistics.get("mine_count", 0) + 1
        flag_modified(user, "statistics")
        await session.commit()
        await session.refresh(user)
        
        event_info = f"\n🎉 <b>Ивент x{money_mult:.1f}!</b>" if money_mult != 1.0 else ""
        
        # Try card drop
        from handlers.cards import try_give_card, CARD_RARITIES
        card_drop, card_level_up = await try_give_card(session, user, "mine")
        if card_level_up:
            level_up = True
        
        needed_xp = user.level * 100
        card_info = ""
        if card_drop:
            _, cname, crarity = card_drop[0], card_drop[1], card_drop[2]
            rinfo = CARD_RARITIES.get(crarity, CARD_RARITIES["common"])
            card_info = f"\n\n🎴 <b>Выпала карточка!</b> {rinfo['color']} {cname} (+{rinfo['bonus_pct']*100:.0f}% к доходу)"
        
        response = (
            f"⛏ <b>Майнинг завершен!</b>\n\n"
            f"💰 Намайнено: +{format_balance(total_amount)}\n"
            f"⭐ Опыт: +{exp_gained}  [{user.experience}/{needed_xp} XP]\n"
            f"💵 Баланс: {fmt_bal(user)}"
            + event_info + card_info
        )
        
        if level_up:
            response += f"\n\n🎉 <b>Поздравляем! Новый уровень: {user.level}</b>"
        
        await message.answer(response, parse_mode="HTML")


@router.message(Command("daily"))
@router.message(F.text.lower().in_(["дейли", "ежедневный"]))
async def cmd_daily(message: Message):
    """Daily bonus command"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        # Check cooldown
        if user.is_cooldown_active("daily", settings.DAILY_COOLDOWN):
            remaining = user.get_cooldown_remaining("daily", settings.DAILY_COOLDOWN)
            await message.answer(
                f"⏳ Ежедневный бонус уже получен!\n"
                f"⏰ Следующий через: {format_time(remaining)}"
            )
            return
        
        # Calculate bonus
        base_bonus = 500
        level_bonus = user.level * 50
        total_bonus = base_bonus + level_bonus
        
        # Update balance
        user, _ = await UserService.update_balance(
            session, user, total_bonus, "daily", "Ежедневный бонус"
        )
        user.last_daily = datetime.utcnow()
        
        await message.answer(
            f"🎁 <b>Ежедневный бонус получен!</b>\n\n"
            f"💰 Получено: +{format_balance(total_bonus)}\n"
            f"💵 Баланс: {fmt_bal(user)}\n\n"
            f"⏰ Следующий бонус через 24 часа",
            parse_mode="HTML"
        )


@router.message(Command("psychiatrist"))
@router.message(F.text.lower().in_(["псих", "психиатр"]))
async def cmd_psychiatrist(message: Message):
    """Psychiatrist mark command"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        # Check cooldown
        if user.is_cooldown_active("psychiatrist", settings.PSYCHIATRIST_COOLDOWN):
            remaining = user.get_cooldown_remaining("psychiatrist", settings.PSYCHIATRIST_COOLDOWN)
            await message.answer(
                f"⏳ Вы уже были у психиатра!\n"
                f"⏰ Следующая отметка через: {format_time(remaining)}"
            )
            return
        
        # Update psychiatrist marks
        from sqlalchemy.orm.attributes import flag_modified
        user.last_psychiatrist = datetime.utcnow()
        user.statistics["psychiatrist_marks"] = user.statistics.get("psychiatrist_marks", 0) + 1
        flag_modified(user, "statistics")
        await session.commit()
        await session.refresh(user)
        
        marks = user.statistics["psychiatrist_marks"]
        
        await message.answer(
            f"🧠 <b>Психиатр</b>\n\n"
            f"✅ Отметка получена!\n"
            f"📊 Всего отметок: {marks}\n\n"
            f"⏰ Следующая отметка через 4 часа",
            parse_mode="HTML"
        )


@router.message(Command("top"))
@router.message(F.text.lower() == "топ")
async def cmd_top(message: Message):
    """Show leaderboards with buttons"""
    await show_top(message, "balance")


@router.callback_query(F.data.startswith("top_"))
async def handle_top_callback(callback: CallbackQuery):
    """Handle top category selection"""
    category = callback.data.split("_")[1]
    await show_top(callback.message, category, edit=True)
    await callback.answer()


async def show_top(message: Message, category: str, edit: bool = False):
    """Show leaderboard for specific category"""
    async with get_db() as session:
        if category == "balance":
            users = await UserService.get_top_by_balance(session, 10)
            title = "💰 ТОП ПО БАЛАНСУ"
            format_func = lambda u: format_balance(u.balance)
        elif category == "level":
            users = await UserService.get_top_by_level(session, 10)
            title = "⭐ ТОП ПО УРОВНЮ"
            format_func = lambda u: f"Уровень {u.level} (опыт: {u.experience})"
        else:  # psychiatrist
            users = await UserService.get_top_by_psychiatrist(session, 10)
            title = "🧠 ТОП ПО ПСИХИАТРУ"
            format_func = lambda u: f"{u.statistics.get('psychiatrist_marks', 0)} отметок"
        
        # Filter out admins and owner
        excluded_ids = settings.all_admin_ids
        users = [u for u in users if u.telegram_id not in excluded_ids]
        
        text = f"<b>{title}</b>\n\n"
        
        for i, user in enumerate(users[:10], 1):  # Limit to top 10 after filtering
            emoji = ["🥇", "🥈", "🥉"][i-1] if i <= 3 else f"{i}."
            # Create clickable username link
            if user.username:
                username_link = f'<a href="tg://user?id={user.telegram_id}">@{user.username}</a>'
            else:
                display_name = user.first_name or f"User_{user.telegram_id}"
                username_link = f'<a href="tg://user?id={user.telegram_id}">{display_name}</a>'
            text += f"{emoji} {username_link} - {format_func(user)}\n"
        
        if not users:
            text += "Пока нет данных"
        
        # Create inline keyboard
        builder = InlineKeyboardBuilder()
        builder.button(text="💰 Баланс", callback_data="top_balance")
        builder.button(text="⭐ Уровень", callback_data="top_level")
        builder.button(text="🧠 Психиатр", callback_data="top_psychiatrist")
        builder.adjust(3)
        
        if edit:
            await message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())
        else:
            await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())


@router.message(Command("profile"))
@router.message(F.text.lower().in_(["профиль", "п"]))
async def cmd_profile(message: Message):
    """Show user profile"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        stats = user.statistics
        
        # Проверка VIP статуса
        vip_status = ""
        if user.vip_until and datetime.utcnow() < user.vip_until:
            time_left = user.vip_until - datetime.utcnow()
            days = time_left.days
            hours = time_left.seconds // 3600
            minutes = (time_left.seconds % 3600) // 60
            
            if days > 0:
                vip_time = f"{days}д {hours}ч {minutes}м"
            elif hours > 0:
                vip_time = f"{hours}ч {minutes}м"
            else:
                vip_time = f"{minutes}м"
            
            vip_status = f"\n👑 VIP статус: <b>Активен</b>\n⏰ Осталось: {vip_time}\n"
        else:
            vip_status = "\n👑 VIP статус: <b>Неактивен</b>\n"
        
        from math import floor
        needed_xp = user.level * 100
        bar_filled = floor(user.experience / needed_xp * 10)
        xp_bar = "█" * bar_filled + "░" * (10 - bar_filled)
        biz_bonus_pct = (user.level - 1)  # +1% per level
        work_bonus = user.level * 5
        
        profile_text = (
            f"👤 <b>ПРОФИЛЬ</b>\n\n"
            f"🆔 ID: {user.telegram_id}\n"
            f"👤 Имя: {user.first_name or 'Не указано'}\n"
            f"📱 Username: @{user.username or 'Нет'}\n"
            f"{vip_status}\n"
            f"💰 <b>Баланс:</b>\n"
            f"💵 Деньги: {fmt_bal(user)}\n\n"
            f"⭐ <b>Прогресс:</b>\n"
            f"🏅 Уровень: {user.level}\n"
            f"📊 Опыт: [{xp_bar}] {user.experience}/{needed_xp} XP\n"
            f"🎁 Бонусы уровня:\n"
            f"  • +{work_bonus}₽ к работе\n"
            f"  • +{biz_bonus_pct}% к доходу бизнесов\n\n"
            f"📈 <b>Статистика:</b>\n"
            f"💼 Работ выполнено: {stats.get('work_count', 0)}\n"
            f"⛏ Майнинг: {stats.get('mine_count', 0)}\n"
            f"🧠 Отметок психиатра: {stats.get('psychiatrist_marks', 0)}\n"
            f"🎰 Игр в слоты: {stats.get('slots_played', 0)}\n"
            f"🎲 Игр в казино: {stats.get('casino_played', 0)}\n"
            f"💰 Всего заработано: {format_balance(stats.get('total_earned', 0))}\n"
            f"💸 Всего потрачено: {format_balance(stats.get('total_spent', 0))}"
        )
        
        await message.answer(profile_text, parse_mode="HTML")


@router.message(Command("transfer", "send"))
@router.message(F.text.lower().startswith("перевод"))
async def cmd_transfer(message: Message):
    """Transfer money to another user (reply-based)"""
    # Check if this is a reply
    if not message.reply_to_message:
        await message.answer(
            "❌ Ответьте на сообщение пользователя, которому хотите перевести деньги!\n\n"
            "Использование: Ответьте на сообщение и напишите: перевод [сумма]"
        )
        return
    
    # Parse amount
    try:
        text_parts = message.text.split()
        if len(text_parts) < 2:
            await message.answer("❌ Укажите сумму перевода!")
            return
        
        amount = parse_amount(text_parts[-1])
    except (ValueError, IndexError):
        await message.answer("❌ Укажите корректную сумму!")
        return
    
    if amount <= 0:
        await message.answer("❌ Сумма должна быть положительной!")
        return
    
    recipient_id = message.reply_to_message.from_user.id
    sender_id = message.from_user.id
    
    if recipient_id == sender_id:
        await message.answer("❌ Нельзя переводить деньги самому себе!")
        return
    
    async with get_db() as session:
        sender = await UserService.get_or_create(
            session, sender_id, message.from_user.username, message.from_user.first_name
        )
        
        if sender.balance < amount:
            await message.answer(
                f"❌ Недостаточно средств!\n"
                f"Ваш баланс: {format_balance(sender.balance)}"
            )
            return
        
        recipient = await UserService.get_or_create(
            session, 
            recipient_id, 
            message.reply_to_message.from_user.username,
            message.reply_to_message.from_user.first_name
        )
        
        # Calculate tax (check tax_shield)
        from sqlalchemy.orm.attributes import flag_modified as _fm
        sender_inv = sender.inventory or {}
        tax_free = False
        if "tax_shield" in sender_inv:
            shield = sender_inv["tax_shield"]
            shield_until_str = shield.get("tax_shield_until")
            if shield_until_str:
                try:
                    from datetime import datetime as _dt
                    shield_until = _dt.fromisoformat(shield_until_str)
                    if _dt.utcnow() < shield_until:
                        tax_free = True
                except Exception:
                    pass

        tax = 0 if tax_free else amount * settings.TAX_RATE
        amount_after_tax = amount - tax
        
        # Transfer money
        await UserService.update_balance(
            session, sender, -amount, "transfer_sent",
            f"Перевод пользователю {recipient.telegram_id}"
        )
        await UserService.update_balance(
            session, recipient, amount_after_tax, "transfer_received",
            f"Получено от пользователя {sender.telegram_id}"
        )
        
        recipient_name = recipient.username or recipient.first_name or f"User_{recipient.telegram_id}"
        tax_line = "🛡 Комиссия: 0 (Налоговый щит!)" if tax_free else f"📉 Комиссия ({settings.TAX_RATE*100:.0f}%): {format_balance(tax)}"
        
        await message.answer(
            f"✅ <b>Перевод выполнен!</b>\n\n"
            f"👤 Получатель: {recipient_name}\n"
            f"💸 Сумма: {format_balance(amount)}\n"
            f"{tax_line}\n"
            f"💰 Получено: {format_balance(amount_after_tax)}\n"
            f"💵 Ваш баланс: {format_balance(sender.balance)}",
            parse_mode="HTML"
        )


@router.message(Command("luckyblock", "lb"))
@router.message(F.text.lower().in_(["лаки", "лакиблок", "удача"]))
async def cmd_lucky_block(message: Message):
    """Lucky block - random reward every 12 hours"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        # Проверяем кулдаун 12 часов (43200 секунд)
        cooldown_seconds = 43200
        if user.is_cooldown_active("lucky_block", cooldown_seconds):
            remaining = user.get_cooldown_remaining("lucky_block", cooldown_seconds)
            hours = remaining // 3600
            minutes = (remaining % 3600) // 60
            await message.answer(
                f"⏳ <b>Лаки Блок</b>\n\n"
                f"Вы уже использовали лаки блок!\n"
                f"⏰ Следующий блок через: {hours}ч {minutes}м",
                parse_mode="HTML"
            )
            return
        
        # Обновляем время последнего использования
        user.last_lucky_block = datetime.utcnow()
        
        # Определяем награду (с весами)
        reward_types = [
            "coins_small",      # 30% - малая сумма монет
            "coins_medium",     # 25% - средняя сумма монет
            "coins_large",      # 15% - большая сумма монет
            "coins_jackpot",    # 5% - джекпот
            "vip_1day",         # 10% - VIP 1 день
            "vip_3days",        # 5% - VIP 3 дня
            "vip_7days",        # 3% - VIP 7 дней
            "event_personal",   # 5% - личный ивент
            "event_global",     # 2% - глобальный ивент
        ]
        
        weights = [30, 25, 15, 5, 10, 5, 3, 5, 2]
        
        reward_type = random.choices(reward_types, weights=weights)[0]
        
        reward_text = ""
        
        if reward_type == "coins_small":
            amount = random.randint(1000, 5000)
            user.balance += amount
            reward_text = f"💰 Монеты: +{format_balance(amount)}"
            await UserService.update_balance(session, user, 0, "lucky_block", f"Лаки блок: {format_balance(amount)}")
            
        elif reward_type == "coins_medium":
            amount = random.randint(5000, 20000)
            user.balance += amount
            reward_text = f"💰 Монеты: +{format_balance(amount)}"
            await UserService.update_balance(session, user, 0, "lucky_block", f"Лаки блок: {format_balance(amount)}")
            
        elif reward_type == "coins_large":
            amount = random.randint(20000, 100000)
            user.balance += amount
            reward_text = f"💰💰 Крупный выигрыш: +{format_balance(amount)}"
            await UserService.update_balance(session, user, 0, "lucky_block", f"Лаки блок (крупный): {format_balance(amount)}")
            
        elif reward_type == "coins_jackpot":
            amount = random.randint(100000, 1000000)
            user.balance += amount
            reward_text = f"💎💎💎 ДЖЕКПОТ: +{format_balance(amount)}"
            await UserService.update_balance(session, user, 0, "lucky_block", f"Лаки блок (ДЖЕКПОТ): {format_balance(amount)}")
            
        elif reward_type == "vip_1day":
            from datetime import timedelta
            if user.vip_until and user.vip_until > datetime.utcnow():
                user.vip_until += timedelta(days=1)
            else:
                user.vip_until = datetime.utcnow() + timedelta(days=1)
            reward_text = "👑 VIP статус на 1 день!"
            
        elif reward_type == "vip_3days":
            from datetime import timedelta
            if user.vip_until and user.vip_until > datetime.utcnow():
                user.vip_until += timedelta(days=3)
            else:
                user.vip_until = datetime.utcnow() + timedelta(days=3)
            reward_text = "👑👑 VIP статус на 3 дня!"
            
        elif reward_type == "vip_7days":
            from datetime import timedelta
            if user.vip_until and user.vip_until > datetime.utcnow():
                user.vip_until += timedelta(days=7)
            else:
                user.vip_until = datetime.utcnow() + timedelta(days=7)
            reward_text = "👑👑👑 VIP статус на 7 дней!"
            
        elif reward_type == "event_personal":
            # Личный ивент - убираем кулдауны на 1 час
            from datetime import timedelta
            user.vip_until = datetime.utcnow() + timedelta(hours=1)
            reward_text = "🎉 Личный ивент: Без кулдаунов 1 час!"
            
        elif reward_type == "event_global":
            # Глобальный ивент - создаем событие на 30 минут для всех
            from models.database import GlobalEvent
            from datetime import timedelta
            
            event = GlobalEvent(
                event_type="lucky_block_bonus",
                multiplier=2.0,
                is_active=True,
                starts_at=datetime.utcnow(),
                ends_at=datetime.utcnow() + timedelta(minutes=30),
                created_by=user.telegram_id,
                description="Глобальный бонус x2 к доходу (из лаки блока)"
            )
            session.add(event)
            
            reward_text = "🌟🌟🌟 ГЛОБАЛЬНЫЙ ИВЕНТ! x2 доход для ВСЕХ на 30 минут!"
            
            # Отправляем уведомление всем
            try:
                all_users = await UserService.get_all_users(session)
                for u in all_users:
                    if u.telegram_id != user.telegram_id and not u.is_banned:
                        try:
                            await message.bot.send_message(
                                u.telegram_id,
                                f"🌟 <b>ГЛОБАЛЬНЫЙ ИВЕНТ!</b>\n\n"
                                f"Игрок {user.first_name} активировал глобальный бонус из лаки блока!\n"
                                f"🎁 x2 к доходу от бизнесов на 30 минут!",
                                parse_mode="HTML"
                            )
                        except:
                            pass
            except:
                pass
        
        await session.commit()
        await session.refresh(user)
        
        response = (
            f"🎁 <b>ЛАКИ БЛОК!</b>\n\n"
            f"🎊 Вы открыли лаки блок и получили:\n"
            f"{reward_text}\n\n"
            f"💼 Баланс: {fmt_bal(user)}\n"
            f"⏰ Следующий блок через 12 часов!"
        )
        
        await message.answer(response, parse_mode="HTML")


@router.message(Command("events"))
@router.message(F.text.lower().in_(["ивенты", "ивент", "события"]))
async def cmd_events(message: Message):
    """Show active global events."""
    from services.event_service import get_active_events
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        events = await get_active_events(session)
        # Deactivate expired events
        from sqlalchemy.orm.attributes import flag_modified as fm
        from models.database import GlobalEvent
        now = datetime.utcnow()
        for ev in events:
            if ev.ends_at < now:
                ev.is_active = False
        await session.commit()
        events = [e for e in events if e.is_active and e.ends_at > now]

        if not events:
            await message.answer(
                "📅 <b>АКТИВНЫЕ ИВЕНТЫ</b>\n\n"
                "Сейчас активных ивентов нет.\n\n"
                "Ивенты запускаются администраторами и дают бонусы:\n"
                "💰 <b>money</b> — множитель дохода\n"
                "🎯 <b>exp</b> — множитель опыта\n"
                "⏰ <b>nocooldown</b> — снятие кулдаунов",
                parse_mode="HTML"
            )
            return

        text = "📅 <b>АКТИВНЫЕ ИВЕНТЫ</b>\n\n"
        event_icons = {
            "money": "💰",
            "exp": "⭐",
            "nocooldown": "⚡",
            "lucky_block_bonus": "🎁",
        }
        for ev in events:
            icon = event_icons.get(ev.event_type, "🎉")
            time_left = ev.ends_at - now
            hours = int(time_left.total_seconds() // 3600)
            mins = int((time_left.total_seconds() % 3600) // 60)
            time_str = f"{hours}ч {mins}м" if hours > 0 else f"{mins}м"
            text += (
                f"{icon} <b>{ev.event_type.upper()}</b>  x{ev.multiplier:.1f}\n"
                f"  📝 {ev.description or 'Специальный ивент'}\n"
                f"  ⏰ Осталось: {time_str}\n\n"
            )
        await message.answer(text, parse_mode="HTML")


# ── Настройка формата баланса ──────────────────────────────────────────────────

@router.message(Command("balformat", "formatbal", "форматбаланса"))
@router.message(F.text.lower().in_(["формат баланса", "форматбаланса", "форматбал"]))
async def cmd_balance_format(message: Message):
    """Выбор формата отображения баланса"""
    builder = InlineKeyboardBuilder()
    for key, label in BALANCE_FORMATS.items():
        builder.button(text=label, callback_data=f"balformat:{key}")
    builder.adjust(1)

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        current_fmt = (user.statistics or {}).get("balance_format", "smart")
        current_label = BALANCE_FORMATS.get(current_fmt, "Умный")

    # Preview all formats
    example = 1_234_567_890.50
    lines = "\n".join(
        f"{'✅' if k == current_fmt else '▪️'} {BALANCE_FORMATS[k]}\n   Пример: <code>{format_balance(example, k)}</code>"
        for k in BALANCE_FORMATS
    )

    await message.answer(
        f"💱 <b>ФОРМАТ ОТОБРАЖЕНИЯ БАЛАНСА</b>\n\n"
        f"Текущий: <b>{current_label}</b>\n\n"
        f"{lines}\n\n"
        f"Выберите формат:",
        parse_mode="HTML",
        reply_markup=builder.as_markup()
    )


@router.callback_query(F.data.startswith("balformat:"))
async def cb_balance_format(callback: CallbackQuery):
    """Handle balance format selection"""
    from sqlalchemy.orm.attributes import flag_modified
    fmt = callback.data.split(":")[1]

    if fmt not in BALANCE_FORMATS:
        await callback.answer("❌ Неверный формат!", show_alert=True)
        return

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        stats = user.statistics or {}
        stats["balance_format"] = fmt
        user.statistics = stats
        flag_modified(user, "statistics")
        await session.commit()
        await session.refresh(user)

        preview = fmt_bal(user)

    label = BALANCE_FORMATS[fmt]
    await callback.message.edit_text(
        f"✅ <b>Формат баланса изменён!</b>\n\n"
        f"Выбрано: <b>{label}</b>\n\n"
        f"Ваш баланс теперь: <b>{preview}</b>\n\n"
        f"Используйте /balformat чтобы изменить снова.",
        parse_mode="HTML"
    )
    await callback.answer("✅ Сохранено!")
