"""
Mining farm handlers
"""
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm.attributes import flag_modified

from services.database import get_db, UserService
from services.crypto_service import (
    get_price, seed_crypto_prices, farm_hourly_rate,
    farm_upgrade_cost, calc_farm_pending, _fmt_amount, _fmt_price
)
from models.database import MINING_FARMS

router = Router()


def _farm_list_text(user) -> str:
    farms = user.mining_farms or {}
    if not farms:
        return "🏭 У вас нет майнинг-ферм.\n\nИспользуйте <code>фермы магазин</code> для покупки."
    lines = []
    for fid, data in farms.items():
        cfg = MINING_FARMS.get(fid)
        if not cfg:
            continue
        lvl = data.get("level", 1)
        rate = farm_hourly_rate(cfg, lvl)
        pending = calc_farm_pending(data, cfg)
        lines.append(
            f"{cfg['name']} [ур. {lvl}]\n"
            f"  Добыча: {_fmt_amount(rate)}/ч {cfg['crypto']}\n"
            f"  Накоплено: {_fmt_amount(pending)} {cfg['crypto']}"
        )
    return "🏭 <b>МАЙНИНГ-ФЕРМЫ</b>\n\n" + "\n\n".join(lines)


# ── Show farms ────────────────────────────────────────────────────────────────

@router.message(F.text.lower().in_(["фермы", "майнинг фермы", "мои фермы"]))
@router.message(Command("farms"))
async def cmd_my_farms(message: Message):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, message.from_user.id,
            message.from_user.username, message.from_user.first_name
        )
        text = _farm_list_text(user)
        kb = InlineKeyboardBuilder()
        kb.button(text="⛏ Собрать всё",    callback_data="farm:collect_all")
        kb.button(text="🛒 Магазин ферм",   callback_data="farm:shop:0")
        kb.button(text="⬆️ Прокачать ферму", callback_data="farm:upgrade_menu")
        kb.adjust(1)
        await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())


# ── Shop ──────────────────────────────────────────────────────────────────────

@router.message(F.text.lower().in_(["фермы магазин", "купить ферму", "магазин ферм"]))
@router.callback_query(F.data.startswith("farm:shop:"))
async def cmd_farm_shop(event):
    message = event if isinstance(event, Message) else event.message
    uid = event.from_user.id
    username = event.from_user.username
    first_name = event.from_user.first_name

    async with get_db() as session:
        await seed_crypto_prices(session)
        user = await UserService.get_or_create(session, uid, username, first_name)
        owned = user.mining_farms or {}

        text = "🛒 <b>МАГАЗИН МАЙНИНГ-ФЕРМ</b>\n\n"
        kb = InlineKeyboardBuilder()

        for fid, cfg in MINING_FARMS.items():
            status = "✅ Есть" if fid in owned else f"💰 {cfg['buy_price']:,}$"
            text += (
                f"{cfg['name']}\n"
                f"  Майнит: <b>{cfg['crypto']}</b>\n"
                f"  Базовая добыча: {_fmt_amount(cfg['base_hourly_rate'])}/ч\n"
                f"  Цена: {cfg['buy_price']:,}$  {status}\n\n"
            )
            if fid not in owned:
                kb.button(text=f"Купить {cfg['name']}", callback_data=f"farm:buy:{fid}")

        kb.button(text="◀️ Мои фермы", callback_data="farm:my")
        kb.adjust(1)

        if isinstance(event, Message):
            await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())
        else:
            try:
                await message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
            except Exception:
                pass
            await event.answer()


@router.callback_query(F.data == "farm:my")
async def cb_farm_my(callback: CallbackQuery):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, callback.from_user.id,
            callback.from_user.username, callback.from_user.first_name
        )
        text = _farm_list_text(user)
        kb = InlineKeyboardBuilder()
        kb.button(text="⛏ Собрать всё",    callback_data="farm:collect_all")
        kb.button(text="🛒 Магазин ферм",   callback_data="farm:shop:0")
        kb.button(text="⬆️ Прокачать ферму", callback_data="farm:upgrade_menu")
        kb.adjust(1)
        try:
            await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
        except Exception:
            pass
    await callback.answer()


# ── Buy farm ──────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("farm:buy:"))
async def cb_buy_farm(callback: CallbackQuery):
    fid = callback.data.split(":")[2]
    cfg = MINING_FARMS.get(fid)
    if not cfg:
        await callback.answer("Ферма не найдена", show_alert=True)
        return

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, callback.from_user.id,
            callback.from_user.username, callback.from_user.first_name
        )

        owned = user.mining_farms or {}
        if fid in owned:
            await callback.answer("У вас уже есть эта ферма!", show_alert=True)
            return

        price = cfg["buy_price"]
        if user.balance < price:
            await callback.answer(
                f"❌ Нужно {price:,}$, у вас {user.balance:,.2f}$",
                show_alert=True
            )
            return

        user, _ = await UserService.update_balance(
            session, user, -price, "farm_buy", f"Покупка {cfg['name']}"
        )

        owned[fid] = {"level": 1, "last_collect": datetime.utcnow().isoformat()}
        user.mining_farms = owned
        flag_modified(user, "mining_farms")
        await session.commit()

        await callback.message.edit_text(
            f"✅ <b>{cfg['name']} куплена!</b>\n\n"
            f"🔧 Уровень: 1\n"
            f"⚙️ Добыча: {_fmt_amount(cfg['base_hourly_rate'])} {cfg['crypto']}/ч\n"
            f"💰 Потрачено: {price:,}$\n"
            f"💼 Баланс: {user.balance:,.2f}$\n\n"
            f"Используйте <code>фермы</code> для управления.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardBuilder().button(
                text="🏭 Мои фермы", callback_data="farm:my"
            ).as_markup()
        )
    await callback.answer("✅ Куплено!")


# ── Collect ───────────────────────────────────────────────────────────────────

@router.message(F.text.lower().in_(["собрать крипту", "сбор крипты", "собрать майнинг"]))
@router.callback_query(F.data == "farm:collect_all")
async def cmd_collect_farms(event):
    is_callback = isinstance(event, CallbackQuery)
    message = event.message if is_callback else event
    uid = event.from_user.id
    username = event.from_user.username
    first_name = event.from_user.first_name

    async with get_db() as session:
        await seed_crypto_prices(session)
        user = await UserService.get_or_create(session, uid, username, first_name)

        farms = user.mining_farms or {}
        if not farms:
            txt = "❌ У вас нет майнинг-ферм!"
            if is_callback:
                await event.answer(txt, show_alert=True)
            else:
                await message.answer(txt)
            return

        wallet = user.crypto_wallet or {}
        collected = {}
        total_usd = 0.0

        # mining_boost check
        inv = user.inventory or {}
        boost = 1.0
        if "mining_boost" in inv:
            boost_data = inv["mining_boost"]
            boost_until_str = boost_data.get("boost_until")
            if boost_until_str:
                try:
                    boost_until = datetime.fromisoformat(boost_until_str)
                    if datetime.utcnow() < boost_until:
                        boost = 3.0
                except Exception:
                    pass

        for fid, data in farms.items():
            cfg = MINING_FARMS.get(fid)
            if not cfg:
                continue
            pending = calc_farm_pending(data, cfg) * boost
            if pending > 0:
                sym = cfg["crypto"]
                collected[sym] = collected.get(sym, 0) + pending
                wallet[sym] = wallet.get(sym, 0) + pending
                # Get price for USD estimate
                cp = await get_price(session, sym)
                if cp:
                    total_usd += pending * cp.price
                farms[fid]["last_collect"] = datetime.utcnow().isoformat()

        user.mining_farms = farms
        user.crypto_wallet = wallet
        flag_modified(user, "mining_farms")
        flag_modified(user, "crypto_wallet")
        await session.commit()

        if not collected:
            txt = "⏳ Ещё ничего не накоплено! Подождите немного."
            if is_callback:
                await event.answer(txt, show_alert=True)
            else:
                await message.answer(txt)
            return

        lines = "\n".join(f"  {sym}: +{_fmt_amount(amt)}" for sym, amt in collected.items())
        boost_str = f"\n⚡ Майнинг-буст x{boost:.0f} активен!" if boost > 1 else ""
        text = (
            f"⛏ <b>Крипта собрана!</b>\n\n"
            f"{lines}{boost_str}\n\n"
            f"💎 Итого: ≈{total_usd:,.4f}$"
        )

        if is_callback:
            try:
                await message.edit_text(text, parse_mode="HTML",
                    reply_markup=InlineKeyboardBuilder().button(
                        text="🏭 Мои фермы", callback_data="farm:my"
                    ).as_markup())
            except Exception:
                pass
            await event.answer("⛏ Собрано!")
        else:
            await message.answer(text, parse_mode="HTML")


# ── Upgrade menu ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "farm:upgrade_menu")
async def cb_upgrade_menu(callback: CallbackQuery):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, callback.from_user.id,
            callback.from_user.username, callback.from_user.first_name
        )
        farms = user.mining_farms or {}
        if not farms:
            await callback.answer("У вас нет ферм!", show_alert=True)
            return

        wallet = user.crypto_wallet or {}
        text = "⬆️ <b>ПРОКАЧКА ФЕРМ</b>\n\n<i>Прокачка оплачивается добытой криптовалютой</i>\n\n"
        kb = InlineKeyboardBuilder()

        for fid, data in farms.items():
            cfg = MINING_FARMS.get(fid)
            if not cfg:
                continue
            lvl = data.get("level", 1)
            cost = farm_upgrade_cost(cfg, lvl)
            sym = cfg["crypto"]
            held = wallet.get(sym, 0)
            can = held >= cost
            new_rate = farm_hourly_rate(cfg, lvl + 1)
            text += (
                f"{cfg['name']} [ур. {lvl} → {lvl+1}]\n"
                f"  Стоимость: {_fmt_amount(cost)} {sym}\n"
                f"  У вас: {_fmt_amount(held)} {sym}\n"
                f"  Новая добыча: {_fmt_amount(new_rate)}/ч\n"
                f"  {'✅ Доступно' if can else '❌ Недостаточно'}\n\n"
            )
            if can:
                kb.button(text=f"⬆️ {cfg['name']}", callback_data=f"farm:upgrade:{fid}")

        kb.button(text="◀️ Назад", callback_data="farm:my")
        kb.adjust(1)
        try:
            await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
        except Exception:
            pass
    await callback.answer()


@router.callback_query(F.data.startswith("farm:upgrade:"))
async def cb_upgrade_farm(callback: CallbackQuery):
    fid = callback.data.split(":")[2]
    cfg = MINING_FARMS.get(fid)
    if not cfg:
        await callback.answer("Ферма не найдена", show_alert=True)
        return

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, callback.from_user.id,
            callback.from_user.username, callback.from_user.first_name
        )

        farms = user.mining_farms or {}
        if fid not in farms:
            await callback.answer("У вас нет этой фермы!", show_alert=True)
            return

        lvl = farms[fid].get("level", 1)
        cost = farm_upgrade_cost(cfg, lvl)
        sym = cfg["crypto"]

        wallet = user.crypto_wallet or {}
        held = wallet.get(sym, 0)

        if held < cost:
            await callback.answer(
                f"❌ Нужно {_fmt_amount(cost)} {sym}\nУ вас: {_fmt_amount(held)}",
                show_alert=True
            )
            return

        # Deduct crypto
        wallet[sym] = held - cost
        if wallet[sym] <= 0:
            del wallet[sym]
        farms[fid]["level"] = lvl + 1
        user.mining_farms = farms
        user.crypto_wallet = wallet
        flag_modified(user, "mining_farms")
        flag_modified(user, "crypto_wallet")
        await session.commit()

        new_rate = farm_hourly_rate(cfg, lvl + 1)
        await callback.message.edit_text(
            f"⬆️ <b>{cfg['name']} прокачана!</b>\n\n"
            f"🔧 Новый уровень: <b>{lvl + 1}</b>\n"
            f"⛏ Добыча: <b>{_fmt_amount(new_rate)} {sym}/ч</b>\n"
            f"💸 Потрачено: {_fmt_amount(cost)} {sym}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardBuilder().button(
                text="⬆️ Ещё прокачать", callback_data="farm:upgrade_menu"
            ).button(
                text="🏭 Мои фермы", callback_data="farm:my"
            ).adjust(1).as_markup()
        )
    await callback.answer("✅ Прокачано!")
