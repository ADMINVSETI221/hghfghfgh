"""
Business handlers — переписан с нуля.

Структура:
  /бизнес — обзор своих бизнесов (только текст + кнопки: Собрать, Купить ещё, ◀▶)
  /купить  — магазин, страницы по 5, выбираешь → вводишь кол-во текстом
  /улучшить — список своих бизнесов для апгрейда, по 5 на стр
  /продать  — список для продажи, по 5 на стр

Callback-data формат:  prefix:value  (используем двоеточие как разделитель,
  чтобы избежать конфликтов с подчёркиванием в biz_id)
"""
from datetime import datetime
from math import floor

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy.orm.attributes import flag_modified

from services.database import get_db, UserService
from services.event_service import get_event_multiplier
from models.database import BUSINESSES
from utils.formatters import format_balance

router = Router()

PAGE_SIZE = 5          # max кнопок бизнеса на одном экране


# ─── FSM ─────────────────────────────────────────────────────────────────────

class BuyState(StatesGroup):
    waiting_qty = State()   # ждём ввода количества


# ─── helpers ─────────────────────────────────────────────────────────────────

def _base(key: str) -> str:
    """lemonade_stand_2 → lemonade_stand"""
    for bid in BUSINESSES:
        if key == bid or key.startswith(bid + "_"):
            return bid
    return key


def _next_slot(businesses: dict, biz_id: str) -> str:
    i = 1
    while f"{biz_id}_{i}" in businesses:
        i += 1
    return f"{biz_id}_{i}"


def _count(businesses: dict, biz_id: str) -> int:
    return sum(1 for k in businesses if _base(k) == biz_id)


def _lvl_bonus(user_level: int) -> float:
    return 1.0 + (user_level - 1) * 0.01


def _xp_needed(lvl: int) -> int:
    return lvl * 100


def _xp_bar(xp: int, lvl: int) -> str:
    needed = _xp_needed(lvl)
    filled = floor(xp / needed * 10) if needed else 0
    return "█" * filled + "░" * (10 - filled)


def _available_income(data: dict, biz: dict, level_bonus: float) -> float:
    lvl = data.get("level", 1)
    inc = biz["base_income"] * (biz["upgrade_multiplier"] ** (lvl - 1)) * level_bonus
    lc = data.get("last_collect")
    if lc:
        lc_dt = datetime.fromisoformat(lc) if isinstance(lc, str) else lc
        cooldown_seconds = biz.get("income_interval", biz.get("cooldown_minutes", 60) * 60)
        periods = int((datetime.utcnow() - lc_dt).total_seconds() / cooldown_seconds)
        return inc * periods
    return inc


# ─── /бизнес ─────────────────────────────────────────────────────────────────

def _owned_page(businesses: dict, user_level: int, user_xp: int, page: int):
    """Строит текст + клавиатуру для просмотра своих бизнесов."""
    # Группируем по типу
    groups: dict[str, list] = {}
    for key, data in businesses.items():
        bid = _base(key)
        groups.setdefault(bid, []).append((key, data))

    group_list = list(groups.items())
    total = len(group_list)
    total_pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    chunk = group_list[page * PAGE_SIZE: (page + 1) * PAGE_SIZE]

    bonus = _lvl_bonus(user_level)
    bonus_pct = int((bonus - 1) * 100)
    bar = _xp_bar(user_xp, user_level)
    needed = _xp_needed(user_level)

    text = (
        f"🏢 <b>ВАШИ БИЗНЕСЫ</b>  (стр. {page+1}/{total_pages})\n"
        f"⭐ Ур.{user_level} [{bar}] {user_xp}/{needed} XP  •  +{bonus_pct}% к доходу\n\n"
    )

    total_avail = 0.0
    for bid, instances in chunk:
        biz = BUSINESSES.get(bid)
        if not biz:
            continue
        count = len(instances)
        avail = sum(_available_income(d, biz, bonus) for _, d in instances)
        total_avail += avail
        lvls = [d.get("level", 1) for _, d in instances]
        l_min, l_max = min(lvls), max(lvls)
        l_str = f"ур.{l_min}" if l_min == l_max else f"ур.{l_min}-{l_max}"
        avg_l = sum(lvls) // count
        total_inc = biz["base_income"] * (biz["upgrade_multiplier"] ** (avg_l - 1)) * bonus * count
        text += (
            f"{biz['name']}"
            + (f" x{count}" if count > 1 else "") +
            f" ({l_str})\n"
            f"  💰 {format_balance(avail)}  📈 {format_balance(total_inc)}/ч\n\n"
        )

    text += f"💵 Итого доступно: <b>{format_balance(total_avail)}</b>"

    builder = InlineKeyboardBuilder()
    builder.button(text="💰 Собрать всё", callback_data="biz:collect")
    builder.button(text="🛒 Купить ещё", callback_data="biz:shop:0")

    nav = []
    if page > 0:
        nav.append(("◀️", f"biz:pg:{page-1}"))
    if page < total_pages - 1:
        nav.append(("▶️", f"biz:pg:{page+1}"))
    for label, cb in nav:
        builder.button(text=label, callback_data=cb)

    # 2 основных, потом навигация в одну строку
    if nav:
        builder.adjust(2, len(nav))
    else:
        builder.adjust(2)

    return text, builder


@router.message(F.text.lower().in_(["бизнес", "бизнесы", "мои бизнесы", "бизы"]))
async def cmd_business(message: Message):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        if not user.businesses:
            await message.answer(
                "🏢 У вас пока нет бизнесов.\n\nИспользуйте /купить чтобы приобрести первый!"
            )
            return
        text, kb = _owned_page(user.businesses, user.level, user.experience, 0)
        await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())


@router.callback_query(F.data == "biz:collect")
async def collect_cb(callback: CallbackQuery):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        if not user.businesses:
            await callback.answer("❌ Нет бизнесов!", show_alert=True)
            return

        total = 0.0
        bonus = _lvl_bonus(user.level)
        mult = await get_event_multiplier(session, "money")

        # Check income_boost and biz_boost from inventory
        inv = user.inventory or {}
        now = datetime.utcnow()
        boost_mult = 1.0
        for boost_key, time_field, factor in [
            ("income_boost", "income_boost_until", 2.0),
            ("business_license", "biz_boost_until", 1.25),
        ]:
            if boost_key in inv:
                until_str = inv[boost_key].get(time_field)
                if until_str:
                    try:
                        until_dt = datetime.fromisoformat(until_str)
                        if now < until_dt:
                            boost_mult *= factor
                    except Exception:
                        pass

        for key, data in user.businesses.items():
            bid = _base(key)
            biz = BUSINESSES.get(bid)
            if not biz:
                continue
            avail = _available_income(data, biz, bonus) * mult * boost_mult
            if avail > 0:
                total += avail
                user.businesses[key]["last_collect"] = datetime.utcnow().isoformat()
                user.businesses[key]["total_earned"] = data.get("total_earned", 0) + avail
                flag_modified(user, "businesses")

        if total <= 0:
            await callback.answer("⏳ Прибыль ещё не накопилась!", show_alert=True)
            return

        user, _ = await UserService.update_balance(session, user, total, "business_income", "Сбор с бизнесов")
        level_up = await UserService.add_experience(session, user, max(1, int(total // 5000)))
        await session.commit()
        await session.refresh(user)

        text, kb = _owned_page(user.businesses, user.level, user.experience, 0)
        extra = f"\n\n✅ Собрано: <b>{format_balance(total)}</b>"
        if mult != 1.0:
            extra += f" (ивент x{mult:.1f}!)"
        if level_up:
            extra += f"\n🎉 Новый уровень: {user.level}!"
        await callback.message.edit_text(text + extra, parse_mode="HTML", reply_markup=kb.as_markup())
        await callback.answer(f"💰 +{format_balance(total)}")


@router.callback_query(F.data.startswith("biz:pg:"))
async def owned_page_cb(callback: CallbackQuery):
    page = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        if not user.businesses:
            await callback.answer("❌ Нет бизнесов!", show_alert=True)
            return
        text, kb = _owned_page(user.businesses, user.level, user.experience, page)
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


# ─── /купить ─────────────────────────────────────────────────────────────────

def _shop_page(page: int, user_level: int, user_xp: int):
    biz_list = list(BUSINESSES.items())
    total_pages = max(1, (len(biz_list) + PAGE_SIZE - 1) // PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    chunk = biz_list[page * PAGE_SIZE: (page + 1) * PAGE_SIZE]

    bonus = _lvl_bonus(user_level)
    bonus_pct = int((bonus - 1) * 100)
    bar = _xp_bar(user_xp, user_level)
    needed = _xp_needed(user_level)

    text = (
        f"🛒 <b>МАГАЗИН БИЗНЕСОВ</b>  (стр. {page+1}/{total_pages})\n"
        f"⭐ Ур.{user_level} [{bar}] {user_xp}/{needed} XP  •  +{bonus_pct}% к доходу\n\n"
    )
    for bid, biz in chunk:
        inc = int(biz["base_income"] * bonus)
        text += (
            f"{biz['name']}\n"
            f"  💰 {format_balance(biz['base_cost'])}  📈 {format_balance(inc)}/ч\n\n"
        )

    builder = InlineKeyboardBuilder()
    for bid, biz in chunk:
        builder.button(text=f"🛒 {biz['name']}", callback_data=f"shop:sel:{bid}:{page}")
    builder.adjust(1)

    nav = []
    if page > 0:
        nav.append(("◀️", f"shop:pg:{page-1}"))
    if page < total_pages - 1:
        nav.append(("▶️", f"shop:pg:{page+1}"))
    for label, cb in nav:
        builder.button(text=label, callback_data=cb)
    if nav:
        builder.adjust(*([1] * len(chunk)), len(nav))

    builder.button(text="🏢 Мои бизнесы", callback_data="biz:show:0")
    return text, builder


@router.message(F.text.lower().in_(["купить бизнес", "купить", "магазин бизнесов", "бизнес магазин"]))
async def cmd_buy(message: Message, state: FSMContext):
    await state.clear()
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        text, kb = _shop_page(0, user.level, user.experience)
    await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("shop:pg:"))
async def shop_page_cb(callback: CallbackQuery):
    page = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        text, kb = _shop_page(page, user.level, user.experience)
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("shop:sel:"))
async def shop_select_cb(callback: CallbackQuery, state: FSMContext):
    # shop:sel:{bid}:{page}  — bid может содержать подчёркивания, поэтому split с maxsplit
    parts = callback.data.split(":", 3)   # ['shop', 'sel', bid, page]
    bid = parts[2]
    back_page = int(parts[3])
    biz = BUSINESSES.get(bid)
    if not biz:
        await callback.answer("❌ Не найден!", show_alert=True)
        return

    await state.set_state(BuyState.waiting_qty)
    await state.update_data(bid=bid, back_page=back_page)

    await callback.message.edit_text(
        f"🛒 <b>{biz['name']}</b>\n\n"
        f"💰 Цена за 1 шт: {format_balance(biz['base_cost'])}\n"
        f"📈 Доход: {format_balance(biz['base_income'])}/ч\n\n"
        f"Сколько штук купить? (1–10)\nОтправьте цифру в чат:",
        parse_mode="HTML",
        reply_markup=None
    )
    await callback.answer()


@router.message(BuyState.waiting_qty, F.text.regexp(r"^\d+$"))
async def buy_qty_input(message: Message, state: FSMContext):
    data = await state.get_data()
    bid = data.get("bid")
    back_page = data.get("back_page", 0)
    await state.clear()

    biz = BUSINESSES.get(bid)
    if not biz:
        await message.answer("❌ Бизнес не найден!")
        return

    qty = int(message.text.strip())
    if qty < 1 or qty > 10:
        await message.answer("❌ Укажи число от 1 до 10!")
        return

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        current_count = _count(user.businesses or {}, bid)
        can_buy = min(qty, 10 - current_count)
        if can_buy <= 0:
            await message.answer(f"❌ У вас уже максимум (10) {biz['name']}!")
            return
        if can_buy < qty:
            await message.answer(
                f"⚠️ Можно купить не более {can_buy} шт. (у вас уже {current_count}/10).\nПокупаю {can_buy} шт."
            )
            qty = can_buy

        total_cost = biz["base_cost"] * qty
        if user.balance < total_cost:
            await message.answer(
                f"❌ Недостаточно средств!\nНужно: {format_balance(total_cost)}\nБаланс: {format_balance(user.balance)}"
            )
            return

        user, success = await UserService.update_balance(
            session, user, -total_cost, "business_purchase", f"Покупка x{qty} {biz['name']}"
        )
        if not success:
            await message.answer("❌ Ошибка при покупке!")
            return

        if user.businesses is None or isinstance(user.businesses, list):
            user.businesses = {}
        for _ in range(qty):
            slot = _next_slot(user.businesses, bid)
            user.businesses[slot] = {
                "level": 1,
                "last_collect": datetime.utcnow().isoformat(),
                "total_earned": 0,
            }
        flag_modified(user, "businesses")
        level_up = await UserService.add_experience(session, user, 15 * qty)
        await session.commit()
        await session.refresh(user)

        inc = biz["base_income"] * qty
        text = (
            f"✅ <b>Куплено: {biz['name']} x{qty}</b>\n\n"
            f"💸 Потрачено: {format_balance(total_cost)}\n"
            f"📈 Новый доход: {format_balance(inc)}/ч\n"
            f"💼 Баланс: {format_balance(user.balance)}"
        )
        if level_up:
            text += f"\n🎉 Новый уровень: {user.level}!"

        builder = InlineKeyboardBuilder()
        builder.button(text="🏢 Мои бизнесы", callback_data="biz:show:0")
        builder.button(text="🛒 Купить ещё", callback_data=f"shop:pg:{back_page}")
        builder.adjust(2)
        await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())


@router.message(BuyState.waiting_qty)
async def buy_qty_invalid(message: Message):
    await message.answer("❌ Введи целое число от 1 до 10:")


# ─── /улучшить ────────────────────────────────────────────────────────────────

def _upgrade_page(businesses: dict, user_level: int, page: int):
    # Список отдельных бизнесов которые можно улучшить
    upgradable = []
    for key, data in businesses.items():
        bid = _base(key)
        biz = BUSINESSES.get(bid)
        if not biz:
            continue
        lvl = data.get("level", 1)
        if lvl < biz["max_level"]:
            upgradable.append((key, bid, biz, lvl))

    if not upgradable:
        return None, None  # ничего нельзя улучшить

    total_pages = max(1, (len(upgradable) + PAGE_SIZE - 1) // PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    chunk = upgradable[page * PAGE_SIZE: (page + 1) * PAGE_SIZE]

    text = f"⬆️ <b>УЛУЧШЕНИЕ БИЗНЕСОВ</b>  (стр. {page+1}/{total_pages})\n\n"
    bonus = _lvl_bonus(user_level)

    builder = InlineKeyboardBuilder()
    for key, bid, biz, lvl in chunk:
        upg_cost = biz["base_cost"] * (biz["upgrade_multiplier"] ** lvl)
        new_inc = biz["base_income"] * (biz["upgrade_multiplier"] ** lvl) * bonus
        text += (
            f"{biz['name']} (ур.{lvl}→{lvl+1})\n"
            f"  💸 {format_balance(upg_cost)}  📈 станет {format_balance(new_inc)}/ч\n\n"
        )
        builder.button(
            text=f"⬆️ {biz['name']} ({format_balance(upg_cost)})",
            callback_data=f"upg:do:{key}:{page}"
        )
    builder.adjust(1)

    nav = []
    if page > 0:
        nav.append(("◀️", f"upg:pg:{page-1}"))
    if page < total_pages - 1:
        nav.append(("▶️", f"upg:pg:{page+1}"))
    for label, cb in nav:
        builder.button(text=label, callback_data=cb)
    if nav:
        builder.adjust(*([1] * len(chunk)), len(nav))

    builder.button(text="🏢 Мои бизнесы", callback_data="biz:show:0")
    return text, builder


@router.message(F.text.lower().in_(["улучшить бизнес", "улучшить", "улучшение", "апгрейд"]))
async def cmd_upgrade(message: Message):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        text, kb = _upgrade_page(user.businesses or {}, user.level, 0)
    if text is None:
        await message.answer("❌ Нечего улучшать — все бизнесы на максимальном уровне!")
        return
    await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("upg:pg:"))
async def upgrade_page_cb(callback: CallbackQuery):
    page = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        text, kb = _upgrade_page(user.businesses or {}, user.level, page)
    if text is None:
        await callback.answer("Нечего улучшать!", show_alert=True)
        return
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("upg:do:"))
async def do_upgrade_cb(callback: CallbackQuery):
    # upg:do:{key}:{page}
    # key может содержать двоеточия? Нет — используем только подчёркивания. Но на всякий случай:
    raw = callback.data[len("upg:do:"):]
    # last segment — page
    last_colon = raw.rfind(":")
    full_key = raw[:last_colon]
    page = int(raw[last_colon + 1:])

    bid = _base(full_key)
    biz = BUSINESSES.get(bid)
    if not biz:
        await callback.answer("❌ Не найден!", show_alert=True)
        return

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        if full_key not in (user.businesses or {}):
            await callback.answer("❌ У вас нет этого бизнеса!", show_alert=True)
            return

        lvl = user.businesses[full_key].get("level", 1)
        if lvl >= biz["max_level"]:
            await callback.answer("❌ Максимальный уровень!", show_alert=True)
            return

        upg_cost = biz["base_cost"] * (biz["upgrade_multiplier"] ** lvl)
        user, ok = await UserService.update_balance(
            session, user, -upg_cost, "business_upgrade", f"Улучшение: {biz['name']}"
        )
        if not ok:
            await callback.answer(f"❌ Нужно {format_balance(upg_cost)}", show_alert=True)
            return

        user.businesses[full_key]["level"] = lvl + 1
        flag_modified(user, "businesses")
        level_up = await UserService.add_experience(session, user, 10)
        await session.commit()
        await session.refresh(user)

        text, kb = _upgrade_page(user.businesses, user.level, page)
        if text is None:
            text = "✅ Все бизнесы на максимальном уровне!"
            builder = InlineKeyboardBuilder()
            builder.button(text="🏢 Мои бизнесы", callback_data="biz:show:0")
            kb = builder
        else:
            extra = f"\n\n⬆️ {biz['name']} → ур.{lvl+1}  (−{format_balance(upg_cost)})"
            if level_up:
                extra += f"\n🎉 Уровень {user.level}!"
            text += extra
        await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer(f"⬆️ Ур.{lvl+1}!")


# ─── /продать ─────────────────────────────────────────────────────────────────

def _sell_page(businesses: dict, page: int):
    items = list(businesses.items())
    total_pages = max(1, (len(items) + PAGE_SIZE - 1) // PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    chunk = items[page * PAGE_SIZE: (page + 1) * PAGE_SIZE]

    text = f"💸 <b>ПРОДАТЬ БИЗНЕС</b>  (стр. {page+1}/{total_pages})\n\n"
    builder = InlineKeyboardBuilder()

    for key, data in chunk:
        bid = _base(key)
        biz = BUSINESSES.get(bid)
        if not biz:
            continue
        lvl = data.get("level", 1)
        base = biz["base_cost"]
        total_cost = base + sum(base * (biz["upgrade_multiplier"] ** l) for l in range(1, lvl))
        sell_price = int(total_cost * 2 / 3)
        text += (
            f"{biz['name']} (ур.{lvl})\n"
            f"  💵 Продажа: {format_balance(sell_price)}\n\n"
        )
        builder.button(
            text=f"💸 {biz['name']} ур.{lvl} → {format_balance(sell_price)}",
            callback_data=f"sell:do:{key}:{page}"
        )
    builder.adjust(1)

    nav = []
    if page > 0:
        nav.append(("◀️", f"sell:pg:{page-1}"))
    if page < total_pages - 1:
        nav.append(("▶️", f"sell:pg:{page+1}"))
    for label, cb in nav:
        builder.button(text=label, callback_data=cb)
    if nav:
        builder.adjust(*([1] * len(chunk)), len(nav))

    builder.button(text="🏢 Мои бизнесы", callback_data="biz:show:0")
    return text, builder


@router.message(F.text.lower().in_(["продать бизнес", "продать", "продажа", "продажа бизнеса"]))
async def cmd_sell(message: Message):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        if not user.businesses:
            await message.answer("❌ У вас нет бизнесов!")
            return
        text, kb = _sell_page(user.businesses, 0)
    await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("sell:pg:"))
async def sell_page_cb(callback: CallbackQuery):
    page = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        if not user.businesses:
            await callback.answer("Нет бизнесов!", show_alert=True)
            return
        text, kb = _sell_page(user.businesses, page)
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("sell:do:"))
async def do_sell_cb(callback: CallbackQuery):
    raw = callback.data[len("sell:do:"):]
    last_colon = raw.rfind(":")
    full_key = raw[:last_colon]
    page = int(raw[last_colon + 1:])

    bid = _base(full_key)
    biz = BUSINESSES.get(bid)
    if not biz:
        await callback.answer("❌ Не найден!", show_alert=True)
        return

    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        if full_key not in (user.businesses or {}):
            await callback.answer("❌ Нет этого бизнеса!", show_alert=True)
            return

        lvl = user.businesses[full_key].get("level", 1)
        base = biz["base_cost"]
        total_cost = base + sum(base * (biz["upgrade_multiplier"] ** l) for l in range(1, lvl))
        sell_price = int(total_cost * 2 / 3)

        del user.businesses[full_key]
        flag_modified(user, "businesses")
        user, _ = await UserService.update_balance(
            session, user, sell_price, "business_sale", f"Продажа: {biz['name']}"
        )
        await session.commit()
        await session.refresh(user)

        if user.businesses:
            text, kb = _sell_page(user.businesses, page)
            extra = f"\n\n💸 Продан: {biz['name']} → +{format_balance(sell_price)}"
            await callback.message.edit_text(text + extra, parse_mode="HTML", reply_markup=kb.as_markup())
        else:
            builder = InlineKeyboardBuilder()
            builder.button(text="🛒 Купить бизнес", callback_data="shop:pg:0")
            await callback.message.edit_text(
                f"💸 {biz['name']} продан за {format_balance(sell_price)}\n"
                f"💼 Баланс: {format_balance(user.balance)}\n\nУ вас не осталось бизнесов.",
                parse_mode="HTML", reply_markup=builder.as_markup()
            )
    await callback.answer(f"💸 +{format_balance(sell_price)}")


# ─── /собрать ─────────────────────────────────────────────────────────────────

@router.message(F.text.lower().in_(["собрать", "собрать доход", "доход"]))
async def cmd_collect(message: Message):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=message.from_user.id,
            username=message.from_user.username, first_name=message.from_user.first_name
        )
        if not user.businesses:
            await message.answer("❌ У вас нет бизнесов!")
            return

        total = 0.0
        details = []
        bonus = _lvl_bonus(user.level)
        mult = await get_event_multiplier(session, "money")

        for key, data in user.businesses.items():
            bid = _base(key)
            biz = BUSINESSES.get(bid)
            if not biz:
                continue
            avail = _available_income(data, biz, bonus) * mult
            if avail > 0:
                total += avail
                details.append(f"{biz['name']}: {format_balance(avail)}")
                user.businesses[key]["last_collect"] = datetime.utcnow().isoformat()
                user.businesses[key]["total_earned"] = data.get("total_earned", 0) + avail
                flag_modified(user, "businesses")

        if total > 0:
            user, _ = await UserService.update_balance(session, user, total, "business_income", "Сбор прибыли")
            level_up = await UserService.add_experience(session, user, max(1, int(total // 5000)))
            await session.commit()
            needed = _xp_needed(user.level)
            ev_note = f" (ивент x{mult:.1f}!)" if mult != 1.0 else ""
            summary = (
                f"💵 Итого: {format_balance(total)}{ev_note}\n"
                f"💼 Баланс: {format_balance(user.balance)}\n"
                f"⭐ Опыт: {user.experience}/{needed} XP"
            )
            if level_up:
                summary += f"\n\n🎉 Новый уровень: {user.level}!"

            # Split details into chunks to avoid Telegram's 4096 char limit
            MAX_LEN = 3800
            header = "💰 <b>Прибыль собрана!</b>\n\n"
            chunks = []
            current = header
            for line in details:
                if len(current) + len(line) + 1 > MAX_LEN:
                    chunks.append(current)
                    current = line + "\n"
                else:
                    current += line + "\n"
            current += "\n" + summary
            chunks.append(current)

            for chunk in chunks:
                await message.answer(chunk, parse_mode="HTML")
        else:
            await message.answer("⏳ Прибыль ещё не накопилась!")


# ─── навигационные коллбеки ───────────────────────────────────────────────────

@router.callback_query(F.data.startswith("biz:show:"))
async def show_biz_cb(callback: CallbackQuery):
    page = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        if not user.businesses:
            builder = InlineKeyboardBuilder()
            builder.button(text="🛒 Купить бизнес", callback_data="shop:pg:0")
            await callback.message.edit_text(
                "🏢 У вас нет бизнесов.", reply_markup=builder.as_markup()
            )
            await callback.answer()
            return
        text, kb = _owned_page(user.businesses, user.level, user.experience, page)
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data == "biz:shop:0")
async def biz_shop_cb(callback: CallbackQuery):
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, telegram_id=callback.from_user.id,
            username=callback.from_user.username, first_name=callback.from_user.first_name
        )
        text, kb = _shop_page(0, user.level, user.experience)
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data == "back_to_menu")
async def back_to_menu_cb(callback: CallbackQuery):
    text = (
        "🎮 <b>Главное меню</b>\n\n"
        "💼 раб  •  ⛏ майн  •  🎁 дейли\n"
        "🎰 слоты  •  🎲 казино\n"
        "👤 профиль  •  🏆 топ\n"
        "🏪 магазин  •  🎴 карточки\n"
        "🏢 бизнес  •  🛒 купить  •  ⬆️ улучшить  •  💸 продать\n"
        "📅 ивенты"
    )
    try:
        await callback.message.edit_text(text, parse_mode="HTML")
    except Exception:
        await callback.message.answer(text, parse_mode="HTML")
    await callback.answer()
