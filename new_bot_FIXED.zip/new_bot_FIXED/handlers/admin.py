"""
Admin command handlers
"""
import random
from datetime import datetime, timedelta
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, PreCheckoutQuery, SuccessfulPayment

from config import settings
from services.database import get_db, UserService, TransactionService
from utils.formatters import format_balance, format_number, parse_amount, fmt_bal, BALANCE_FORMATS

# --- Donate via Telegram Stars constants ---
STARS_PER_UNIT  = 1          # количество звёзд за 1 единицу покупки
COINS_PER_STAR  = 15000      # сколько монет начисляется за 1 звезду
DONATE_PAYLOAD  = "donate_stars"  # payload для идентификации транзакции


router = Router()


def is_admin(user_id: int) -> bool:
    """Check if user is admin"""
    return user_id in settings.all_admin_ids


@router.message(Command("stats"))
async def cmd_stats(message: Message):
    """Show server statistics"""
    if not is_admin(message.from_user.id):
        return
    
    async with get_db() as session:
        # Get statistics
        user_count = await UserService.get_user_count(session)
        all_users = await UserService.get_all_users(session)
        
        total_balance = sum(u.balance for u in all_users)
        total_level = sum(u.level for u in all_users)
        avg_level = total_level / user_count if user_count > 0 else 0
        
        banned_count = sum(1 for u in all_users if u.is_banned)
        
        text = (
            f"📊 <b>СТАТИСТИКА СЕРВЕРА</b>\n\n"
            f"👥 Всего игроков: {user_count}\n"
            f"🚫 Заблокировано: {banned_count}\n"
            f"💰 Всего денег в игре: {format_balance(total_balance)}\n"
            f"⭐ Средний уровень: {avg_level:.1f}\n"
        )
        
        await message.answer(text, parse_mode="HTML")


@router.message(Command("ban"))
async def cmd_ban(message: Message):
    """Ban user"""
    if not is_admin(message.from_user.id):
        return
    
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя, которого хотите забанить!")
        return
    
    # Get reason
    text_parts = message.text.split(maxsplit=1)
    reason = text_parts[1] if len(text_parts) > 1 else "Не указана"
    
    target_id = message.reply_to_message.from_user.id
    
    # Don't ban admins
    if target_id in settings.all_admin_ids:
        await message.answer("❌ Нельзя забанить администратора!")
        return
    
    async with get_db() as session:
        success = await UserService.ban_user(session, target_id, reason)
        
        if success:
            await message.answer(
                f"✅ Пользователь заблокирован!\n"
                f"Причина: {reason}"
            )
        else:
            await message.answer("❌ Пользователь не найден!")


@router.message(Command("unban"))
async def cmd_unban(message: Message):
    """Unban user"""
    if not is_admin(message.from_user.id):
        return
    
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя, которого хотите разбанить!")
        return
    
    target_id = message.reply_to_message.from_user.id
    
    async with get_db() as session:
        success = await UserService.unban_user(session, target_id)
        
        if success:
            await message.answer("✅ Пользователь разблокирован!")
        else:
            await message.answer("❌ Пользователь не найден!")


@router.message(Command("give"))
async def cmd_give(message: Message):
    """Give money to user"""
    if not is_admin(message.from_user.id):
        return
    
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя и укажите сумму!")
        return
    
    # Parse amount
    text_parts = message.text.split()
    if len(text_parts) < 2:
        await message.answer("❌ Укажите сумму!")
        return
    
    try:
        amount = parse_amount(text_parts[1])
    except ValueError as e:
        await message.answer(f"❌ Некорректная сумма! {e}")
        return
    
    target_id = message.reply_to_message.from_user.id
    
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return
        
        await UserService.update_balance(
            session, user, amount, "admin_give",
            f"Выдано администратором {message.from_user.id}"
        )
        
        await message.answer(
            f"✅ Выдано {format_balance(amount)} пользователю {user.first_name}!\n"
            f"Новый баланс: {format_balance(user.balance)}"
        )


@router.message(Command("take"))
async def cmd_take(message: Message):
    """Take money from user"""
    if not is_admin(message.from_user.id):
        return
    
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя и укажите сумму!")
        return
    
    # Parse amount
    text_parts = message.text.split()
    if len(text_parts) < 2:
        await message.answer("❌ Укажите сумму!")
        return
    
    try:
        amount = float(text_parts[1])
    except ValueError:
        await message.answer("❌ Некорректная сумма!")
        return
    
    target_id = message.reply_to_message.from_user.id
    
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return
        
        await UserService.update_balance(
            session, user, -amount, "admin_take",
            f"Забрано администратором {message.from_user.id}"
        )
        
        await message.answer(
            f"✅ Забрано {format_balance(amount)} у пользователя {user.first_name}!\n"
            f"Новый баланс: {format_balance(user.balance)}"
        )


@router.message(Command("setlevel"))
async def cmd_setlevel(message: Message):
    """Set user level"""
    if not is_admin(message.from_user.id):
        return
    
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя и укажите уровень!")
        return
    
    # Parse level
    text_parts = message.text.split()
    if len(text_parts) < 2:
        await message.answer("❌ Укажите уровень!")
        return
    
    try:
        level = int(text_parts[1])
    except ValueError:
        await message.answer("❌ Некорректный уровень!")
        return
    
    if level < 1 or level > 1000:
        await message.answer("❌ Уровень должен быть от 1 до 1000!")
        return
    
    target_id = message.reply_to_message.from_user.id
    
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return
        
        user.level = level
        user.experience = 0
        await session.commit()
        
        await message.answer(
            f"✅ Уровень пользователя {user.first_name} установлен на {level}!"
        )


@router.message(Command("broadcast"))
async def cmd_broadcast(message: Message):
    """Broadcast message to all users"""
    if not is_admin(message.from_user.id):
        return
    
    # Get message text
    text_parts = message.text.split(maxsplit=1)
    if len(text_parts) < 2:
        await message.answer("❌ Укажите текст сообщения!")
        return
    
    broadcast_text = text_parts[1]
    
    async with get_db() as session:
        users = await UserService.get_all_users(session)
        
        success_count = 0
        fail_count = 0
        
        for user in users:
            if user.is_banned:
                continue
            
            try:
                await message.bot.send_message(
                    user.telegram_id,
                    f"📢 <b>ОБЪЯВЛЕНИЕ</b>\n\n{broadcast_text}",
                    parse_mode="HTML"
                )
                success_count += 1
            except Exception:
                fail_count += 1
        
        await message.answer(
            f"✅ Рассылка завершена!\n"
            f"Отправлено: {success_count}\n"
            f"Ошибок: {fail_count}"
        )


@router.message(Command("users"))
async def cmd_users(message: Message):
    """List all users"""
    if not is_admin(message.from_user.id):
        return
    
    async with get_db() as session:
        users = await UserService.get_all_users(session)
        
        text = f"👥 <b>СПИСОК ПОЛЬЗОВАТЕЛЕЙ ({len(users)})</b>\n\n"
        
        for user in users[:20]:  # Show first 20
            status = "🚫" if user.is_banned else "✅"
            text += (
                f"{status} {user.first_name} (@{user.username or 'нет'})\n"
                f"ID: {user.telegram_id} | Баланс: {format_balance(user.balance)}\n\n"
            )
        
        if len(users) > 20:
            text += f"... и еще {len(users) - 20} пользователей"
        
        await message.answer(text, parse_mode="HTML")


@router.message(Command("transactions"))
async def cmd_transactions(message: Message):
    """Show recent transactions"""
    if not is_admin(message.from_user.id):
        return
    
    async with get_db() as session:
        transactions = await TransactionService.get_all_transactions(session, limit=20)
        
        text = "💳 <b>ПОСЛЕДНИЕ ТРАНЗАКЦИИ</b>\n\n"
        
        for t in transactions:
            amount_text = f"+{format_balance(t.amount)}" if t.amount > 0 else f"{format_balance(t.amount)}"
            text += (
                f"ID: {t.id} | User: {t.user_id}\n"
                f"Тип: {t.transaction_type}\n"
                f"Сумма: {amount_text}\n"
                f"Описание: {t.description or 'Нет'}\n\n"
            )
        
        await message.answer(text, parse_mode="HTML")


@router.message(Command("casinoconfig"))
async def cmd_casino_config(message: Message):
    """Show current casino configuration"""
    if not is_admin(message.from_user.id):
        return
    
    text = (
        f"🎰 <b>НАСТРОЙКИ КАЗИНО</b>\n\n"
        f"💰 Минимальная ставка: {format_balance(settings.MIN_CASINO_BET)}\n"
        f"💎 Максимальная ставка: {format_balance(settings.MAX_CASINO_BET)}\n\n"
        f"<b>Множители и шансы:</b>\n"
    )
    
    multipliers = settings.casino_multipliers
    weights = settings.casino_weights
    total_weight = sum(weights)
    
    for mult, weight in zip(multipliers, weights):
        probability = (weight / total_weight) * 100
        text += f"x{mult} - {probability:.1f}%\n"
    
    text += (
        f"\n<b>Текущие настройки:</b>\n"
        f"Множители: {settings.CASINO_WIN_MULTIPLIERS}\n"
        f"Веса: {settings.CASINO_WIN_WEIGHTS}\n\n"
        f"Используйте /setcasino для изменения"
    )
    
    await message.answer(text, parse_mode="HTML")


@router.message(Command("setcasino"))
async def cmd_set_casino(message: Message):
    """Set casino multipliers and weights"""
    if not is_admin(message.from_user.id):
        return
    
    # Parse command
    text_parts = message.text.split()
    if len(text_parts) < 3:
        await message.answer(
            "❌ Использование: /setcasino [множители] [веса]\n"
            "Пример: /setcasino 0.5,1.25,2,5,10 40,30,20,8,2"
        )
        return
    
    multipliers_str = text_parts[1]
    weights_str = text_parts[2]
    
    try:
        # Validate multipliers
        multipliers = [float(x.strip()) for x in multipliers_str.split(",")]
        # Validate weights
        weights = [int(x.strip()) for x in weights_str.split(",")]
        
        if len(multipliers) != len(weights):
            await message.answer("❌ Количество множителей должно совпадать с количеством весов!")
            return
        
        if any(m < 0 for m in multipliers):
            await message.answer("❌ Множители не могут быть отрицательными!")
            return
        
        if any(w <= 0 for w in weights):
            await message.answer("❌ Веса должны быть положительными!")
            return
        
        # Update settings (this will only work for current session)
        # For permanent changes, update .env file
        settings.CASINO_WIN_MULTIPLIERS = multipliers_str
        settings.CASINO_WIN_WEIGHTS = weights_str
        
        # Show new configuration
        text = "✅ <b>Настройки казино обновлены!</b>\n\n"
        total_weight = sum(weights)
        for mult, weight in zip(multipliers, weights):
            probability = (weight / total_weight) * 100
            text += f"x{mult} - {probability:.1f}%\n"
        
        text += (
            "\n⚠️ <b>ВНИМАНИЕ:</b> Изменения применяются только до перезапуска бота!\n"
            "Для постоянных изменений обновите файл .env:\n"
            f"CASINO_WIN_MULTIPLIERS={multipliers_str}\n"
            f"CASINO_WIN_WEIGHTS={weights_str}"
        )
        
        await message.answer(text, parse_mode="HTML")
        
    except ValueError as e:
        await message.answer(f"❌ Ошибка в формате данных: {e}")


# ──────────────────────────────────────────────
#  DONATE via Telegram Stars (публичная команда)
# ──────────────────────────────────────────────

@router.message(Command("donate"))
async def cmd_donate(message: Message):
    """
    Публичная команда доната через Telegram Stars.
    Доступна для всех пользователей.
    1 ⭐ = 10 000 монет.
    """
    # Отправляем invoice через send_invoice (Telegram Stars: currency="XTR")
    await message.bot.send_invoice(
        chat_id=message.chat.id,
        title="⭐ Донат через Telegram Stars",
        description=(
            f"Купить 1 звезду — получить {format_balance(COINS_PER_STAR)} монет.\n"
            "Поддержите проект!"
        ),
        payload=DONATE_PAYLOAD,
        currency="XTR",           # Telegram Stars
        prices=[
            {
                "label": "1 ⭐ → 15 000 монет",
                "amount": STARS_PER_UNIT   # amount в звёздах
            }
        ],
        need_name=False,
        need_phone_number=False,
        need_email=False,
        need_shipping_address=False,
        is_flexible=False,
    )


@router.pre_checkout_query()
async def handle_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    """
    Подтвердить оплату перед списанием звёзд.
    Проверяем что payload наш — иначе отказываем.
    """
    if pre_checkout_query.invoice_payload == DONATE_PAYLOAD:
        await pre_checkout_query.answer(ok=True)
    else:
        await pre_checkout_query.answer(
            ok=False,
            error_message="Неизвестная транзакция."
        )


@router.message(F.successful_payment)
async def handle_successful_payment(message: Message):
    """
    После успешной оплаты звёздами начисляем монеты.
    Работает только для нашего payload — остальные игнорируем.
    """
    payment: SuccessfulPayment = message.successful_payment

    if payment.invoice_payload != DONATE_PAYLOAD:
        return  # Не наша транзакция — пропускаем

    # Количество оплаченных звёзд (amount пришло в звёздах)
    stars_paid = payment.total_amount
    coins_to_add = stars_paid * COINS_PER_STAR

    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )

        await UserService.update_balance(
            session,
            user,
            coins_to_add,
            "donate_stars",
            f"Донат: оплачено {stars_paid} ⭐ Telegram Stars"
        )

        new_balance = user.balance  # сохраняем до закрытия сессии

    await message.answer(
        f"🎉 <b>Спасибо за донат!</b>\n\n"
        f"⭐ Оплачено звёзд: {stars_paid}\n"
        f"💰 Начислено монет: +{format_balance(coins_to_add)}\n"
        f"💵 Новый баланс: {format_balance(new_balance)}",
        parse_mode="HTML"
    )


@router.message(Command("givevip"))
async def cmd_give_vip(message: Message):
    """Give VIP status to user"""
    if not is_admin(message.from_user.id):
        return
    
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя и укажите количество дней!")
        return
    
    # Parse days
    text_parts = message.text.split()
    if len(text_parts) < 2:
        await message.answer("❌ Укажите количество дней!")
        return
    
    try:
        days = int(text_parts[1])
    except ValueError:
        await message.answer("❌ Некорректное количество дней!")
        return
    
    if days < 1 or days > 365:
        await message.answer("❌ Количество дней должно быть от 1 до 365!")
        return
    
    target_id = message.reply_to_message.from_user.id
    
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return
        
        from datetime import timedelta
        if user.vip_until and user.vip_until > datetime.utcnow():
            user.vip_until += timedelta(days=days)
        else:
            user.vip_until = datetime.utcnow() + timedelta(days=days)
        
        await session.commit()
        
        await message.answer(
            f"✅ Выдан VIP статус на {days} дней пользователю {user.first_name}!\n"
            f"VIP до: {user.vip_until.strftime('%Y-%m-%d %H:%M')}"
        )


@router.message(Command("startevent"))
async def cmd_start_event(message: Message):
    """Start a global event"""
    if not is_admin(message.from_user.id):
        return
    
    text_parts = message.text.split()
    if len(text_parts) < 4:
        await message.answer(
            "❌ Использование: /startevent [тип] [множитель] [минуты]\n\n"
            "Типы ивентов:\n"
            "• money - Множитель к заработку\n"
            "• luck - Повышенная удача в играх\n"
            "• nocooldown - Без кулдаунов\n\n"
            "Пример: /startevent money 2 60"
        )
        return
    
    event_type = text_parts[1]
    
    try:
        multiplier = float(text_parts[2])
        duration_minutes = int(text_parts[3])
    except ValueError:
        await message.answer("❌ Некорректные параметры!")
        return
    
    if event_type not in ["money", "luck", "nocooldown", "exp"]:
        await message.answer("❌ Неизвестный тип ивента! Используйте: money, luck, nocooldown, exp")
        return
    
    if multiplier < 0.1 or multiplier > 100:
        await message.answer("❌ Множитель должен быть от 0.1 до 100!")
        return
    
    if duration_minutes < 1 or duration_minutes > 1440:
        await message.answer("❌ Длительность должна быть от 1 до 1440 минут!")
        return
    
    async with get_db() as session:
        from models.database import GlobalEvent
        from datetime import timedelta
        
        event = GlobalEvent(
            event_type=event_type,
            multiplier=multiplier,
            is_active=True,
            starts_at=datetime.utcnow(),
            ends_at=datetime.utcnow() + timedelta(minutes=duration_minutes),
            created_by=message.from_user.id,
            description=f"Ивент {event_type} x{multiplier}"
        )
        session.add(event)
        await session.commit()
        
        event_name = {
            "money": "💰 Бонус к заработку",
            "luck": "🍀 Повышенная удача",
            "nocooldown": "⚡ Без кулдаунов",
            "exp": "⭐ Бонус к опыту"
        }.get(event_type, f"🎉 {event_type}")
        
        # Уведомляем всех пользователей
        all_users = await UserService.get_all_users(session)
        success_count = 0
        
        for user in all_users:
            if not user.is_banned:
                try:
                    await message.bot.send_message(
                        user.telegram_id,
                        f"🎉 <b>ГЛОБАЛЬНЫЙ ИВЕНТ!</b>\n\n"
                        f"{event_name}\n"
                        f"📊 Множитель: x{multiplier}\n"
                        f"⏰ Длительность: {duration_minutes} минут\n\n"
                        f"Успейте воспользоваться бонусом!",
                        parse_mode="HTML"
                    )
                    success_count += 1
                except:
                    pass
        
        await message.answer(
            f"✅ <b>Ивент запущен!</b>\n\n"
            f"Тип: {event_name}\n"
            f"Множитель: x{multiplier}\n"
            f"Длительность: {duration_minutes} минут\n"
            f"Уведомлено игроков: {success_count}",
            parse_mode="HTML"
        )


@router.message(Command("stopevent"))
async def cmd_stop_event(message: Message):
    """Stop all active events"""
    if not is_admin(message.from_user.id):
        return
    
    async with get_db() as session:
        from models.database import GlobalEvent
        from sqlalchemy import select, update
        
        # Деактивируем все активные ивенты
        stmt = (
            update(GlobalEvent)
            .where(GlobalEvent.is_active == True)
            .values(is_active=False, ends_at=datetime.utcnow())
        )
        result = await session.execute(stmt)
        await session.commit()
        
        count = result.rowcount
        
        await message.answer(
            f"✅ Остановлено ивентов: {count}",
            parse_mode="HTML"
        )


@router.message(Command("activeevents"))
async def cmd_active_events(message: Message):
    """Show all active events"""
    if not is_admin(message.from_user.id):
        return
    
    async with get_db() as session:
        from models.database import GlobalEvent
        from sqlalchemy import select
        
        stmt = (
            select(GlobalEvent)
            .where(GlobalEvent.is_active == True)
            .where(GlobalEvent.ends_at > datetime.utcnow())
        )
        result = await session.execute(stmt)
        events = result.scalars().all()
        
        if not events:
            await message.answer("📭 Нет активных ивентов")
            return
        
        text = "🎉 <b>АКТИВНЫЕ ИВЕНТЫ</b>\n\n"
        
        for event in events:
            time_left = event.ends_at - datetime.utcnow()
            minutes_left = int(time_left.total_seconds() / 60)
            
            text += (
                f"ID: {event.id}\n"
                f"Тип: {event.event_type}\n"
                f"Множитель: x{event.multiplier}\n"
                f"Осталось: {minutes_left} минут\n"
                f"Описание: {event.description or 'Нет'}\n\n"
            )
        
        await message.answer(text, parse_mode="HTML")



@router.message(F.text.lower().startswith("!улучшить до"))
async def cmd_upgrade_businesses(message: Message):
    """Upgrade all businesses of a replied user to target level or random range.
    Examples:
      !улучшить до 10        — set all businesses to level 10
      !улучшить до 10-100    — each business gets random level 10..100
    """
    if not is_admin(message.from_user.id):
        return

    if not message.reply_to_message:
        await message.answer(
            "❌ Ответьте на сообщение игрока!\n\n"
            "Примеры:\n"
            "<code>!улучшить до 10</code> — все бизнесы → ур. 10\n"
            "<code>!улучшить до 30</code> — все бизнесы → ур. 30\n"
            "<code>!улучшить до 10-100</code> — каждый бизнес случайный ур. 10–100",
            parse_mode="HTML"
        )
        return

    parts = message.text.strip().split(maxsplit=2)
    if len(parts) < 3:
        await message.answer("❌ Укажите уровень. Пример: <code>!улучшить до 10</code>", parse_mode="HTML")
        return

    level_arg = parts[2].strip()
    level_min = None
    level_max = None

    if "-" in level_arg:
        try:
            a, b = level_arg.split("-", 1)
            level_min = int(a.strip())
            level_max = int(b.strip())
            if level_min < 1 or level_max < level_min:
                raise ValueError
        except ValueError:
            await message.answer("❌ Неверный диапазон. Пример: <code>!улучшить до 10-100</code>", parse_mode="HTML")
            return
    else:
        try:
            level_min = level_max = int(level_arg)
            if level_min < 1:
                raise ValueError
        except ValueError:
            await message.answer("❌ Неверный уровень. Пример: <code>!улучшить до 20</code>", parse_mode="HTML")
            return

    target_id = message.reply_to_message.from_user.id

    async with get_db() as session:
        from models.database import BUSINESSES
        from sqlalchemy.orm.attributes import flag_modified

        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        if not user.businesses:
            await message.answer("❌ У этого игрока нет бизнесов!")
            return

        changed = 0
        details = []

        for key in list(user.businesses.keys()):
            bid = key
            for b in BUSINESSES:
                if key == b or key.startswith(b + "_"):
                    bid = b
                    break

            biz = BUSINESSES.get(bid)
            if not biz:
                continue

            max_lvl = biz.get("max_level", 10)
            if level_min == level_max:
                target_lvl = min(level_min, max_lvl)
            else:
                target_lvl = min(random.randint(level_min, level_max), max_lvl)

            old_lvl = user.businesses[key].get("level", 1)
            user.businesses[key]["level"] = target_lvl
            details.append(f"  {biz['name']}: {old_lvl} → {target_lvl}")
            changed += 1

        flag_modified(user, "businesses")
        await session.commit()

        range_str = f"{level_min}–{level_max}" if level_min != level_max else str(level_min)
        details_text = "\n".join(details[:30])
        if len(details) > 30:
            details_text += f"\n  ... и ещё {len(details) - 30}"

        name = user.first_name or user.username or str(target_id)
        await message.answer(
            f"✅ <b>Бизнесы улучшены!</b>\n\n"
            f"👤 Игрок: {name}\n"
            f"🎯 Целевой уровень: <b>{range_str}</b>\n"
            f"🏢 Улучшено бизнесов: <b>{changed}</b>\n\n"
            f"{details_text}",
            parse_mode="HTML"
        )
        try:
            await message.bot.send_message(
                target_id,
                f"🏢 <b>Ваши бизнесы улучшены администратором!</b>\n\n"
                f"🎯 Уровень: <b>{range_str}</b>\n"
                f"🏢 Бизнесов обновлено: <b>{changed}</b>",
                parse_mode="HTML"
            )
        except Exception:
            pass



@router.message(F.text.lower().startswith("!компенсация"))
async def cmd_compensation(message: Message):
    """Give random compensation to ALL users (10M - 10B) with DM notification"""
    if not is_admin(message.from_user.id):
        return

    # Parse optional reason
    parts = message.text.split(maxsplit=1)
    reason = parts[1] if len(parts) > 1 else "Технические работы"

    # Random compensation amount: 10_000_000 to 10_000_000_000
    amount = random.randint(10_000_000, 10_000_000_000)

    async with get_db() as session:
        users = await UserService.get_all_users(session)

        success_count = 0
        fail_count = 0

        for user in users:
            if user.is_banned:
                continue

            await UserService.update_balance(
                session, user, amount, "compensation",
                f"Компенсация: {reason}"
            )

            try:
                await message.bot.send_message(
                    user.telegram_id,
                    f"🎁 <b>КОМПЕНСАЦИЯ</b>\n\n"
                    f"Администрация выдала вам компенсацию за технические работы!\n\n"
                    f"💰 Начислено: +{format_balance(amount)}\n"
                    f"📝 Причина: {reason}\n\n"
                    f"Ваш новый баланс: {format_balance(user.balance)}",
                    parse_mode="HTML"
                )
                success_count += 1
            except Exception:
                fail_count += 1

        await message.answer(
            f"✅ <b>Компенсация выдана!</b>\n\n"
            f"💰 Сумма: {format_balance(amount)}\n"
            f"📝 Причина: {reason}\n"
            f"✉️ Уведомлено: {success_count}\n"
            f"❌ Ошибок ЛС: {fail_count}",
            parse_mode="HTML"
        )


@router.message(Command("reset"))
async def cmd_reset_user(message: Message):
    """Reset user progress"""
    if not is_admin(message.from_user.id):
        return
    
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return
    
    target_id = message.reply_to_message.from_user.id
    
    # Don't reset admins
    if target_id in settings.all_admin_ids:
        await message.answer("❌ Нельзя сбросить прогресс администратора!")
        return
    
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return
        
        # Сброс прогресса
        user.balance = 100.0
        user.experience = 0
        user.level = 1
        user.businesses = {}
        user.inventory = {}
        user.statistics = {}
        user.vip_until = None
        user.last_work = None
        user.last_mine = None
        user.last_daily = None
        user.last_casino = None
        user.last_slots = None
        user.last_psychiatrist = None
        user.last_lucky_block = None
        
        await session.commit()
        
        await message.answer(
            f"✅ Прогресс пользователя {user.first_name} сброшен!\n"
            f"Баланс: 100 монет\n"
            f"Уровень: 1"
        )


@router.message(Command("псих", "addmarks", "givepsych"))
async def cmd_give_psychiatrist(message: Message):
    """Add psychiatrist marks to a user (admin only)."""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа!")
        return

    # Получаем target — только через reply
    if not message.reply_to_message:
        await message.answer(
            "❌ Используй reply на сообщение пользователя.\n\n"
            "Пример: ответь на сообщение и напиши\n"
            "<code>/псих 5</code> — добавит 5 отметок\n"
            "<code>/псих</code> — добавит 1 отметку",
            parse_mode="HTML"
        )
        return

    target_id = message.reply_to_message.from_user.id

    # Парсим количество
    parts = message.text.split()
    count = 1
    if len(parts) >= 2:
        try:
            count = int(parts[1])
        except ValueError:
            await message.answer("❌ Укажи целое число: /псих [количество]")
            return

    if count < 1 or count > 9999:
        await message.answer("❌ Количество должно быть от 1 до 9999!")
        return

    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        from sqlalchemy.orm.attributes import flag_modified
        if user.statistics is None:
            user.statistics = {}
        old_marks = user.statistics.get("psychiatrist_marks", 0)
        user.statistics["psychiatrist_marks"] = old_marks + count
        flag_modified(user, "statistics")
        await session.commit()

        new_marks = user.statistics["psychiatrist_marks"]
        name = user.first_name or user.username or str(target_id)

        await message.answer(
            f"🧠 <b>Отметки психиатра добавлены</b>\n\n"
            f"👤 Пользователь: {name}\n"
            f"➕ Добавлено: {count}\n"
            f"📊 Было: {old_marks}  →  Стало: {new_marks}",
            parse_mode="HTML"
        )

        # Уведомляем самого пользователя
        try:
            await message.bot.send_message(
                target_id,
                f"🧠 Вам добавлено <b>{count}</b> отметок психиатра!\n"
                f"📊 Всего отметок: <b>{new_marks}</b>",
                parse_mode="HTML"
            )
        except Exception:
            pass


# ── !новыйсезон ────────────────────────────────────────────────────────────────

@router.message(F.text.lower().startswith("!новыйсезон"))
async def cmd_new_season(message: Message):
    """
    !новыйсезон — сброс прогресса всех игроков + награды топ-игрокам.
    Доступно только OWNER.
    """
    if message.from_user.id != settings.OWNER_ID:
        await message.answer("❌ Только владелец бота может запустить новый сезон!")
        return

    await message.answer(
        "🔄 <b>НОВЫЙ СЕЗОН</b>\n\n"
        "⚠️ Это СБРОСИТ прогресс ВСЕХ игроков!\n"
        "Для подтверждения напишите: <code>!подтвердить новый сезон</code>",
        parse_mode="HTML"
    )


@router.message(F.text.lower() == "!подтвердить новый сезон")
async def cmd_new_season_confirm(message: Message):
    if message.from_user.id != settings.OWNER_ID:
        return

    await message.answer("⏳ <b>Запускаю новый сезон...</b>", parse_mode="HTML")

    async with get_db() as session:
        users = await UserService.get_all_users(session)

        # Sort by balance for top rewards
        top_users = sorted(
            [u for u in users if not u.is_banned],
            key=lambda u: u.balance,
            reverse=True
        )

        # VIP rewards for top players (years)
        vip_years_map = {
            1: 25, 2: 20, 3: 15, 4: 10, 5: 10,
            6: 5, 7: 5, 8: 5, 9: 5, 10: 5,
        }
        start_bonus_map = {
            1: 1_000_000, 2: 500_000, 3: 250_000,
            4: 100_000, 5: 100_000,
        }
        for i in range(6, 11):
            start_bonus_map[i] = 50_000

        from datetime import timedelta
        vip_rewards = {}
        coin_rewards = {}
        for i, user in enumerate(top_users[:10], 1):
            vip_years = vip_years_map.get(i, 0)
            bonus = start_bonus_map.get(i, 10_000)
            vip_rewards[user.telegram_id] = vip_years
            coin_rewards[user.telegram_id] = bonus

        notify_msgs = {}
        # Top badges
        medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
        for i, user in enumerate(top_users[:10], 1):
            vip_y_msg = vip_rewards.get(user.telegram_id, 0)
            bonus_msg = coin_rewards.get(user.telegram_id, 10_000)
            medal_icon = medals[i-1] if i <= len(medals) else f"{i}."
            notify_msgs[user.telegram_id] = (
                f"🏆 <b>Новый сезон начался!</b>\n\n"
                f"{medal_icon} Вы заняли <b>{i} место</b> в прошлом сезоне!\n\n"
                f"🎁 Бонус: <b>{format_balance(bonus_msg)}</b>\n"
                f"👑 VIP: <b>{vip_y_msg} лет</b>\n"
                f"🏢 Сохранён 1 бизнес (самый дорогой)\n\n"
                f"Удачи в новом сезоне!"
            )

        # Определяем самый дорогой бизнес для топ-игроков
        from models.database import BUSINESSES
        top_ids = {u.telegram_id for u in top_users[:10]}

        def _get_most_expensive_biz(user_businesses: dict) -> tuple:
            """Возвращает (key, data) самого дорогого бизнеса у игрока."""
            if not user_businesses:
                return None, None
            best_key = None
            best_cost = -1
            for key, data in user_businesses.items():
                # Определяем base_id (без суффикса _N)
                bid = key
                for b in BUSINESSES:
                    if key == b or key.startswith(b + "_"):
                        bid = b
                        break
                biz_cfg = BUSINESSES.get(bid)
                if biz_cfg and biz_cfg["base_cost"] > best_cost:
                    best_cost = biz_cfg["base_cost"]
                    best_key = key
            return best_key, user_businesses.get(best_key)

        # Reset ALL users
        from sqlalchemy.orm.attributes import flag_modified
        success = 0
        for user in users:
            # Save rewards before reset
            vip_y = vip_rewards.get(user.telegram_id, 0)
            bonus = coin_rewards.get(user.telegram_id, 0)

            # Топ-10 сохраняют свой самый дорогой бизнес
            saved_biz = {}
            if user.telegram_id in top_ids:
                bkey, bdata = _get_most_expensive_biz(user.businesses or {})
                if bkey and bdata:
                    # Сбрасываем last_collect чтобы не было накоплений
                    saved_biz = {bkey: {
                        "level": bdata.get("level", 1),
                        "last_collect": datetime.utcnow().isoformat(),
                        "total_earned": 0
                    }}

            # Full reset
            user.balance = 1_000.0
            user.experience = 0
            user.level = 1
            user.businesses = saved_biz  # пустой или 1 бизнес для топа
            user.inventory = {}
            user.statistics = {}
            user.crypto_wallet = {}
            user.mining_farms = {}
            user.vip_until = None
            user.last_work = None
            user.last_mine = None
            user.last_daily = None
            user.last_casino = None
            user.last_slots = None
            user.last_psychiatrist = None
            user.last_lucky_block = None

            # Apply rewards
            if bonus > 0:
                user.balance = float(bonus)
            if vip_y > 0:
                from datetime import timedelta
                user.vip_until = datetime.utcnow() + timedelta(days=vip_y * 365)

            flag_modified(user, "businesses")
            flag_modified(user, "inventory")
            flag_modified(user, "statistics")
            flag_modified(user, "crypto_wallet")
            flag_modified(user, "mining_farms")
            success += 1

        await session.commit()

        # Notify all users
        notified = 0
        for user in users:
            if user.is_banned:
                continue
            try:
                msg_text = notify_msgs.get(
                    user.telegram_id,
                    f"🔄 <b>Новый сезон начался!</b>\n\nПрогресс обнулён. Удачи! 💪\nСтартовый баланс: {format_balance(1000)}"
                )
                await message.bot.send_message(user.telegram_id, msg_text, parse_mode="HTML")
                notified += 1
            except Exception:
                pass

    await message.answer(
        f"✅ <b>Новый сезон запущен!</b>\n\n"
        f"👥 Игроков сброшено: {success}\n"
        f"📨 Уведомлено: {notified}\n"
        f"🏆 ТОП-{min(len(top_users), 10)} получили VIP и бонусы",
        parse_mode="HTML"
    )


# ══════════════════════════════════════════════════════════════════════════════
# НОВЫЕ ADMIN КОМАНДЫ
# ══════════════════════════════════════════════════════════════════════════════

@router.message(Command("giveall"))
async def cmd_give_all(message: Message):
    """Выдать деньги всем пользователям: /giveall [сумма]"""
    if not is_admin(message.from_user.id):
        return

    parts = message.text.split()
    if len(parts) < 2:
        await message.answer("❌ Использование: /giveall [сумма]")
        return

    try:
        amount = parse_amount(parts[1])
    except ValueError as e:
        await message.answer(f"❌ Некорректная сумма! {e}")
        return

    await message.answer(f"⏳ Начисляю {format_balance(amount)} всем игрокам...")

    async with get_db() as session:
        users = await UserService.get_all_users(session)
        count = 0
        for user in users:
            if not user.is_banned:
                await UserService.update_balance(
                    session, user, amount, "admin_give_all",
                    f"Массовая выдача от администратора {message.from_user.id}"
                )
                count += 1

    await message.answer(
        f"✅ <b>Готово!</b>\n\n"
        f"💰 Выдано: {format_balance(amount)}\n"
        f"👥 Игроков: {count}",
        parse_mode="HTML"
    )


@router.message(Command("setbalance", "setbal"))
async def cmd_set_balance(message: Message):
    """Установить точный баланс: /setbalance [сумма] (reply)"""
    if not is_admin(message.from_user.id):
        return

    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя и укажите сумму!")
        return

    parts = message.text.split()
    if len(parts) < 2:
        await message.answer("❌ Укажите сумму!")
        return

    try:
        amount = parse_amount(parts[1])
    except ValueError as e:
        await message.answer(f"❌ Некорректная сумма! {e}")
        return

    target_id = message.reply_to_message.from_user.id

    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        old_balance = float(user.balance)
        user.balance = round(amount, 2)
        await session.commit()

        await message.answer(
            f"✅ <b>Баланс установлен!</b>\n\n"
            f"👤 {user.first_name or user.username}\n"
            f"💰 Было: {format_balance(old_balance)}\n"
            f"💰 Стало: {format_balance(user.balance)}",
            parse_mode="HTML"
        )


@router.message(Command("userinfo", "ui"))
async def cmd_user_info(message: Message):
    """Подробная информация о пользователе: /userinfo (reply)"""
    if not is_admin(message.from_user.id):
        return

    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    target_id = message.reply_to_message.from_user.id

    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        vip_status = "❌ Нет"
        if user.vip_until and datetime.utcnow() < user.vip_until:
            vip_status = f"✅ до {user.vip_until.strftime('%d.%m.%Y %H:%M')}"

        businesses_count = len(user.businesses) if user.businesses else 0
        crypto_count = len(user.crypto_wallet) if user.crypto_wallet else 0
        farms_count = len(user.mining_farms) if user.mining_farms else 0
        psych_marks = (user.statistics or {}).get("psychiatrist_marks", 0)

        txs = await TransactionService.get_user_transactions(session, user.id, 3)
        tx_lines = "\n".join(
            f"  {'🟢' if t.amount > 0 else '🔴'} {format_balance(t.amount)} — {t.transaction_type}"
            for t in txs
        ) or "  Нет транзакций"

        text = (
            f"👤 <b>ИНФОРМАЦИЯ О ПОЛЬЗОВАТЕЛЕ</b>\n\n"
            f"🆔 ID: <code>{user.telegram_id}</code>\n"
            f"📛 Имя: {user.first_name or '—'}\n"
            f"🔗 Username: @{user.username or '—'}\n"
            f"📅 Регистрация: {user.created_at.strftime('%d.%m.%Y')}\n\n"
            f"💰 Баланс: <b>{format_balance(float(user.balance))}</b>\n"
            f"⭐ Уровень: {user.level} ({user.experience} XP)\n"
            f"👑 VIP: {vip_status}\n"
            f"🚫 Бан: {'❌ ' + (user.ban_reason or '') if user.is_banned else '✅ Нет'}\n\n"
            f"🏢 Бизнесов: {businesses_count}\n"
            f"🪙 Криптовалют: {crypto_count}\n"
            f"⛏ Ферм: {farms_count}\n"
            f"🧠 Отметок психиатра: {psych_marks}\n\n"
            f"📊 <b>Последние транзакции:</b>\n{tx_lines}"
        )

        await message.answer(text, parse_mode="HTML")


@router.message(Command("wipe"))
async def cmd_wipe_user(message: Message):
    """Полный сброс прогресса одного пользователя: /wipe (reply)"""
    if message.from_user.id != settings.OWNER_ID:
        await message.answer("❌ Только владелец бота!")
        return

    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    target_id = message.reply_to_message.from_user.id

    if target_id in settings.all_admin_ids:
        await message.answer("❌ Нельзя сбросить прогресс администратора!")
        return

    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        name = user.first_name or user.username or str(target_id)
        user.balance = float(settings.START_BALANCE)
        user.experience = 0
        user.level = 1
        user.businesses = {}
        user.inventory = {}
        user.statistics = {}
        user.crypto_wallet = {}
        user.mining_farms = {}
        user.vip_until = None
        user.last_work = None
        user.last_mine = None
        user.last_daily = None
        user.last_casino = None
        user.last_slots = None
        user.last_psychiatrist = None
        user.last_lucky_block = None

        flag_modified(user, "businesses")
        flag_modified(user, "inventory")
        flag_modified(user, "statistics")
        flag_modified(user, "crypto_wallet")
        flag_modified(user, "mining_farms")
        await session.commit()

    await message.answer(
        f"🗑 <b>Прогресс сброшен!</b>\n\n"
        f"👤 Пользователь: {name}\n"
        f"💰 Баланс сброшен до {format_balance(settings.START_BALANCE)}",
        parse_mode="HTML"
    )


@router.message(Command("addvip", "removevip"))
async def cmd_manage_vip(message: Message):
    """Управление VIP одной командой: /addvip [дни] или /removevip (reply)"""
    if not is_admin(message.from_user.id):
        return

    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    target_id = message.reply_to_message.from_user.id
    is_add = "addvip" in message.text.lower()

    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        name = user.first_name or user.username or str(target_id)

        if is_add:
            parts = message.text.split()
            try:
                days = int(parts[1]) if len(parts) > 1 else 7
            except ValueError:
                days = 7

            now = datetime.utcnow()
            current = user.vip_until if (user.vip_until and user.vip_until > now) else now
            user.vip_until = current + timedelta(days=days)
            await session.commit()

            await message.answer(
                f"👑 <b>VIP добавлен!</b>\n\n"
                f"👤 {name}\n"
                f"📅 Действует до: {user.vip_until.strftime('%d.%m.%Y %H:%M')}",
                parse_mode="HTML"
            )
        else:
            user.vip_until = None
            await session.commit()
            await message.answer(f"✅ VIP снят у {name}!")


@router.message(Command("finduser", "find"))
async def cmd_find_user(message: Message):
    """Найти пользователя по username или ID: /finduser [username/id]"""
    if not is_admin(message.from_user.id):
        return

    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("❌ Использование: /finduser [username или ID]")
        return

    query = parts[1].strip().lstrip("@")

    async with get_db() as session:
        from sqlalchemy import select, or_
        from models.database import User

        try:
            tg_id = int(query)
            result = await session.execute(select(User).where(User.telegram_id == tg_id))
        except ValueError:
            result = await session.execute(select(User).where(User.username == query))

        user = result.scalar_one_or_none()
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        vip = "✅" if (user.vip_until and datetime.utcnow() < user.vip_until) else "❌"
        await message.answer(
            f"🔍 <b>Найден пользователь:</b>\n\n"
            f"🆔 ID: <code>{user.telegram_id}</code>\n"
            f"📛 Имя: {user.first_name or '—'}\n"
            f"🔗 @{user.username or '—'}\n"
            f"💰 Баланс: {format_balance(float(user.balance))}\n"
            f"⭐ Уровень: {user.level}\n"
            f"👑 VIP: {vip}\n"
            f"🚫 Бан: {'Да — ' + (user.ban_reason or '') if user.is_banned else 'Нет'}",
            parse_mode="HTML"
        )


@router.message(Command("topbalance", "toprich"))
async def cmd_top_balance_admin(message: Message):
    """Топ-20 игроков по балансу для админов: /topbalance"""
    if not is_admin(message.from_user.id):
        return

    async with get_db() as session:
        users = await UserService.get_top_by_balance(session, 20)

    lines = []
    medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 17
    for i, u in enumerate(users, 1):
        medal = medals[i - 1]
        name = u.first_name or u.username or str(u.telegram_id)
        ban = " 🚫" if u.is_banned else ""
        vip = " 👑" if (u.vip_until and datetime.utcnow() < u.vip_until) else ""
        lines.append(f"{medal} {i}. {name}{vip}{ban}\n   💰 {format_balance(float(u.balance))} | Ур.{u.level}")

    await message.answer(
        "💎 <b>ТОП-20 ПО БАЛАНСУ</b>\n\n" + "\n".join(lines),
        parse_mode="HTML"
    )


@router.message(Command("serverstats", "serverstat"))
async def cmd_server_stats_detailed(message: Message):
    """Подробная статистика сервера: /serverstats"""
    if not is_admin(message.from_user.id):
        return

    async with get_db() as session:
        all_users = await UserService.get_all_users(session)

    total = len(all_users)
    banned = sum(1 for u in all_users if u.is_banned)
    active = total - banned
    vip_count = sum(1 for u in all_users if u.vip_until and datetime.utcnow() < u.vip_until)
    total_balance = sum(float(u.balance) for u in all_users)
    avg_balance = total_balance / total if total else 0
    max_bal_user = max(all_users, key=lambda u: float(u.balance), default=None)
    total_level = sum(u.level for u in all_users)
    avg_level = total_level / total if total else 0

    top_name = (max_bal_user.first_name or max_bal_user.username or str(max_bal_user.telegram_id)) if max_bal_user else "—"

    text = (
        f"📊 <b>ДЕТАЛЬНАЯ СТАТИСТИКА</b>\n\n"
        f"👥 Всего игроков: <b>{total}</b>\n"
        f"✅ Активных: {active}\n"
        f"🚫 Забанено: {banned}\n"
        f"👑 VIP: {vip_count}\n\n"
        f"💰 Денег в игре: <b>{format_balance(total_balance)}</b>\n"
        f"📈 Средний баланс: {format_balance(avg_balance)}\n"
        f"🏆 Богатейший: {top_name} ({format_balance(float(max_bal_user.balance)) if max_bal_user else '—'})\n\n"
        f"⭐ Средний уровень: {avg_level:.1f}\n"
    )

    await message.answer(text, parse_mode="HTML")


@router.message(Command("clearcooldowns", "nocooldown"))
async def cmd_clear_cooldowns(message: Message):
    """Сбросить все кулдауны пользователя: /clearcooldowns (reply)"""
    if not is_admin(message.from_user.id):
        return

    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    target_id = message.reply_to_message.from_user.id

    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        user.last_work = None
        user.last_mine = None
        user.last_daily = None
        user.last_casino = None
        user.last_slots = None
        user.last_psychiatrist = None
        user.last_lucky_block = None
        await session.commit()

        name = user.first_name or user.username or str(target_id)
        await message.answer(f"✅ Все кулдауны пользователя {name} сброшены!")


# Панель администратора — перенесена ниже, используется полная версия cmd_admin_panel_v2


# ══════════════════════════════════════════════════════════════════════════════
# ЕЩЁ БОЛЬШЕ ADMIN КОМАНД
# ══════════════════════════════════════════════════════════════════════════════

# ── /mute — временный мут (блок команд, но не бан) ────────────────────────────

@router.message(Command("mute"))
async def cmd_mute(message: Message):
    """/mute [reply] [минуты] [причина] — временно замутить игрока (заблокировать команды)"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    parts = message.text.split(maxsplit=2)
    try:
        minutes = int(parts[1]) if len(parts) > 1 else 60
    except ValueError:
        minutes = 60
    reason = parts[2] if len(parts) > 2 else "Нарушение правил"

    target_id = message.reply_to_message.from_user.id
    if target_id in settings.all_admin_ids:
        await message.answer("❌ Нельзя замутить администратора!")
        return

    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        stats = user.statistics or {}
        mute_until = datetime.utcnow() + timedelta(minutes=minutes)
        stats["muted_until"] = mute_until.isoformat()
        stats["mute_reason"] = reason
        user.statistics = stats
        flag_modified(user, "statistics")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    await message.answer(
        f"🔇 <b>Игрок замучен!</b>\n\n"
        f"👤 {name}\n"
        f"⏱ Срок: {minutes} мин\n"
        f"📝 Причина: {reason}",
        parse_mode="HTML"
    )
    try:
        await message.bot.send_message(
            target_id,
            f"🔇 <b>Вы замучены на {minutes} минут</b>\n📝 Причина: {reason}",
            parse_mode="HTML"
        )
    except Exception:
        pass


@router.message(Command("unmute"))
async def cmd_unmute(message: Message):
    """/unmute [reply] — снять мут"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        stats = user.statistics or {}
        stats.pop("muted_until", None)
        stats.pop("mute_reason", None)
        user.statistics = stats
        flag_modified(user, "statistics")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    await message.answer(f"✅ Мут снят с {name}!")


# ── /addexp — выдать опыт ─────────────────────────────────────────────────────

@router.message(Command("addexp", "giveexp"))
async def cmd_add_exp(message: Message):
    """/addexp [reply] [кол-во] — выдать опыт"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    parts = message.text.split()
    try:
        exp = int(parts[1]) if len(parts) > 1 else 1000
    except ValueError:
        await message.answer("❌ Укажите целое число!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        old_level = user.level
        leveled_up = await UserService.add_experience(session, user, exp)
        name = user.first_name or user.username or str(target_id)

    extra = f"\n🎉 Повысился до уровня {user.level}!" if leveled_up else ""
    await message.answer(
        f"⭐ <b>Опыт выдан!</b>\n\n"
        f"👤 {name}\n"
        f"➕ {exp} XP{extra}",
        parse_mode="HTML"
    )


# ── /takexp — забрать опыт ────────────────────────────────────────────────────

@router.message(Command("takeexp", "removeexp"))
async def cmd_take_exp(message: Message):
    """/takeexp [reply] [кол-во] — забрать опыт"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    parts = message.text.split()
    try:
        exp = int(parts[1]) if len(parts) > 1 else 0
    except ValueError:
        await message.answer("❌ Укажите целое число!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        user.experience = max(0, user.experience - exp)
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    await message.answer(f"✅ Забрано {exp} XP у {name}!")


# ── /resetstat — сбросить статистику ─────────────────────────────────────────

@router.message(Command("resetstat", "clearstat"))
async def cmd_reset_stat(message: Message):
    """/resetstat [reply] — сбросить статистику игрока (не баланс)"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        # Preserve balance_format setting
        fmt = (user.statistics or {}).get("balance_format", "smart")
        user.statistics = {"balance_format": fmt}
        flag_modified(user, "statistics")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    await message.answer(f"✅ Статистика {name} сброшена!")


# ── /givecrypto — выдать криптовалюту ────────────────────────────────────────

@router.message(Command("givecrypto", "addcrypto"))
async def cmd_give_crypto(message: Message):
    """/givecrypto [reply] [символ] [кол-во] — выдать крипту"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    parts = message.text.split()
    if len(parts) < 3:
        await message.answer("❌ Использование: /givecrypto [reply] [символ] [кол-во]\nПример: /givecrypto BTC 0.5")
        return

    symbol = parts[1].upper()
    try:
        qty = float(parts[2])
    except ValueError:
        await message.answer("❌ Неверное количество!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        from models.database import CRYPTO_DEFAULTS
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return
        if symbol not in CRYPTO_DEFAULTS:
            available = ", ".join(CRYPTO_DEFAULTS.keys())
            await message.answer(f"❌ Неизвестная монета!\nДоступно: {available}")
            return

        wallet = user.crypto_wallet or {}
        wallet[symbol] = round(wallet.get(symbol, 0) + qty, 8)
        user.crypto_wallet = wallet
        flag_modified(user, "crypto_wallet")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    await message.answer(
        f"✅ <b>Крипта выдана!</b>\n\n"
        f"👤 {name}\n"
        f"🪙 +{qty} {symbol}\n"
        f"💼 Итого {symbol}: {wallet[symbol]}",
        parse_mode="HTML"
    )


# ── /takecrypto — забрать криптовалюту ───────────────────────────────────────

@router.message(Command("takecrypto", "removecrypto"))
async def cmd_take_crypto(message: Message):
    """/takecrypto [reply] [символ] [кол-во] — забрать крипту"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    parts = message.text.split()
    if len(parts) < 3:
        await message.answer("❌ Использование: /takecrypto [reply] [символ] [кол-во]")
        return

    symbol = parts[1].upper()
    try:
        qty = float(parts[2])
    except ValueError:
        await message.answer("❌ Неверное количество!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        wallet = user.crypto_wallet or {}
        current = wallet.get(symbol, 0)
        wallet[symbol] = max(0, round(current - qty, 8))
        user.crypto_wallet = wallet
        flag_modified(user, "crypto_wallet")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    await message.answer(f"✅ Забрано {qty} {symbol} у {name}!")


# ── /givebiz — выдать бизнес ──────────────────────────────────────────────────

@router.message(Command("givebiz", "addbusiness"))
async def cmd_give_biz(message: Message):
    """/givebiz [reply] [ключ_бизнеса] [уровень] — выдать бизнес"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    parts = message.text.split()
    if len(parts) < 2:
        from models.database import BUSINESSES
        biz_list = "\n".join(f"  <code>{k}</code> — {v['name']}" for k, v in BUSINESSES.items())
        await message.answer(
            f"❌ Использование: /givebiz [reply] [ключ] [уровень]\n\nДоступные бизнесы:\n{biz_list}",
            parse_mode="HTML"
        )
        return

    biz_key = parts[1].lower()
    try:
        level = int(parts[2]) if len(parts) > 2 else 1
    except ValueError:
        level = 1

    from models.database import BUSINESSES
    if biz_key not in BUSINESSES:
        await message.answer(f"❌ Бизнес '{biz_key}' не найден!")
        return

    level = max(1, min(10, level))
    target_id = message.reply_to_message.from_user.id

    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        bizzes = user.businesses or {}
        bizzes[biz_key] = {
            "level": level,
            "last_collect": datetime.utcnow().isoformat(),
            "total_earned": 0
        }
        user.businesses = bizzes
        flag_modified(user, "businesses")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    biz_name = BUSINESSES[biz_key]["name"]
    await message.answer(
        f"✅ <b>Бизнес выдан!</b>\n\n"
        f"👤 {name}\n"
        f"🏢 {biz_name} (уровень {level})",
        parse_mode="HTML"
    )


# ── /clearinventory — очистить инвентарь ─────────────────────────────────────

@router.message(Command("clearinv", "clearinventory"))
async def cmd_clear_inventory(message: Message):
    """/clearinv [reply] — очистить инвентарь игрока"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        user.inventory = {}
        flag_modified(user, "inventory")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    await message.answer(f"✅ Инвентарь {name} очищен!")


# ── /clearwallet — очистить крипто кошелёк ────────────────────────────────────

@router.message(Command("clearwallet", "clearcrypto"))
async def cmd_clear_wallet(message: Message):
    """/clearwallet [reply] — очистить крипто-кошелёк игрока"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        user.crypto_wallet = {}
        flag_modified(user, "crypto_wallet")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    await message.answer(f"✅ Крипто-кошелёк {name} очищен!")


# ── /setbalanceall — установить баланс всем ──────────────────────────────────

@router.message(Command("setbalanceall", "setbalall"))
async def cmd_set_balance_all(message: Message):
    """/setbalanceall [сумма] — установить баланс всем (только owner)"""
    if message.from_user.id != settings.OWNER_ID:
        await message.answer("❌ Только владелец бота!")
        return

    parts = message.text.split()
    if len(parts) < 2:
        await message.answer("❌ Использование: /setbalanceall [сумма]")
        return

    try:
        amount = parse_amount(parts[1])
    except ValueError as e:
        await message.answer(f"❌ {e}")
        return

    await message.answer(f"⏳ Устанавливаю баланс {format_balance(amount)} всем...")

    async with get_db() as session:
        users = await UserService.get_all_users(session)
        for user in users:
            user.balance = round(amount, 2)
        await session.commit()

    await message.answer(f"✅ Баланс {format_balance(amount)} установлен всем {len(users)} игрокам!")


# ── /takeall — забрать деньги у всех ─────────────────────────────────────────

@router.message(Command("takeall"))
async def cmd_take_all(message: Message):
    """/takeall [сумма] — забрать деньги у всех игроков"""
    if message.from_user.id != settings.OWNER_ID:
        await message.answer("❌ Только владелец бота!")
        return

    parts = message.text.split()
    if len(parts) < 2:
        await message.answer("❌ Использование: /takeall [сумма]")
        return

    try:
        amount = parse_amount(parts[1])
    except ValueError as e:
        await message.answer(f"❌ {e}")
        return

    async with get_db() as session:
        users = await UserService.get_all_users(session)
        count = 0
        for user in users:
            if not user.is_banned:
                await UserService.update_balance(
                    session, user, -amount, "admin_take_all",
                    f"Массовое изъятие от {message.from_user.id}"
                )
                count += 1

    await message.answer(
        f"✅ Забрано {format_balance(amount)} у {count} игроков!"
    )


# ── /banlist — список забаненных ──────────────────────────────────────────────

@router.message(Command("banlist", "banned"))
async def cmd_ban_list(message: Message):
    """/banlist — список всех забаненных игроков"""
    if not is_admin(message.from_user.id):
        return

    async with get_db() as session:
        all_users = await UserService.get_all_users(session)

    banned = [u for u in all_users if u.is_banned]
    if not banned:
        await message.answer("✅ Забаненных игроков нет!")
        return

    lines = []
    for u in banned:
        name = u.first_name or u.username or str(u.telegram_id)
        reason = u.ban_reason or "Без причины"
        lines.append(f"🚫 <code>{u.telegram_id}</code> {name}\n   📝 {reason}")

    text = f"🚫 <b>ЗАБАНЕННЫЕ ({len(banned)})</b>\n\n" + "\n\n".join(lines)
    # Telegram limit
    if len(text) > 4000:
        text = text[:3950] + "\n\n... и ещё"
    await message.answer(text, parse_mode="HTML")


# ── /viplist — список VIP игроков ─────────────────────────────────────────────

@router.message(Command("viplist", "vipers"))
async def cmd_vip_list(message: Message):
    """/viplist — список всех VIP игроков"""
    if not is_admin(message.from_user.id):
        return

    async with get_db() as session:
        all_users = await UserService.get_all_users(session)

    now = datetime.utcnow()
    vips = [u for u in all_users if u.vip_until and u.vip_until > now]
    if not vips:
        await message.answer("Активных VIP игроков нет!")
        return

    vips.sort(key=lambda u: u.vip_until, reverse=True)
    lines = []
    for u in vips:
        name = u.first_name or u.username or str(u.telegram_id)
        days = (u.vip_until - now).days
        lines.append(f"👑 {name} — осталось {days}д")

    await message.answer(
        f"👑 <b>VIP ИГРОКИ ({len(vips)})</b>\n\n" + "\n".join(lines),
        parse_mode="HTML"
    )


# ── /mutelist — список замученных ─────────────────────────────────────────────

@router.message(Command("mutelist", "muted"))
async def cmd_mute_list(message: Message):
    """/mutelist — список замученных игроков"""
    if not is_admin(message.from_user.id):
        return

    async with get_db() as session:
        all_users = await UserService.get_all_users(session)

    now = datetime.utcnow()
    muted = []
    for u in all_users:
        muted_until_str = (u.statistics or {}).get("muted_until")
        if muted_until_str:
            try:
                muted_until = datetime.fromisoformat(muted_until_str)
                if muted_until > now:
                    muted.append((u, muted_until))
            except Exception:
                pass

    if not muted:
        await message.answer("✅ Замученных игроков нет!")
        return

    lines = []
    for u, until in muted:
        name = u.first_name or u.username or str(u.telegram_id)
        reason = (u.statistics or {}).get("mute_reason", "—")
        mins = int((until - now).total_seconds() / 60)
        lines.append(f"🔇 {name} — {mins}м осталось\n   📝 {reason}")

    await message.answer(
        f"🔇 <b>ЗАМУЧЕННЫЕ ({len(muted)})</b>\n\n" + "\n\n".join(lines),
        parse_mode="HTML"
    )


# ── /adminlog — последние действия админов ────────────────────────────────────

@router.message(Command("adminlog"))
async def cmd_admin_log(message: Message):
    """/adminlog — последние admin-транзакции"""
    if not is_admin(message.from_user.id):
        return

    async with get_db() as session:
        from sqlalchemy import select, desc
        from models.database import Transaction
        result = await session.execute(
            select(Transaction)
            .where(Transaction.transaction_type.in_(
                ["admin_give", "admin_take", "admin_give_all", "admin_take_all", "compensation"]
            ))
            .order_by(desc(Transaction.created_at))
            .limit(20)
        )
        txs = list(result.scalars().all())

    if not txs:
        await message.answer("Нет admin-транзакций!")
        return

    lines = []
    for t in txs:
        sign = "+" if t.amount > 0 else ""
        lines.append(
            f"{'🟢' if t.amount > 0 else '🔴'} {t.transaction_type}\n"
            f"   {sign}{format_balance(t.amount)} | ID:{t.user_id} | {t.created_at.strftime('%d.%m %H:%M')}"
        )

    await message.answer(
        f"📋 <b>ADMIN ЛOGI (последние 20)</b>\n\n" + "\n\n".join(lines),
        parse_mode="HTML"
    )


# ── /notify — уведомить одного игрока ────────────────────────────────────────

@router.message(Command("notify", "pm"))
async def cmd_notify(message: Message):
    """/notify [reply] [текст] — отправить ЛС одному игроку"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("❌ Укажите текст сообщения!")
        return

    text = parts[1]
    target_id = message.reply_to_message.from_user.id

    try:
        await message.bot.send_message(
            target_id,
            f"📩 <b>Сообщение от администратора:</b>\n\n{text}",
            parse_mode="HTML"
        )
        await message.answer("✅ Сообщение отправлено!")
    except Exception as e:
        await message.answer(f"❌ Не удалось отправить: {e}")


# ── /transferadmin — перевод между игроками от имени системы ─────────────────

@router.message(Command("transferadmin", "admintransfer"))
async def cmd_admin_transfer(message: Message):
    """/transferadmin [from_id] [to_id] [сумма] — системный перевод между игроками"""
    if not is_admin(message.from_user.id):
        return

    parts = message.text.split()
    if len(parts) < 4:
        await message.answer("❌ Использование: /transferadmin [from_id] [to_id] [сумма]")
        return

    try:
        from_id = int(parts[1])
        to_id = int(parts[2])
        amount = parse_amount(parts[3])
    except (ValueError, Exception) as e:
        await message.answer(f"❌ Ошибка: {e}")
        return

    async with get_db() as session:
        from_user = await UserService.get_by_telegram_id(session, from_id)
        to_user = await UserService.get_by_telegram_id(session, to_id)

        if not from_user:
            await message.answer(f"❌ Пользователь {from_id} не найден!")
            return
        if not to_user:
            await message.answer(f"❌ Пользователь {to_id} не найден!")
            return

        if float(from_user.balance) < amount:
            await message.answer(
                f"❌ У {from_user.first_name} недостаточно средств!\n"
                f"Баланс: {format_balance(float(from_user.balance))}"
            )
            return

        await UserService.update_balance(session, from_user, -amount, "admin_transfer",
            f"Системный перевод → {to_id}")
        await UserService.update_balance(session, to_user, amount, "admin_transfer",
            f"Системный перевод ← {from_id}")

        from_name = from_user.first_name or str(from_id)
        to_name = to_user.first_name or str(to_id)

    await message.answer(
        f"✅ <b>Перевод выполнен!</b>\n\n"
        f"👤 Отправитель: {from_name}\n"
        f"👤 Получатель: {to_name}\n"
        f"💰 Сумма: {format_balance(amount)}",
        parse_mode="HTML"
    )


# ── /setcooldown — установить кулдаун ─────────────────────────────────────────

@router.message(Command("setcd", "setcooldown"))
async def cmd_set_cooldown(message: Message):
    """/setcd [reply] [тип] [секунды] — вручную установить кулдаун"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    VALID_TYPES = {"work", "mine", "daily", "casino", "slots", "psychiatrist", "lucky_block"}
    parts = message.text.split()
    if len(parts) < 3:
        await message.answer(
            f"❌ Использование: /setcd [reply] [тип] [секунды]\n"
            f"Типы: {', '.join(VALID_TYPES)}"
        )
        return

    cd_type = parts[1].lower()
    if cd_type not in VALID_TYPES:
        await message.answer(f"❌ Неверный тип! Доступно: {', '.join(VALID_TYPES)}")
        return

    try:
        seconds = int(parts[2])
    except ValueError:
        await message.answer("❌ Укажите секунды (целое число)!")
        return

    target_id = message.reply_to_message.from_user.id
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        if seconds <= 0:
            setattr(user, f"last_{cd_type}", None)
        else:
            setattr(user, f"last_{cd_type}", datetime.utcnow() - timedelta(seconds=1) + timedelta(seconds=seconds))
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    if seconds <= 0:
        await message.answer(f"✅ Кулдаун {cd_type} сброшен для {name}!")
    else:
        await message.answer(f"✅ Кулдаун {cd_type} установлен на {seconds}с для {name}!")


# ── /giveitem — выдать предмет из магазина ────────────────────────────────────

@router.message(Command("giveitem", "additem"))
async def cmd_give_item(message: Message):
    """/giveitem [reply] [ключ_предмета] [кол-во] — выдать предмет из магазина"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    from models.database import SHOP_ITEMS
    parts = message.text.split()
    if len(parts) < 2:
        items_list = "\n".join(f"  <code>{k}</code> — {v['name']}" for k, v in SHOP_ITEMS.items())
        await message.answer(
            f"❌ Использование: /giveitem [reply] [ключ] [кол-во]\n\nПредметы:\n{items_list}",
            parse_mode="HTML"
        )
        return

    item_key = parts[1].lower()
    try:
        qty = int(parts[2]) if len(parts) > 2 else 1
    except ValueError:
        qty = 1

    if item_key not in SHOP_ITEMS:
        await message.answer(f"❌ Предмет '{item_key}' не найден!")
        return

    qty = max(1, min(qty, 999))
    target_id = message.reply_to_message.from_user.id

    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        inv = user.inventory or {}
        inv[item_key] = inv.get(item_key, 0) + qty
        user.inventory = inv
        flag_modified(user, "inventory")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    item_name = SHOP_ITEMS[item_key]["name"]
    await message.answer(
        f"✅ <b>Предмет выдан!</b>\n\n"
        f"👤 {name}\n"
        f"🎁 {item_name} x{qty}",
        parse_mode="HTML"
    )


# ── /topstats — топ по разным критериям ──────────────────────────────────────

@router.message(Command("topstats"))
async def cmd_top_stats(message: Message):
    """/topstats — подробный топ по всем критериям"""
    if not is_admin(message.from_user.id):
        return

    async with get_db() as session:
        all_users = await UserService.get_all_users(session)

    active = [u for u in all_users if not u.is_banned]

    top_bal = sorted(active, key=lambda u: float(u.balance), reverse=True)[:5]
    top_lvl = sorted(active, key=lambda u: (u.level, u.experience), reverse=True)[:5]
    top_games = sorted(active, key=lambda u: (u.statistics or {}).get("casino_played", 0) + (u.statistics or {}).get("slots_played", 0), reverse=True)[:5]
    top_earned = sorted(active, key=lambda u: (u.statistics or {}).get("total_earned", 0), reverse=True)[:5]

    def fmt_list(users, key_fn, val_fn):
        lines = []
        for i, u in enumerate(users, 1):
            name = u.first_name or u.username or str(u.telegram_id)
            lines.append(f"{i}. {name} — {val_fn(u)}")
        return "\n".join(lines) or "Нет данных"

    text = (
        f"📊 <b>ТОП СТАТИСТИКА</b>\n\n"
        f"💰 <b>По балансу:</b>\n"
        f"{fmt_list(top_bal, None, lambda u: format_balance(float(u.balance)))}\n\n"
        f"⭐ <b>По уровню:</b>\n"
        f"{fmt_list(top_lvl, None, lambda u: f'Ур. {u.level}')}\n\n"
        f"🎰 <b>По играм:</b>\n"
        f"{fmt_list(top_games, None, lambda u: str((u.statistics or {}).get('casino_played',0)+(u.statistics or {}).get('slots_played',0)) + ' игр')}\n\n"
        f"📈 <b>Всего заработано:</b>\n"
        f"{fmt_list(top_earned, None, lambda u: format_balance((u.statistics or {}).get('total_earned',0)))}"
    )
    await message.answer(text, parse_mode="HTML")


# ── /announce — красивый анонс ────────────────────────────────────────────────

@router.message(Command("announce"))
async def cmd_announce(message: Message):
    """/announce [текст] — красивый анонс всем (с рамкой)"""
    if not is_admin(message.from_user.id):
        return

    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("❌ Использование: /announce [текст]")
        return

    ann_text = parts[1]
    from_name = message.from_user.first_name or "Администратор"

    formatted = (
        f"📢 <b>═══ АНОНС ═══</b>\n\n"
        f"{ann_text}\n\n"
        f"<i>— {from_name}</i>"
    )

    async with get_db() as session:
        users = await UserService.get_all_users(session)

    sent = 0
    for user in users:
        if user.is_banned:
            continue
        try:
            await message.bot.send_message(user.telegram_id, formatted, parse_mode="HTML")
            sent += 1
        except Exception:
            pass

    await message.answer(f"📢 Анонс отправлен {sent} игрокам!")


# ── /techworks — техработы (сообщение + временный баланс) ────────────────────

@router.message(Command("techworks"))
async def cmd_tech_works(message: Message):
    """/techworks [минуты] [причина] — объявить о техработах"""
    if not is_admin(message.from_user.id):
        return

    parts = message.text.split(maxsplit=2)
    try:
        minutes = int(parts[1]) if len(parts) > 1 else 30
    except ValueError:
        minutes = 30
    reason = parts[2] if len(parts) > 2 else "Плановое обслуживание"

    async with get_db() as session:
        users = await UserService.get_all_users(session)

    text = (
        f"🔧 <b>ТЕХНИЧЕСКИЕ РАБОТЫ</b>\n\n"
        f"⏱ Продолжительность: ~{minutes} минут\n"
        f"📝 Причина: {reason}\n\n"
        f"Приносим извинения за неудобства! 🙏"
    )

    sent = 0
    for user in users:
        if user.is_banned:
            continue
        try:
            await message.bot.send_message(user.telegram_id, text, parse_mode="HTML")
            sent += 1
        except Exception:
            pass

    await message.answer(f"🔧 Уведомление о техработах отправлено {sent} игрокам!")


# ── /givefarm — выдать майнинг ферму ─────────────────────────────────────────

@router.message(Command("givefarm", "addfarm"))
async def cmd_give_farm(message: Message):
    """/givefarm [reply] [ключ_фермы] [уровень] — выдать ферму"""
    if not is_admin(message.from_user.id):
        return
    if not message.reply_to_message:
        await message.answer("❌ Ответьте на сообщение пользователя!")
        return

    from models.database import MINING_FARMS
    parts = message.text.split()
    if len(parts) < 2:
        farm_list = "\n".join(f"  <code>{k}</code> — {v['name']}" for k, v in MINING_FARMS.items())
        await message.answer(
            f"❌ Использование: /givefarm [reply] [ключ] [уровень]\n\nФермы:\n{farm_list}",
            parse_mode="HTML"
        )
        return

    farm_key = parts[1].lower()
    try:
        level = int(parts[2]) if len(parts) > 2 else 1
    except ValueError:
        level = 1

    if farm_key not in MINING_FARMS:
        await message.answer(f"❌ Ферма '{farm_key}' не найдена!")
        return

    level = max(1, level)
    target_id = message.reply_to_message.from_user.id

    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, target_id)
        if not user:
            await message.answer("❌ Пользователь не найден!")
            return

        farms = user.mining_farms or {}
        farms[farm_key] = {
            "level": level,
            "last_collect": datetime.utcnow().isoformat()
        }
        user.mining_farms = farms
        flag_modified(user, "mining_farms")
        await session.commit()
        name = user.first_name or user.username or str(target_id)

    farm_name = MINING_FARMS[farm_key]["name"]
    await message.answer(
        f"✅ <b>Ферма выдана!</b>\n\n"
        f"👤 {name}\n"
        f"⛏ {farm_name} (уровень {level})",
        parse_mode="HTML"
    )


# ── /admins — список всех администраторов ─────────────────────────────────────

@router.message(Command("admins", "adminlist"))
async def cmd_admins(message: Message):
    """/admins — список администраторов"""
    if not is_admin(message.from_user.id):
        return

    async with get_db() as session:
        all_users = await UserService.get_all_users(session)

    admin_ids = settings.all_admin_ids
    owner_id = settings.OWNER_ID

    lines = []
    for admin_id in admin_ids:
        user = next((u for u in all_users if u.telegram_id == admin_id), None)
        name = (user.first_name or user.username) if user else str(admin_id)
        role = "👑 Владелец" if admin_id == owner_id else "🛡 Администратор"
        lines.append(f"{role}: {name} (<code>{admin_id}</code>)")

    await message.answer(
        f"👥 <b>АДМИНИСТРАТОРЫ ({len(admin_ids)})</b>\n\n" + "\n".join(lines),
        parse_mode="HTML"
    )


# ── /reloadcrypto — обновить цены крипты ──────────────────────────────────────

@router.message(Command("reloadcrypto", "updatecrypto"))
async def cmd_reload_crypto(message: Message):
    """/reloadcrypto — принудительно обновить цены криптовалют"""
    if not is_admin(message.from_user.id):
        return

    try:
        from services.crypto_service import update_crypto_prices
        async with get_db() as session:
            await update_crypto_prices(session)
        await message.answer("✅ Цены криптовалют обновлены!")
    except Exception as e:
        await message.answer(f"❌ Ошибка: {e}")


# ── Обновлённая панель администратора ─────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin_panel_v2(message: Message):
    """Полная панель администратора"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ У вас нет доступа к админ панели!")
        return

    is_owner = message.from_user.id == settings.OWNER_ID

    text = (
        "👑 <b>АДМИН ПАНЕЛЬ</b>\n\n"

        "📊 <b>Статистика:</b>\n"
        "/stats — Статистика сервера\n"
        "/serverstats — Детальная статистика\n"
        "/topbalance — Топ-20 по балансу\n"
        "/topstats — Топ по всем критериям\n"
        "/adminlog — Последние admin-действия\n"
        "/admins — Список администраторов\n"
        "/users — Список всех игроков\n"
        "/transactions — История транзакций\n\n"

        "🔍 <b>Поиск игроков:</b>\n"
        "/finduser [username/ID] — Найти игрока\n"
        "/userinfo [reply] — Подробный профиль\n"
        "/banlist — Список забаненных\n"
        "/viplist — Список VIP\n"
        "/mutelist — Список замученных\n\n"

        "💰 <b>Баланс:</b>\n"
        "/give [reply] [сумма] — Выдать деньги\n"
        "/take [reply] [сумма] — Забрать деньги\n"
        "/giveall [сумма] — Выдать всем\n"
        "/setbalance [reply] [сумма] — Установить баланс\n"
        "/transferadmin [from_id] [to_id] [сумма] — Перевод\n"
        "/donate [reply] [stars] — Начислить донат\n\n"

        "👤 <b>Управление игроками:</b>\n"
        "/ban [reply] [причина] — Забанить\n"
        "/unban [reply] — Разбанить\n"
        "/mute [reply] [мин] [причина] — Замутить\n"
        "/unmute [reply] — Снять мут\n"
        "/setlevel [reply] [ур] — Установить уровень\n"
        "/addexp [reply] [кол] — Выдать опыт\n"
        "/takeexp [reply] [кол] — Забрать опыт\n"
        "/addvip [reply] [дни] — Добавить VIP\n"
        "/removevip [reply] — Снять VIP\n"
        "/givevip [reply] [дни] — Выдать VIP\n"
        "/clearcooldowns [reply] — Сбросить кулдауны\n"
        "/setcd [reply] [тип] [сек] — Установить кулдаун\n"
        "/resetstat [reply] — Сбросить статистику\n"
        "/псих [reply] [кол] — Отметки психиатра\n"
        "/reset [reply] — Сброс кулдаунов игрока\n\n"

        "🎁 <b>Инвентарь / Бизнесы / Крипта:</b>\n"
        "/givecrypto [reply] [символ] [кол] — Выдать крипту\n"
        "/takecrypto [reply] [символ] [кол] — Забрать крипту\n"
        "/giveitem [reply] [ключ] [кол] — Выдать предмет\n"
        "/givebiz [reply] [ключ] [ур] — Выдать бизнес\n"
        "/givefarm [reply] [ключ] [ур] — Выдать ферму\n"
        "/clearinv [reply] — Очистить инвентарь\n"
        "/clearwallet [reply] — Очистить кошелёк\n"
        "/reloadcrypto — Обновить крипто цены\n"
        "!улучшить до [ур] [reply] — Прокачать бизнесы\n\n"

        "📢 <b>Оповещения:</b>\n"
        "/broadcast [текст] — Рассылка всем\n"
        "/announce [текст] — Красивый анонс\n"
        "/notify [reply] [текст] — ЛС игроку\n"
        "/techworks [мин] [причина] — Техработы\n"
        "!компенсация [причина] — Компенсация всем\n\n"

        "🎉 <b>Ивенты:</b>\n"
        "/startevent [тип] [x] [мин] — Запустить ивент\n"
        "Типы: money, exp, nocooldown\n"
        "/stopevent — Остановить ивент\n"
        "/activeevents — Активные ивенты\n\n"

        "🎰 <b>Казино:</b>\n"
        "/casinoconfig — Настройки казино\n"
        "/setcasino [множители] [веса] — Изменить шансы\n"
    )

    if is_owner:
        text += (
            "\n🔑 <b>Только владелец:</b>\n"
            "/wipe [reply] — Полный сброс игрока\n"
            "/setbalanceall [сумма] — Установить баланс всем\n"
            "/takeall [сумма] — Забрать у всех игроков\n"
            "!новыйсезон — Начать новый сезон\n"
        )

    await message.answer(text, parse_mode="HTML")
