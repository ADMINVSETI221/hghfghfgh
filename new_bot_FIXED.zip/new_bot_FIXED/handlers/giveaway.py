"""
Giveaway (money distribution) handlers for admins
"""
from datetime import datetime, timedelta
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import select
from sqlalchemy.orm.attributes import flag_modified

from config import settings
from services.database import get_db, UserService
from models.database import Giveaway
from utils.formatters import format_balance


router = Router()


def is_admin(user_id: int) -> bool:
    """Check if user is admin or owner"""
    return user_id in settings.all_admin_ids


@router.message(Command("money"))
async def cmd_money(message: Message):
    """Create money giveaway (admins only)
    Usage: /money <total_amount> <amount_per_user>
    Example: /money 1000 100
    """
    # Check if user is admin
    if not is_admin(message.from_user.id):
        await message.answer("❌ Эта команда доступна только администраторам!")
        return
    
    # Parse arguments
    args = message.text.split()
    if len(args) != 3:
        await message.answer(
            "❌ Неверный формат!\n\n"
            "Использование: /money <общая_сумма> <сумма_на_игрока>\n"
            "Пример: /money 1000 100\n\n"
            "Это создаст раздачу на 1000 единиц, где каждый игрок получит по 100"
        )
        return
    
    try:
        total_amount = float(args[1])
        amount_per_user = float(args[2])
    except ValueError:
        await message.answer("❌ Суммы должны быть числами!")
        return
    
    if total_amount <= 0 or amount_per_user <= 0:
        await message.answer("❌ Суммы должны быть положительными!")
        return
    
    if amount_per_user > total_amount:
        await message.answer("❌ Сумма на игрока не может быть больше общей суммы!")
        return
    
    # Calculate max participants
    max_participants = int(total_amount / amount_per_user)
    
    # Create giveaway
    async with get_db() as session:
        giveaway = Giveaway(
            total_amount=total_amount,
            amount_per_user=amount_per_user,
            max_participants=max_participants,
            remaining_amount=total_amount,
            claimed_users={},
            created_by=message.from_user.id,
            is_active=True,
            expires_at=datetime.utcnow() + timedelta(hours=24)
        )
        session.add(giveaway)
        await session.commit()
        await session.refresh(giveaway)
        
        # Create message with button
        text = (
            f"🎁 <b>РАЗДАЧА ДЕНЕГ!</b>\n\n"
            f"💰 Общая сумма: {format_balance(total_amount)}\n"
            f"💵 На человека: {format_balance(amount_per_user)}\n"
            f"👥 Участников: 0/{max_participants}\n"
            f"📊 Осталось: {format_balance(total_amount)}\n\n"
            f"<b>Получили:</b>\n"
            f"Пока никто не забрал\n\n"
            f"⏰ Раздача активна 24 часа"
        )
        
        builder = InlineKeyboardBuilder()
        builder.button(text="🎁 Забрать награду", callback_data=f"claim_giveaway_{giveaway.id}")
        
        sent_message = await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())
        
        # Update giveaway with message info
        giveaway.message_id = sent_message.message_id
        giveaway.chat_id = sent_message.chat.id
        await session.commit()
        
        await message.answer(
            f"✅ Раздача создана!\n"
            f"ID раздачи: {giveaway.id}"
        )


@router.callback_query(F.data.startswith("claim_giveaway_"))
async def claim_giveaway_callback(callback: CallbackQuery):
    """Handle giveaway claim"""
    giveaway_id = int(callback.data.split("_")[2])
    
    async with get_db() as session:
        # Get giveaway
        result = await session.execute(
            select(Giveaway).where(Giveaway.id == giveaway_id)
        )
        giveaway = result.scalar_one_or_none()
        
        if not giveaway:
            await callback.answer("❌ Раздача не найдена!", show_alert=True)
            return
        
        if not giveaway.is_active:
            await callback.answer("❌ Раздача уже завершена!", show_alert=True)
            return
        
        # Check if expired
        if giveaway.expires_at and datetime.utcnow() > giveaway.expires_at:
            giveaway.is_active = False
            await session.commit()
            await callback.answer("❌ Раздача истекла!", show_alert=True)
            return
        
        # Check if user already claimed
        user_id_str = str(callback.from_user.id)
        if user_id_str in giveaway.claimed_users:
            await callback.answer("❌ Вы уже получили награду!", show_alert=True)
            return
        
        # Check if giveaway is full
        if len(giveaway.claimed_users) >= giveaway.max_participants:
            giveaway.is_active = False
            await session.commit()
            await callback.answer("❌ Все награды разобраны!", show_alert=True)
            return
        
        # Get or create user
        user = await UserService.get_or_create(
            session,
            telegram_id=callback.from_user.id,
            username=callback.from_user.username,
            first_name=callback.from_user.first_name
        )
        
        # Give money
        await UserService.update_balance(
            session,
            user,
            giveaway.amount_per_user,
            "giveaway",
            f"Раздача #{giveaway.id}"
        )
        
        # Update giveaway
        if giveaway.claimed_users is None:
            giveaway.claimed_users = {}
        
        giveaway.claimed_users[user_id_str] = {
            "username": callback.from_user.username,
            "first_name": callback.from_user.first_name,
            "claimed_at": datetime.utcnow().isoformat()
        }
        giveaway.remaining_amount -= giveaway.amount_per_user
        
        # Check if giveaway is complete
        if len(giveaway.claimed_users) >= giveaway.max_participants:
            giveaway.is_active = False
        
        flag_modified(giveaway, "claimed_users")
        await session.commit()
        await session.refresh(giveaway)
        
        # Update message
        claimed_list = []
        for uid, udata in giveaway.claimed_users.items():
            if udata.get("username"):
                user_link = f'<a href="tg://user?id={uid}">@{udata["username"]}</a>'
            else:
                display_name = udata.get("first_name") or f"User_{uid}"
                user_link = f'<a href="tg://user?id={uid}">{display_name}</a>'
            claimed_list.append(user_link)
        
        claimed_text = ", ".join(claimed_list) if claimed_list else "Пока никто не забрал"
        
        status = "❌ Завершена" if not giveaway.is_active else "✅ Активна"
        
        text = (
            f"🎁 <b>РАЗДАЧА ДЕНЕГ!</b>\n\n"
            f"💰 Общая сумма: {format_balance(giveaway.total_amount)}\n"
            f"💵 На человека: {format_balance(giveaway.amount_per_user)}\n"
            f"👥 Участников: {len(giveaway.claimed_users)}/{giveaway.max_participants}\n"
            f"📊 Осталось: {format_balance(giveaway.remaining_amount)}\n"
            f"📍 Статус: {status}\n\n"
            f"<b>Получили:</b>\n"
            f"{claimed_text}\n\n"
            f"⏰ Раздача активна 24 часа"
        )
        
        builder = InlineKeyboardBuilder()
        if giveaway.is_active:
            builder.button(text="🎁 Забрать награду", callback_data=f"claim_giveaway_{giveaway.id}")
        else:
            builder.button(text="✅ Раздача завершена", callback_data="giveaway_ended")
        
        try:
            await callback.message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())
        except:
            pass  # Message not modified
        
        await callback.answer(
            f"✅ Вы получили {format_balance(giveaway.amount_per_user)}!",
            show_alert=True
        )


@router.callback_query(F.data == "giveaway_ended")
async def giveaway_ended_callback(callback: CallbackQuery):
    """Handle ended giveaway button"""
    await callback.answer("Раздача завершена!", show_alert=False)


@router.message(Command("giveaway_list"))
async def cmd_giveaway_list(message: Message):
    """List all active giveaways (admins only)"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Эта команда доступна только администраторам!")
        return
    
    async with get_db() as session:
        result = await session.execute(
            select(Giveaway).where(Giveaway.is_active == True)
        )
        giveaways = result.scalars().all()
        
        if not giveaways:
            await message.answer("📋 Нет активных раздач")
            return
        
        text = "📋 <b>АКТИВНЫЕ РАЗДАЧИ</b>\n\n"
        
        for g in giveaways:
            text += (
                f"ID: {g.id}\n"
                f"💰 Сумма: {format_balance(g.total_amount)}\n"
                f"👥 Участников: {len(g.claimed_users or {})}/{g.max_participants}\n"
                f"📊 Осталось: {format_balance(g.remaining_amount)}\n\n"
            )
        
        await message.answer(text, parse_mode="HTML")


@router.message(Command("giveaway_cancel"))
async def cmd_giveaway_cancel(message: Message):
    """Cancel active giveaway (admins only)
    Usage: /giveaway_cancel <id>
    """
    if not is_admin(message.from_user.id):
        await message.answer("❌ Эта команда доступна только администраторам!")
        return
    
    args = message.text.split()
    if len(args) != 2:
        await message.answer("Использование: /giveaway_cancel <id>")
        return
    
    try:
        giveaway_id = int(args[1])
    except ValueError:
        await message.answer("❌ ID должен быть числом!")
        return
    
    async with get_db() as session:
        result = await session.execute(
            select(Giveaway).where(Giveaway.id == giveaway_id)
        )
        giveaway = result.scalar_one_or_none()
        
        if not giveaway:
            await message.answer("❌ Раздача не найдена!")
            return
        
        giveaway.is_active = False
        await session.commit()
        
        await message.answer(f"✅ Раздача #{giveaway_id} отменена!")
