"""
Shop command handlers
"""
from datetime import datetime, timedelta
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import settings
from services.database import get_db, UserService
from models.database import SHOP_ITEMS
from utils.formatters import format_balance


router = Router()


@router.message(Command("shop"))
@router.message(F.text.lower() == "магазин")
async def cmd_shop(message: Message):
    """Show shop items"""
    text = "🏪 <b>МАГАЗИН ПРЕДМЕТОВ</b>\n\n"
    
    builder = InlineKeyboardBuilder()
    
    for item_id, item in SHOP_ITEMS.items():
        text += (
            f"{item['name']}\n"
            f"{item['description']}\n"
            f"💰 Цена: {format_balance(item['price'])}\n\n"
        )
        
        builder.button(
            text=f"Купить {item['name']}", 
            callback_data=f"buy_item_{item_id}"
        )
    
    text += "Используйте: купить [название предмета]"
    
    builder.adjust(1)
    builder.button(text="◀️ Назад", callback_data="back_to_menu")
    await message.answer(text, parse_mode="HTML", reply_markup=builder.as_markup())


@router.callback_query(F.data.startswith("buy_item_"))
async def buy_item_callback(callback: CallbackQuery):
    """Handle item purchase via callback"""
    # Проверка: разрешаем только если это ответ на команду пользователя
    if hasattr(callback.message, 'reply_to_message') and callback.message.reply_to_message:
        if callback.message.reply_to_message.from_user.id != callback.from_user.id:
            await callback.answer("❌ Это не ваши кнопки!", show_alert=True)
            return
    
    item_id = callback.data.split("_", 2)[2]
    await process_item_purchase(callback.message, callback.from_user, item_id, callback)


@router.message(F.text.lower().startswith("купить"), ~F.text.lower().startswith("купить крипту"), ~F.text.lower().in_(["купить бизнес", "купить"]))
async def cmd_buy(message: Message):
    """Buy item command"""
    text_parts = message.text.lower().split()
    
    if len(text_parts) < 2:
        await message.answer("❌ Укажите название предмета!\nИспользование: купить [название]")
        return
    
    # Try to match item by name
    search_term = " ".join(text_parts[1:])
    
    item_id = None
    for iid, item in SHOP_ITEMS.items():
        if search_term in item['name'].lower() or search_term in iid:
            item_id = iid
            break
    
    if not item_id:
        await message.answer("❌ Предмет не найден! Используйте 'магазин' для списка.")
        return
    
    await process_item_purchase(message, message.from_user, item_id)


async def process_item_purchase(message: Message, user_info, item_id: str, callback: CallbackQuery = None):
    """Process item purchase"""
    item = SHOP_ITEMS.get(item_id)
    
    if not item:
        text = "❌ Предмет не найден!"
        if callback:
            await callback.answer(text, show_alert=True)
        else:
            await message.answer(text)
        return
    
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=user_info.id,
            username=user_info.username,
            first_name=user_info.first_name
        )
        
        price = item["price"]
        
        if user.balance < price:
            text = f"❌ Недостаточно средств! Нужно: {format_balance(price)}"
            if callback:
                await callback.answer(text, show_alert=True)
            else:
                await message.answer(text)
            return
        
        # Purchase item
        user.balance -= price
        
        # Add to inventory
        from sqlalchemy.orm.attributes import flag_modified
        if user.inventory is None:
            user.inventory = {}
        if item_id not in user.inventory:
            user.inventory[item_id] = {
                "quantity": 0,
                "purchased_at": []
            }
        
        user.inventory[item_id]["quantity"] += 1
        user.inventory[item_id]["purchased_at"].append(datetime.utcnow().isoformat())
        flag_modified(user, "inventory")
        
        # Apply effect if consumable
        effect_text = ""
        consume_item = True  # по умолчанию предмет расходуется сразу
        if item["consumable"]:
            effect = item["effect"]
            now = datetime.utcnow()

            if effect == "reset_work_cooldown":
                user.last_work = None
                effect_text = "\n✅ Кулдаун работы снят!"

            elif effect == "reset_mine_cooldown":
                user.last_mine = None
                effect_text = "\n✅ Кулдаун майнинга снят!"

            elif effect == "reset_casino_cooldown":
                user.last_casino = None
                user.last_slots = None
                effect_text = "\n✅ Кулдауны казино и слотов сняты!"

            elif effect == "vip_24h":
                current = user.vip_until if (user.vip_until and user.vip_until > now) else now
                user.vip_until = current + timedelta(hours=24)
                effect_text = "\n✅ VIP на 24 часа! Все кулдауны сняты!"

            elif effect == "vip_7d":
                current = user.vip_until if (user.vip_until and user.vip_until > now) else now
                user.vip_until = current + timedelta(days=7)
                effect_text = "\n✅ VIP на 7 дней! Все кулдауны сняты!"

            elif effect == "vip_30d":
                current = user.vip_until if (user.vip_until and user.vip_until > now) else now
                user.vip_until = current + timedelta(days=30)
                effect_text = "\n✅ VIP на 30 дней! Все кулдауны сняты!"

            elif effect == "luck_boost":
                # Хранится в инвентаре, расходуется при проигрыше в слоты/казино
                consume_item = False  # не удаляем сразу — расходуется в games.py
                effect_text = "\n✅ +20% к следующему выигрышу активировано!"

            elif effect == "exp_boost_1h":
                user.inventory[item_id]["exp_boost_until"] = (now + timedelta(hours=1)).isoformat()
                flag_modified(user, "inventory")
                consume_item = False
                effect_text = "\n✅ x2 опыт на 1 час активирован!"

            elif effect == "income_boost_1h":
                user.inventory[item_id]["income_boost_until"] = (now + timedelta(hours=1)).isoformat()
                flag_modified(user, "inventory")
                consume_item = False
                effect_text = "\n✅ x2 доход от бизнесов на 1 час активирован!"

            elif effect == "mining_boost_2h":
                user.inventory[item_id]["boost_until"] = (now + timedelta(hours=2)).isoformat()
                flag_modified(user, "inventory")
                consume_item = False
                effect_text = "\n✅ x3 майнинг на 2 часа активирован!"

            elif effect == "crypto_signal":
                # Хранится в инвентаре, используется при запросе
                consume_item = False
                effect_text = "\n✅ Крипто-анализатор готов к использованию!"

            elif effect == "tax_shield_24h":
                user.inventory[item_id]["tax_shield_until"] = (now + timedelta(hours=24)).isoformat()
                flag_modified(user, "inventory")
                consume_item = False
                effect_text = "\n✅ Налоговый щит на 24 часа активирован!"

            elif effect == "slots_jackpot":
                # Хранится в инвентаре, расходуется в games.py при следующей игре в слоты
                consume_item = False
                effect_text = "\n✅ Джекпот-тикет готов к использованию!"

            elif effect == "biz_boost_6h":
                user.inventory[item_id]["biz_boost_until"] = (now + timedelta(hours=6)).isoformat()
                flag_modified(user, "inventory")
                consume_item = False
                effect_text = "\n✅ +25% доход от бизнесов на 6 часов активирован!"

            elif effect == "instant_farm_collect":
                # Телепортируем все фермы — сбрасываем last_collect в прошлое
                farms = user.mining_farms or {}
                for fid in farms:
                    farms[fid]["last_collect"] = (now - timedelta(days=365)).isoformat()
                user.mining_farms = farms
                flag_modified(user, "mining_farms")
                effect_text = "\n✅ Все фермы готовы к сбору!"

            elif effect == "crypto_discount":
                # Хранится в инвентаре, расходуется при следующей покупке крипты
                consume_item = False
                effect_text = "\n✅ Скидка -10% на следующую покупку крипты готова!"

            # Расходуем предмет (если consume_item=True — немедленно, иначе при использовании)
            if consume_item:
                user.inventory[item_id]["quantity"] -= 1
                if user.inventory[item_id]["quantity"] <= 0:
                    del user.inventory[item_id]
        
        await UserService.update_balance(
            session, user, 0, "shop_purchase",
            f"Покупка предмета: {item['name']}"
        )
        
        response_text = (
            f"✅ <b>Предмет куплен!</b>\n\n"
            f"{item['name']}\n"
            f"💰 Потрачено: {format_balance(price)}\n"
            f"💼 Баланс: {format_balance(user.balance)}"
            f"{effect_text}"
        )
        
        if callback:
            builder = InlineKeyboardBuilder()
            builder.button(text="🏪 Магазин", callback_data="show_shop")
            builder.button(text="◀️ Назад", callback_data="back_to_menu")
            builder.adjust(1)
            await callback.message.edit_text(response_text, parse_mode="HTML", reply_markup=builder.as_markup())
            await callback.answer()
        else:
            await message.answer(response_text, parse_mode="HTML")


@router.message(Command("inventory"))
@router.message(F.text.lower() == "инвентарь")
async def cmd_inventory(message: Message):
    """Show user inventory"""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name
        )
        
        if not user.inventory:
            await message.answer("🎒 Ваш инвентарь пуст!")
            return
        
        text = "🎒 <b>ВАШ ИНВЕНТАРЬ</b>\n\n"
        
        for item_id, data in user.inventory.items():
            item = SHOP_ITEMS.get(item_id)
            if not item:
                continue
            
            quantity = data.get("quantity", 0)
            if quantity > 0:
                text += f"{item['name']} x{quantity}\n"
        
        await message.answer(text, parse_mode="HTML")


@router.callback_query(F.data == "show_shop")
async def show_shop_callback(callback: CallbackQuery):
    """Show shop via callback"""
    text = "🏪 <b>МАГАЗИН ПРЕДМЕТОВ</b>\n\n"
    
    builder = InlineKeyboardBuilder()
    
    for item_id, item in SHOP_ITEMS.items():
        text += (
            f"{item['name']}\n"
            f"{item['description']}\n"
            f"💰 Цена: {format_balance(item['price'])}\n\n"
        )
        
        builder.button(
            text=f"Купить {item['name']}", 
            callback_data=f"buy_item_{item_id}"
        )
    
    text += "Используйте: купить [название предмета]"
    
    builder.adjust(1)
    builder.button(text="◀️ Назад", callback_data="back_to_menu")
    
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=builder.as_markup())
    await callback.answer()
