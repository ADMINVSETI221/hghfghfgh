"""
Отдельный бот-админка.
Токен задаётся в .env → ADMIN_BOT_TOKEN
Доступен только OWNER_ID и ADMIN_IDS.

Меню:
  🔍 Найти игрока        — поиск по username / ID
  👥 Все игроки          — список с пагинацией
  ⚙️ Настройки игры      — редактирование cooldown'ов, ставок, цен бизнесов
  📊 Статистика           — сводка по серверу

Карточка игрока:
  💰 Выдать/Забрать деньги
  ⬆️ Уровень / Опыт
  🧠 Отметки психиатра
  👑 Выдать/Снять VIP
  🚫 Бан / Разбан
  🔒 Ограничить функции (работа/майн/казино/слоты/бизнес/карточки)
  🗑 Сбросить прогресс
"""
import asyncio
import json
from datetime import datetime, timedelta
from typing import Optional

from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import settings
from services.database import get_db, UserService
from models.database import BUSINESSES, SHOP_ITEMS
from utils.formatters import format_balance

router = Router()   # используется только для регистрации, сам бот стартует отдельно


# ── FSM ───────────────────────────────────────────────────────────────────────

class AdminState(StatesGroup):
    search_input    = State()
    give_money      = State()
    take_money      = State()
    set_level       = State()
    set_exp         = State()
    add_marks       = State()
    give_vip        = State()
    ban_reason      = State()
    edit_setting    = State()
    edit_biz_price  = State()
    biz_upgrade_lvl = State()
    dm_text         = State()
    broadcast_text  = State()
    set_crypto_price = State()
    add_crypto_sym   = State()
    add_crypto_data  = State()


# ── helpers ───────────────────────────────────────────────────────────────────

def is_admin(uid: int) -> bool:
    return uid in settings.all_admin_ids


def user_link(user) -> str:
    name = user.first_name or user.username or str(user.telegram_id)
    return f'<a href="tg://user?id={user.telegram_id}">{name}</a>'


def short_profile(user) -> str:
    stats = user.statistics or {}
    vip_str = ""
    if user.vip_until and datetime.utcnow() < user.vip_until:
        left = user.vip_until - datetime.utcnow()
        h = int(left.total_seconds() // 3600)
        vip_str = f" 👑 VIP {h}ч"
    ban_str = " 🚫 BANNED" if user.is_banned else ""
    limits = user.inventory.get("_limits", {}) if user.inventory else {}
    lim_str = ""
    if limits:
        lim_str = "\n🔒 Ограничения: " + ", ".join(limits.keys())
    marks = stats.get("psychiatrist_marks", 0)
    biz_count = len(user.businesses) if user.businesses else 0
    needed_xp = user.level * 100
    return (
        f"👤 {user_link(user)}{ban_str}{vip_str}\n"
        f"🆔 <code>{user.telegram_id}</code>\n"
        f"💰 Баланс: <b>{format_balance(user.balance)}</b>\n"
        f"⭐ Ур.{user.level}  XP {user.experience}/{needed_xp}\n"
        f"🧠 Психиатр: {marks}  🏢 Бизнесов: {biz_count}\n"
        f"💼 Работ: {stats.get('work_count',0)}  ⛏ Майн: {stats.get('mine_count',0)}"
        + lim_str
    )


def player_keyboard(user, page: int = 0) -> InlineKeyboardBuilder:
    uid = user.telegram_id
    kb = InlineKeyboardBuilder()
    limits = (user.inventory or {}).get("_limits", {})

    kb.button(text="💰 Выдать деньги",   callback_data=f"ap:give:{uid}")
    kb.button(text="💸 Забрать деньги",  callback_data=f"ap:take:{uid}")
    kb.button(text="⬆️ Уровень",         callback_data=f"ap:lvl:{uid}")
    kb.button(text="📊 Опыт",             callback_data=f"ap:exp:{uid}")
    kb.button(text="🧠 +Психиатр",       callback_data=f"ap:marks:{uid}")
    kb.button(text="🏢 Бизнесы",         callback_data=f"ap:biz:{uid}")
    kb.button(text="📨 Написать",         callback_data=f"ap:dm:{uid}")
    if user.vip_until and datetime.utcnow() < user.vip_until:
        kb.button(text="👑 Снять VIP",    callback_data=f"ap:rmvip:{uid}")
    else:
        kb.button(text="👑 Выдать VIP",   callback_data=f"ap:vip:{uid}")
    if user.is_banned:
        kb.button(text="✅ Разбанить",    callback_data=f"ap:unban:{uid}")
    else:
        kb.button(text="🚫 Забанить",     callback_data=f"ap:ban:{uid}")
    kb.button(text="🔒 Ограничения",      callback_data=f"ap:limits:{uid}")
    kb.button(text="🗑 Сбросить всё",    callback_data=f"ap:reset:{uid}")
    kb.button(text="🔄 Обновить",        callback_data=f"ap:view:{uid}:{page}")
    kb.button(text="◀️ К списку",         callback_data=f"ap:list:0")
    kb.adjust(2, 2, 2, 2, 2, 2, 2)
    return kb


def limits_keyboard(user) -> InlineKeyboardBuilder:
    uid = user.telegram_id
    limits = (user.inventory or {}).get("_limits", {})
    kb = InlineKeyboardBuilder()
    actions = [
        ("работа",   "work"),
        ("майнинг",  "mine"),
        ("казино",   "casino"),
        ("слоты",    "slots"),
        ("бизнес",   "business"),
        ("карточки", "cards"),
        ("дейли",    "daily"),
    ]
    for label, key in actions:
        icon = "🔴" if key in limits else "🟢"
        kb.button(text=f"{icon} {label}", callback_data=f"ap:togglelim:{uid}:{key}")
    kb.button(text="◀️ Назад", callback_data=f"ap:view:{uid}:0")
    kb.adjust(2)
    return kb


# ── /start ────────────────────────────────────────────────────────────────────

@router.message(CommandStart())
async def admin_start(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    await show_main_menu(message)


async def show_main_menu(event, edit: bool = False):
    text = (
        "🛡 <b>АДМИН-ПАНЕЛЬ</b>\n\n"
        "Выберите действие:"
    )
    kb = InlineKeyboardBuilder()
    kb.button(text="🔍 Найти игрока",    callback_data="ap:search")
    kb.button(text="👥 Все игроки",       callback_data="ap:list:0")
    kb.button(text="⚙️ Настройки игры",  callback_data="ap:settings:main")
    kb.button(text="📊 Статистика",       callback_data="ap:stats")
    kb.button(text="🏆 Топ игроков",      callback_data="ap:top:balance")
    kb.button(text="📢 Рассылка",         callback_data="ap:broadcast")
    kb.adjust(2, 2, 2)
    if edit:
        try:
            await event.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
        except Exception:
            pass
        await event.answer()
    else:
        await event.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())


# ── menu callback ─────────────────────────────────────────────────────────────

@router.callback_query(F.data == "ap:menu")
async def cb_menu(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await show_main_menu(callback, edit=True)


# ── search ────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "ap:search")
async def cb_search(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminState.search_input)
    await callback.message.edit_text(
        "🔍 Введите <b>username</b> (без @) или <b>Telegram ID</b> игрока:",
        parse_mode="HTML",
        reply_markup=_cancel_kb()
    )
    await callback.answer()


@router.message(AdminState.search_input)
async def search_input(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.clear()
    query = message.text.strip().lstrip("@")

    async with get_db() as session:
        user = None
        if query.isdigit():
            user = await UserService.get_by_telegram_id(session, int(query))
        if not user:
            from sqlalchemy import select
            from models.database import User
            result = await session.execute(
                select(User).where(User.username.ilike(f"%{query}%"))
            )
            users = result.scalars().all()
            if len(users) == 1:
                user = users[0]
            elif len(users) > 1:
                kb = InlineKeyboardBuilder()
                text = f"🔍 Найдено {len(users)} игроков:\n\n"
                for u in users[:10]:
                    text += f"• {u.first_name or '?'} @{u.username or '?'}  <code>{u.telegram_id}</code>\n"
                    kb.button(
                        text=f"{u.first_name or u.username or u.telegram_id}",
                        callback_data=f"ap:view:{u.telegram_id}:0"
                    )
                kb.button(text="◀️ Меню", callback_data="ap:menu")
                kb.adjust(1)
                await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())
                return

        if not user:
            kb = InlineKeyboardBuilder()
            kb.button(text="◀️ Меню", callback_data="ap:menu")
            await message.answer("❌ Игрок не найден!", reply_markup=kb.as_markup())
            return

        text = short_profile(user)
        await message.answer(
            text, parse_mode="HTML",
            reply_markup=player_keyboard(user).as_markup()
        )


# ── player list ───────────────────────────────────────────────────────────────

PAGE = 8

@router.callback_query(F.data.startswith("ap:list:"))
async def cb_list(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    page = int(callback.data.split(":")[2])
    async with get_db() as session:
        from sqlalchemy import select
        from models.database import User
        result = await session.execute(select(User).order_by(User.balance.desc()))
        all_users = result.scalars().all()

    total = len(all_users)
    total_pages = max(1, (total + PAGE - 1) // PAGE)
    page = max(0, min(page, total_pages - 1))
    chunk = all_users[page * PAGE:(page + 1) * PAGE]

    text = f"👥 <b>Игроки</b> (стр. {page+1}/{total_pages}, всего: {total})\n\n"
    kb = InlineKeyboardBuilder()
    for u in chunk:
        ban = "🚫" if u.is_banned else ""
        vip = "👑" if u.vip_until and datetime.utcnow() < u.vip_until else ""
        label = f"{ban}{vip} {u.first_name or u.username or u.telegram_id}  {format_balance(u.balance)}"
        kb.button(text=label, callback_data=f"ap:view:{u.telegram_id}:{page}")
    kb.adjust(1)

    nav = []
    if page > 0:
        nav.append(("◀️", f"ap:list:{page-1}"))
    nav.append(("🏠", "ap:menu"))
    if page < total_pages - 1:
        nav.append(("▶️", f"ap:list:{page+1}"))
    for label, cb in nav:
        kb.button(text=label, callback_data=cb)
    kb.adjust(*([1] * len(chunk)), len(nav))

    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


# ── view player ───────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:view:"))
async def cb_view(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split(":")
    uid = int(parts[2])
    page = int(parts[3]) if len(parts) > 3 else 0
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
    if not user:
        await callback.answer("❌ Не найден!", show_alert=True)
        return
    await callback.message.edit_text(
        short_profile(user), parse_mode="HTML",
        reply_markup=player_keyboard(user, page).as_markup()
    )
    await callback.answer()


# ── give money ────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:give:"))
async def cb_give(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    await state.set_state(AdminState.give_money)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "💰 Введите сумму для выдачи:", reply_markup=_cancel_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


@router.message(AdminState.give_money)
async def input_give(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data["target_uid"]
    try:
        amount = float(message.text.replace(" ", "").replace(",", "."))
        assert amount > 0
    except Exception:
        await message.answer("❌ Введите положительное число:")
        return
    await state.clear()
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        user, _ = await UserService.update_balance(session, user, amount, "admin_give", f"Выдача админом")
        await session.commit()
        await session.refresh(user)
    await message.answer(
        f"✅ Выдано <b>{format_balance(amount)}</b>\n💼 Баланс: {format_balance(user.balance)}",
        parse_mode="HTML",
        reply_markup=_back_kb(f"ap:view:{uid}:0")
    )
    try:
        await message.bot.send_message(uid, f"💰 Вам выдано <b>{format_balance(amount)}</b> монет!", parse_mode="HTML")
    except Exception:
        pass


# ── take money ────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:take:"))
async def cb_take(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    await state.set_state(AdminState.take_money)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "💸 Введите сумму для снятия:", reply_markup=_cancel_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


@router.message(AdminState.take_money)
async def input_take(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data["target_uid"]
    try:
        amount = float(message.text.replace(" ", "").replace(",", "."))
        assert amount > 0
    except Exception:
        await message.answer("❌ Введите положительное число:")
        return
    await state.clear()
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        taken = min(amount, user.balance)
        user, _ = await UserService.update_balance(session, user, -taken, "admin_take", "Снятие админом")
        await session.commit()
        await session.refresh(user)
    await message.answer(
        f"✅ Снято <b>{format_balance(taken)}</b>\n💼 Баланс: {format_balance(user.balance)}",
        parse_mode="HTML",
        reply_markup=_back_kb(f"ap:view:{uid}:0")
    )


# ── set level ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:lvl:"))
async def cb_lvl(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    await state.set_state(AdminState.set_level)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "⬆️ Введите новый уровень (1–9999):", reply_markup=_cancel_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


@router.message(AdminState.set_level)
async def input_level(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data["target_uid"]
    try:
        lvl = int(message.text.strip())
        assert 1 <= lvl <= 9999
    except Exception:
        await message.answer("❌ Введите число от 1 до 9999:")
        return
    await state.clear()
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        user.level = lvl
        await session.commit()
    await message.answer(
        f"✅ Уровень установлен: <b>{lvl}</b>",
        parse_mode="HTML",
        reply_markup=_back_kb(f"ap:view:{uid}:0")
    )


# ── set exp ───────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:exp:"))
async def cb_exp(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    await state.set_state(AdminState.set_exp)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "📊 Введите количество XP для добавления (можно отрицательное):",
        reply_markup=_cancel_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


@router.message(AdminState.set_exp)
async def input_exp(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data["target_uid"]
    try:
        exp = int(message.text.strip())
    except Exception:
        await message.answer("❌ Введите целое число:")
        return
    await state.clear()
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        user.experience = max(0, user.experience + exp)
        await session.commit()
        await session.refresh(user)
    await message.answer(
        f"✅ Опыт изменён. Теперь: <b>{user.experience}/{user.level*100} XP</b>",
        parse_mode="HTML",
        reply_markup=_back_kb(f"ap:view:{uid}:0")
    )


# ── psychiatrist marks ────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:marks:"))
async def cb_marks(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    await state.set_state(AdminState.add_marks)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "🧠 Введите количество отметок психиатра (можно отрицательное):",
        reply_markup=_cancel_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


@router.message(AdminState.add_marks)
async def input_marks(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data["target_uid"]
    try:
        marks = int(message.text.strip())
    except Exception:
        await message.answer("❌ Введите целое число:")
        return
    await state.clear()
    from sqlalchemy.orm.attributes import flag_modified
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        if user.statistics is None:
            user.statistics = {}
        old = user.statistics.get("psychiatrist_marks", 0)
        user.statistics["psychiatrist_marks"] = max(0, old + marks)
        flag_modified(user, "statistics")
        await session.commit()
        new = user.statistics["psychiatrist_marks"]
    await message.answer(
        f"✅ Отметки психиатра: <b>{old} → {new}</b>",
        parse_mode="HTML",
        reply_markup=_back_kb(f"ap:view:{uid}:0")
    )
    try:
        sign = "+" if marks >= 0 else ""
        await message.bot.send_message(uid, f"🧠 Ваши отметки психиатра изменены: <b>{sign}{marks}</b>\nВсего: <b>{new}</b>", parse_mode="HTML")
    except Exception:
        pass


# ── VIP ───────────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:vip:"))
async def cb_vip(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    await state.set_state(AdminState.give_vip)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "👑 Введите количество дней VIP:", reply_markup=_cancel_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


@router.message(AdminState.give_vip)
async def input_vip(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data["target_uid"]
    try:
        days = int(message.text.strip())
        assert days >= 1
    except Exception:
        await message.answer("❌ Введите целое число дней ≥ 1:")
        return
    await state.clear()
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        base = max(datetime.utcnow(), user.vip_until or datetime.utcnow())
        user.vip_until = base + timedelta(days=days)
        await session.commit()
    await message.answer(
        f"✅ VIP выдан на <b>{days} дн.</b>",
        parse_mode="HTML",
        reply_markup=_back_kb(f"ap:view:{uid}:0")
    )
    try:
        await message.bot.send_message(uid, f"👑 Вам выдан VIP на <b>{days} дней</b>!", parse_mode="HTML")
    except Exception:
        pass


@router.callback_query(F.data.startswith("ap:rmvip:"))
async def cb_rmvip(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        user.vip_until = None
        await session.commit()
        await session.refresh(user)
    await callback.message.edit_text(
        short_profile(user), parse_mode="HTML",
        reply_markup=player_keyboard(user).as_markup()
    )
    await callback.answer("✅ VIP снят!")


# ── ban / unban ───────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:ban:"))
async def cb_ban(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    if uid in settings.all_admin_ids:
        await callback.answer("❌ Нельзя банить администратора!", show_alert=True)
        return
    await state.set_state(AdminState.ban_reason)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "🚫 Введите причину бана (или «-» без причины):",
        reply_markup=_cancel_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


@router.message(AdminState.ban_reason)
async def input_ban_reason(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data["target_uid"]
    reason = message.text.strip()
    if reason == "-":
        reason = "Не указана"
    await state.clear()
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        user.is_banned = True
        user.ban_reason = reason
        await session.commit()
        await session.refresh(user)
    await message.answer(
        f"🚫 Игрок забанен.\nПричина: <b>{reason}</b>",
        parse_mode="HTML",
        reply_markup=_back_kb(f"ap:view:{uid}:0")
    )
    try:
        await message.bot.send_message(uid, f"🚫 Вы заблокированы.\nПричина: <b>{reason}</b>", parse_mode="HTML")
    except Exception:
        pass


@router.callback_query(F.data.startswith("ap:unban:"))
async def cb_unban(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        user.is_banned = False
        user.ban_reason = None
        await session.commit()
        await session.refresh(user)
    await callback.message.edit_text(
        short_profile(user), parse_mode="HTML",
        reply_markup=player_keyboard(user).as_markup()
    )
    await callback.answer("✅ Разбанен!")
    try:
        await callback.bot.send_message(uid, "✅ Вы разблокированы!")
    except Exception:
        pass


# ── limits ────────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:limits:"))
async def cb_limits(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
    limits = (user.inventory or {}).get("_limits", {})
    active = ", ".join(limits.keys()) if limits else "нет"
    await callback.message.edit_text(
        f"🔒 <b>Ограничения</b> для {user_link(user)}\n"
        f"Активные: <b>{active}</b>\n\n"
        f"🟢 = разрешено  🔴 = заблокировано",
        parse_mode="HTML",
        reply_markup=limits_keyboard(user).as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("ap:togglelim:"))
async def cb_togglelim(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split(":")
    uid = int(parts[2])
    key = parts[3]
    from sqlalchemy.orm.attributes import flag_modified
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        if user.inventory is None:
            user.inventory = {}
        limits = user.inventory.get("_limits", {})
        if key in limits:
            del limits[key]
            action = "снято"
        else:
            limits[key] = True
            action = "установлено"
        user.inventory["_limits"] = limits
        flag_modified(user, "inventory")
        await session.commit()
        await session.refresh(user)
    await callback.message.edit_text(
        f"🔒 <b>Ограничения</b> для {user_link(user)}\n"
        f"✅ Ограничение <b>{key}</b> {action}\n\n"
        f"🟢 = разрешено  🔴 = заблокировано",
        parse_mode="HTML",
        reply_markup=limits_keyboard(user).as_markup()
    )
    await callback.answer(f"{'🔴' if action=='установлено' else '🟢'} {key} {action}")


# ── reset ─────────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:reset:"))
async def cb_reset(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    # Confirm
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Да, сбросить!", callback_data=f"ap:resetconfirm:{uid}")
    kb.button(text="❌ Отмена",        callback_data=f"ap:view:{uid}:0")
    kb.adjust(2)
    await callback.message.edit_text(
        "⚠️ Вы уверены? Прогресс игрока будет полностью сброшен!",
        reply_markup=kb.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("ap:resetconfirm:"))
async def cb_reset_confirm(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        user.balance = settings.START_BALANCE
        user.experience = 0
        user.level = 1
        user.businesses = {}
        user.inventory = {}
        user.statistics = {}
        user.vip_until = None
        user.last_work = user.last_mine = user.last_daily = None
        user.last_casino = user.last_slots = user.last_psychiatrist = None
        user.last_lucky_block = None
        await session.commit()
        await session.refresh(user)
    await callback.message.edit_text(
        short_profile(user), parse_mode="HTML",
        reply_markup=player_keyboard(user).as_markup()
    )
    await callback.answer("✅ Прогресс сброшен!")


# ── stats ─────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "ap:stats")
async def cb_stats(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    from sqlalchemy import select, func
    from models.database import User, Transaction
    async with get_db() as session:
        total_users = (await session.execute(select(func.count(User.id)))).scalar()
        banned = (await session.execute(select(func.count(User.id)).where(User.is_banned == True))).scalar()
        total_balance = (await session.execute(select(func.sum(User.balance)))).scalar() or 0
        vip_count = (await session.execute(
            select(func.count(User.id)).where(User.vip_until > datetime.utcnow())
        )).scalar()
        tx_count = (await session.execute(select(func.count(Transaction.id)))).scalar()

    kb = InlineKeyboardBuilder()
    kb.button(text="◀️ Меню", callback_data="ap:menu")
    await callback.message.edit_text(
        f"📊 <b>СТАТИСТИКА СЕРВЕРА</b>\n\n"
        f"👥 Игроков: <b>{total_users}</b>\n"
        f"🚫 Забанено: <b>{banned}</b>\n"
        f"👑 VIP: <b>{vip_count}</b>\n"
        f"💰 Деньги в обороте: <b>{format_balance(total_balance)}</b>\n"
        f"📋 Транзакций: <b>{tx_count}</b>",
        parse_mode="HTML",
        reply_markup=kb.as_markup()
    )
    await callback.answer()


# ── settings ──────────────────────────────────────────────────────────────────

def _settings_main_kb():
    kb = InlineKeyboardBuilder()
    kb.button(text="⏱ Кулдауны",        callback_data="ap:settings:cooldowns")
    kb.button(text="🎰 Казино/Слоты",    callback_data="ap:settings:casino")
    kb.button(text="🏢 Цены бизнесов",   callback_data="ap:settings:bizprices:0")
    kb.button(text="💰 Стартовый баланс", callback_data="ap:settings:startbal")
    kb.button(text="💹 Криптовалюта",    callback_data="ap:crypto:main")
    kb.button(text="◀️ Меню",             callback_data="ap:menu")
    kb.adjust(2, 2, 2)
    return kb


@router.callback_query(F.data == "ap:settings:main")
async def cb_settings_main(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    await callback.message.edit_text(
        "⚙️ <b>НАСТРОЙКИ ИГРЫ</b>\n\nВыберите раздел:",
        parse_mode="HTML",
        reply_markup=_settings_main_kb().as_markup()
    )
    await callback.answer()


@router.callback_query(F.data == "ap:settings:cooldowns")
async def cb_settings_cooldowns(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    s = settings
    kb = InlineKeyboardBuilder()
    items = [
        ("💼 Работа",    "WORK_COOLDOWN",         s.WORK_COOLDOWN),
        ("⛏ Майнинг",   "MINE_COOLDOWN",         s.MINE_COOLDOWN),
        ("🎁 Дейли",    "DAILY_COOLDOWN",        s.DAILY_COOLDOWN),
        ("🧠 Психиатр", "PSYCHIATRIST_COOLDOWN", s.PSYCHIATRIST_COOLDOWN),
        ("🎰 Казино",   "CASINO_COOLDOWN",       s.CASINO_COOLDOWN),
        ("🎰 Слоты",    "SLOTS_COOLDOWN",        s.SLOTS_COOLDOWN),
    ]
    text = "⏱ <b>КУЛДАУНЫ</b> (в секундах)\n\n"
    for label, key, val in items:
        text += f"{label}: <b>{val}с</b> ({val//60}м)\n"
        kb.button(text=f"✏️ {label}", callback_data=f"ap:setedit:{key}")
    kb.button(text="◀️ Настройки", callback_data="ap:settings:main")
    kb.adjust(2, 2, 2, 1)
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data == "ap:settings:casino")
async def cb_settings_casino(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    s = settings
    kb = InlineKeyboardBuilder()
    items = [
        ("💰 Мин ставка казино",  "MIN_CASINO_BET",  s.MIN_CASINO_BET),
        ("💰 Макс ставка казино", "MAX_CASINO_BET",  s.MAX_CASINO_BET),
        ("💰 Мин ставка слоты",   "MIN_SLOTS_BET",   s.MIN_SLOTS_BET),
        ("💰 Макс ставка слоты",  "MAX_SLOTS_BET",   s.MAX_SLOTS_BET),
        ("🎲 Множители казино",   "CASINO_WIN_MULTIPLIERS", s.CASINO_WIN_MULTIPLIERS),
        ("🎲 Веса казино",        "CASINO_WIN_WEIGHTS",     s.CASINO_WIN_WEIGHTS),
    ]
    text = "🎰 <b>КАЗИНО / СЛОТЫ</b>\n\n"
    for label, key, val in items:
        text += f"{label}: <b>{val}</b>\n"
        kb.button(text=f"✏️ {label}", callback_data=f"ap:setedit:{key}")
    kb.button(text="◀️ Настройки", callback_data="ap:settings:main")
    kb.adjust(2, 2, 2, 1)
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data == "ap:settings:startbal")
async def cb_settings_startbal(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    kb = InlineKeyboardBuilder()
    kb.button(text="✏️ Изменить", callback_data="ap:setedit:START_BALANCE")
    kb.button(text="◀️ Настройки", callback_data="ap:settings:main")
    kb.adjust(2)
    await callback.message.edit_text(
        f"💰 <b>Стартовый баланс</b>\n\nТекущее значение: <b>{settings.START_BALANCE}</b>",
        parse_mode="HTML",
        reply_markup=kb.as_markup()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("ap:settings:bizprices:"))
async def cb_settings_bizprices(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    page = int(callback.data.split(":")[3])
    biz_list = list(BUSINESSES.items())
    total_pages = max(1, (len(biz_list) + 5 - 1) // 5)
    page = max(0, min(page, total_pages - 1))
    chunk = biz_list[page * 5: (page + 1) * 5]

    text = f"🏢 <b>ЦЕНЫ БИЗНЕСОВ</b>  (стр. {page+1}/{total_pages})\n\n"
    kb = InlineKeyboardBuilder()
    for bid, biz in chunk:
        text += (
            f"{biz['name']}\n"
            f"  Цена: {format_balance(biz['base_cost'])}  Доход: {format_balance(biz['base_income'])}/ч\n\n"
        )
        kb.button(text=f"💰 {biz['name']}", callback_data=f"ap:editbiz:{bid}:{page}")
    kb.adjust(1)

    nav = []
    if page > 0:
        nav.append(("◀️", f"ap:settings:bizprices:{page-1}"))
    nav.append(("🏠 Настройки", "ap:settings:main"))
    if page < total_pages - 1:
        nav.append(("▶️", f"ap:settings:bizprices:{page+1}"))
    for label, cb in nav:
        kb.button(text=label, callback_data=cb)
    kb.adjust(*([1] * len(chunk)), len(nav))

    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("ap:editbiz:"))
async def cb_editbiz(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split(":")
    bid = parts[2]
    back_page = int(parts[3])
    biz = BUSINESSES.get(bid)
    if not biz:
        await callback.answer("❌ Не найден!", show_alert=True)
        return
    await state.set_state(AdminState.edit_biz_price)
    await state.update_data(bid=bid, back_page=back_page)
    kb = InlineKeyboardBuilder()
    kb.button(text="❌ Отмена", callback_data=f"ap:settings:bizprices:{back_page}")
    await callback.message.edit_text(
        f"🏢 <b>{biz['name']}</b>\n\n"
        f"Текущая цена: <b>{format_balance(biz['base_cost'])}</b>\n"
        f"Текущий доход: <b>{format_balance(biz['base_income'])}/ч</b>\n\n"
        f"Введите новые значения в формате:\n"
        f"<code>цена доход</code>\n"
        f"Пример: <code>5000 300</code>",
        parse_mode="HTML",
        reply_markup=kb.as_markup()
    )
    await callback.answer()


@router.message(AdminState.edit_biz_price)
async def input_biz_price(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    bid = data["bid"]
    back_page = data.get("back_page", 0)
    try:
        parts = message.text.strip().split()
        cost = float(parts[0])
        income = float(parts[1])
        assert cost > 0 and income > 0
    except Exception:
        await message.answer("❌ Формат: <code>цена доход</code>  Пример: <code>5000 300</code>", parse_mode="HTML")
        return
    await state.clear()
    biz = BUSINESSES.get(bid)
    BUSINESSES[bid]["base_cost"] = cost
    BUSINESSES[bid]["base_income"] = income
    kb = InlineKeyboardBuilder()
    kb.button(text="◀️ К бизнесам", callback_data=f"ap:settings:bizprices:{back_page}")
    await message.answer(
        f"✅ <b>{biz['name']}</b> обновлён!\n"
        f"💰 Цена: {format_balance(cost)}\n"
        f"📈 Доход: {format_balance(income)}/ч\n\n"
        f"⚠️ Изменения действуют до перезапуска бота.",
        parse_mode="HTML",
        reply_markup=kb.as_markup()
    )


# ── generic setting edit ──────────────────────────────────────────────────────

SETTING_LABELS = {
    "WORK_COOLDOWN":          ("⏱ Кулдаун работы (сек)",   "int"),
    "MINE_COOLDOWN":          ("⏱ Кулдаун майнинга (сек)", "int"),
    "DAILY_COOLDOWN":         ("⏱ Кулдаун дейли (сек)",    "int"),
    "PSYCHIATRIST_COOLDOWN":  ("⏱ Кулдаун психиатра (сек)","int"),
    "CASINO_COOLDOWN":        ("⏱ Кулдаун казино (сек)",   "int"),
    "SLOTS_COOLDOWN":         ("⏱ Кулдаун слотов (сек)",   "int"),
    "MIN_CASINO_BET":         ("💰 Мин ставка казино",      "int"),
    "MAX_CASINO_BET":         ("💰 Макс ставка казино",     "int"),
    "MIN_SLOTS_BET":          ("💰 Мин ставка слоты",       "int"),
    "MAX_SLOTS_BET":          ("💰 Макс ставка слоты",      "int"),
    "CASINO_WIN_MULTIPLIERS": ("🎲 Множители (через запятую)", "str"),
    "CASINO_WIN_WEIGHTS":     ("🎲 Веса (через запятую)",      "str"),
    "START_BALANCE":          ("💰 Стартовый баланс",       "float"),
    "TAX_RATE":               ("💸 Налог (0.0–1.0)",        "float"),
}


@router.callback_query(F.data.startswith("ap:setedit:"))
async def cb_setedit(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    key = callback.data[len("ap:setedit:"):]
    info = SETTING_LABELS.get(key)
    if not info:
        await callback.answer("❌ Неизвестная настройка!", show_alert=True)
        return
    label, typ = info
    current = getattr(settings, key, "?")
    await state.set_state(AdminState.edit_setting)
    await state.update_data(setting_key=key, setting_type=typ)
    kb = InlineKeyboardBuilder()
    kb.button(text="❌ Отмена", callback_data="ap:settings:main")
    await callback.message.edit_text(
        f"✏️ <b>{label}</b>\n\nТекущее значение: <code>{current}</code>\n\nВведите новое значение:",
        parse_mode="HTML",
        reply_markup=kb.as_markup()
    )
    await callback.answer()


@router.message(AdminState.edit_setting)
async def input_setting(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    key = data["setting_key"]
    typ = data["setting_type"]
    raw = message.text.strip()
    try:
        if typ == "int":
            val = int(raw)
        elif typ == "float":
            val = float(raw)
        else:
            val = raw
    except Exception:
        await message.answer(f"❌ Неверный формат для типа {typ}. Попробуйте ещё раз:")
        return
    await state.clear()
    try:
        object.__setattr__(settings, key, val)
    except Exception:
        settings.__dict__[key] = val
    label = SETTING_LABELS.get(key, (key,))[0]
    kb = InlineKeyboardBuilder()
    kb.button(text="⚙️ Настройки", callback_data="ap:settings:main")
    await message.answer(
        f"✅ <b>{label}</b> обновлено!\n"
        f"Новое значение: <code>{val}</code>\n\n"
        f"⚠️ До перезапуска. Для постоянного сохранения обновите .env",
        parse_mode="HTML",
        reply_markup=kb.as_markup()
    )




# ── Бизнесы игрока (просмотр + улучшение) ─────────────────────────────────────

@router.callback_query(F.data.startswith("ap:biz:"))
async def cb_biz(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        if not user:
            await callback.answer("Игрок не найден", show_alert=True)
            return

        businesses = user.businesses or {}
        if not businesses:
            kb = InlineKeyboardBuilder()
            kb.button(text="◀️ Назад", callback_data=f"ap:view:{uid}:0")
            await callback.message.edit_text(
                f"🏢 У игрока <b>{user.first_name}</b> нет бизнесов.",
                parse_mode="HTML", reply_markup=kb.as_markup()
            )
            await callback.answer()
            return

        lines = []
        for key, data in businesses.items():
            bid = key
            for b in BUSINESSES:
                if key == b or key.startswith(b + "_"):
                    bid = b
                    break
            biz = BUSINESSES.get(bid)
            name = biz["name"] if biz else key
            lvl = data.get("level", 1)
            max_lvl = biz.get("max_level", 10) if biz else 10
            lines.append(f"  {name}: ур. {lvl}/{max_lvl}")

        biz_count = len(businesses)
        details_head = "\n".join(lines[:40])
        overflow = f"\n  ... и ещё {len(lines)-40}" if len(lines) > 40 else ""
        text = (
            f"🏢 <b>Бизнесы игрока {user.first_name}</b>\n\n"
            + details_head
            + overflow
            + f"\n\nВсего бизнесов: {biz_count}"
        )
        kb = InlineKeyboardBuilder()
        kb.button(text="⬆️ Улучшить все до уровня", callback_data=f"ap:biz_upg:{uid}")
        kb.button(text="🗑 Сбросить бизнесы",        callback_data=f"ap:biz_clear:{uid}")
        kb.button(text="◀️ Назад",                    callback_data=f"ap:view:{uid}:0")
        kb.adjust(1)
        await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("ap:biz_upg:"))
async def cb_biz_upg_ask(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    await state.set_state(AdminState.biz_upgrade_lvl)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "📊 Введите целевой уровень для всех бизнесов:\n\n"
        "• Одно число: <code>10</code> → всем ур. 10\n"
        "• Диапазон: <code>5-30</code> → каждому случайный ур. 5–30",
        parse_mode="HTML",
        reply_markup=_cancel_kb(f"ap:biz:{uid}")
    )
    await callback.answer()


@router.message(AdminState.biz_upgrade_lvl)
async def input_biz_upgrade_lvl(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data.get("target_uid")
    await state.clear()

    level_arg = message.text.strip()
    level_min = level_max = None

    if "-" in level_arg:
        try:
            a, b = level_arg.split("-", 1)
            level_min, level_max = int(a), int(b)
            if level_min < 1 or level_max < level_min:
                raise ValueError
        except ValueError:
            await message.answer("❌ Неверный диапазон. Пример: <code>5-30</code>", parse_mode="HTML")
            return
    else:
        try:
            level_min = level_max = int(level_arg)
            if level_min < 1:
                raise ValueError
        except ValueError:
            await message.answer("❌ Неверный уровень.", parse_mode="HTML")
            return

    import random as _rnd
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified as _fm
        user = await UserService.get_by_telegram_id(session, uid)
        if not user or not user.businesses:
            await message.answer("❌ Игрок или бизнесы не найдены.")
            return
        changed = 0
        for key in list(user.businesses.keys()):
            bid = key
            for b in BUSINESSES:
                if key == b or key.startswith(b + "_"):
                    bid = b
                    break
            biz = BUSINESSES.get(bid)
            if not biz:
                continue
            max_lvl = biz.get("max_level", 10)
            tlvl = min(level_min if level_min == level_max else _rnd.randint(level_min, level_max), max_lvl)
            user.businesses[key]["level"] = tlvl
            changed += 1
        _fm(user, "businesses")
        await session.commit()
        range_str = f"{level_min}–{level_max}" if level_min != level_max else str(level_min)
        await message.answer(
            f"✅ Улучшено <b>{changed}</b> бизнесов игрока <b>{user.first_name}</b> до ур. <b>{range_str}</b>",
            parse_mode="HTML"
        )
        try:
            await message.bot.send_message(
                uid,
                f"🏢 <b>Ваши бизнесы улучшены!</b>\nУровень: <b>{range_str}</b>  |  Бизнесов: <b>{changed}</b>",
                parse_mode="HTML"
            )
        except Exception:
            pass


@router.callback_query(F.data.startswith("ap:biz_clear:"))
async def cb_biz_clear(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified as _fm
        user = await UserService.get_by_telegram_id(session, uid)
        if not user:
            await callback.answer("Не найден", show_alert=True)
            return
        count = len(user.businesses or {})
        user.businesses = {}
        _fm(user, "businesses")
        await session.commit()
    await callback.message.edit_text(
        f"✅ Все бизнесы игрока <b>{user.first_name}</b> удалены ({count} шт.)",
        parse_mode="HTML",
        reply_markup=_back_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


# ── Написать игроку (DM) ───────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:dm:"))
async def cb_dm_ask(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    await state.set_state(AdminState.dm_text)
    await state.update_data(target_uid=uid)
    await callback.message.edit_text(
        "📨 Введите сообщение для отправки игроку:\n\n"
        "<i>Поддерживается HTML-разметка</i>",
        parse_mode="HTML",
        reply_markup=_cancel_kb(f"ap:view:{uid}:0")
    )
    await callback.answer()


@router.message(AdminState.dm_text)
async def input_dm_text(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data.get("target_uid")
    await state.clear()

    try:
        await message.bot.send_message(
            uid,
            f"📨 <b>Сообщение от администратора:</b>\n\n{message.text}",
            parse_mode="HTML"
        )
        await message.answer(f"✅ Сообщение доставлено игроку <code>{uid}</code>.", parse_mode="HTML")
    except Exception as e:
        await message.answer(f"❌ Не удалось отправить: {e}")


# ── Топ игроков ────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ap:top:"))
async def cb_top(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    sort_by = callback.data.split(":")[2]  # balance | level | businesses
    async with get_db() as session:
        from sqlalchemy import select
        from models.database import User
        if sort_by == "level":
            stmt = select(User).order_by(User.level.desc(), User.experience.desc()).limit(15)
            title = "🏆 ТОП-15 по уровню"
        elif sort_by == "businesses":
            users_all = await UserService.get_all_users(session)
            users_all.sort(key=lambda u: len(u.businesses or {}), reverse=True)
            users_all = users_all[:15]
            title = "🏆 ТОП-15 по бизнесам"
            lines = []
            for i, u in enumerate(users_all, 1):
                biz_cnt = len(u.businesses or {})
                lines.append(f"{i}. {u.first_name or u.username} — {biz_cnt} бизнесов")
            kb = InlineKeyboardBuilder()
            kb.button(text="💰 Топ по балансу", callback_data="ap:top:balance")
            kb.button(text="⭐ Топ по уровню",  callback_data="ap:top:level")
            kb.button(text="◀️ Меню",            callback_data="ap:menu")
            kb.adjust(2, 1)
            await callback.message.edit_text(
                f"<b>{title}</b>\n\n" + "\n".join(lines),
                parse_mode="HTML", reply_markup=kb.as_markup()
            )
            await callback.answer()
            return
        else:
            stmt = select(User).order_by(User.balance.desc()).limit(15)
            title = "🏆 ТОП-15 по балансу"

        result = await session.execute(stmt)
        users = result.scalars().all()

    lines = []
    for i, u in enumerate(users, 1):
        if sort_by == "level":
            val = f"ур. {u.level} ({u.experience} XP)"
        else:
            val = format_balance(u.balance)
        status = "🚫" if u.is_banned else ""
        lines.append(f"{i}. {u.first_name or u.username} {status}\n   {val}")

    kb = InlineKeyboardBuilder()
    kb.button(text="⭐ Топ по уровню",  callback_data="ap:top:level")
    kb.button(text="🏢 Топ по бизнесам", callback_data="ap:top:businesses")
    kb.button(text="◀️ Меню",            callback_data="ap:menu")
    kb.adjust(2, 1)
    await callback.message.edit_text(
        f"<b>{title}</b>\n\n" + "\n".join(lines),
        parse_mode="HTML", reply_markup=kb.as_markup()
    )
    await callback.answer()


# ── Рассылка из admin bot ──────────────────────────────────────────────────────

@router.callback_query(F.data == "ap:broadcast")
async def cb_broadcast_ask(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminState.broadcast_text)
    await callback.message.edit_text(
        "📢 <b>Рассылка</b>\n\nВведите текст для отправки ВСЕМ игрокам:\n\n"
        "<i>Поддерживается HTML. Забаненные пропускаются.</i>",
        parse_mode="HTML",
        reply_markup=_cancel_kb()
    )
    await callback.answer()


@router.message(AdminState.broadcast_text)
async def input_broadcast_text(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.clear()
    broadcast_text = message.text

    async with get_db() as session:
        users = await UserService.get_all_users(session)
        ok = fail = 0
        for u in users:
            if u.is_banned:
                continue
            try:
                await message.bot.send_message(
                    u.telegram_id,
                    f"📢 <b>ОБЪЯВЛЕНИЕ</b>\n\n{broadcast_text}",
                    parse_mode="HTML"
                )
                ok += 1
            except Exception:
                fail += 1

    await message.answer(
        f"✅ <b>Рассылка завершена!</b>\n\n"
        f"📤 Отправлено: <b>{ok}</b>\n"
        f"❌ Ошибок: <b>{fail}</b>",
        parse_mode="HTML",
        reply_markup=_back_kb()
    )





# ── Крипто-управление ─────────────────────────────────────────────────────────

@router.callback_query(F.data == "ap:crypto:main")
async def cb_crypto_main(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    from services.crypto_service import get_all_prices, seed_crypto_prices
    async with get_db() as session:
        await seed_crypto_prices(session)
        coins = await get_all_prices(session)

    text = "💹 <b>УПРАВЛЕНИЕ КРИПТОВАЛЮТОЙ</b>\n\n"
    for cp in coins:
        status = "✅" if cp.admin_enabled else "🔒"
        text += f"{status} {cp.emoji} <b>{cp.symbol}</b> {cp.name} — {cp.price:.10g}$\n"

    kb = InlineKeyboardBuilder()
    for cp in coins:
        kb.button(text=f"{cp.emoji} {cp.symbol}", callback_data=f"ap:crypto:edit:{cp.symbol}")
    kb.button(text="➕ Добавить монету", callback_data="ap:crypto:add")
    kb.button(text="◀️ Настройки",       callback_data="ap:settings:main")
    kb.adjust(3)
    try:
        await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
    except Exception:
        pass
    await callback.answer()


@router.callback_query(F.data.startswith("ap:crypto:edit:"))
async def cb_crypto_edit(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    symbol = callback.data.split(":")[3]
    from services.crypto_service import get_price, seed_crypto_prices
    async with get_db() as session:
        await seed_crypto_prices(session)
        cp = await get_price(session, symbol)
        if not cp:
            await callback.answer("Монета не найдена", show_alert=True)
            return

        status = "✅ Торги открыты" if cp.admin_enabled else "🔒 Торги закрыты"
        text = (
            f"💹 <b>{cp.emoji} {cp.name} ({cp.symbol})</b>\n\n"
            f"💵 Цена: <b>{cp.price:.10g}$</b>\n"
            f"📉 Волатильность: {cp.volatility*100:.0f}%\n"
            f"Статус: {status}\n\n"
            f"Выберите действие:"
        )
        kb = InlineKeyboardBuilder()
        kb.button(text="✏️ Изменить цену",   callback_data=f"ap:crypto:setprice:{symbol}")
        if cp.admin_enabled:
            kb.button(text="🔒 Заблокировать",  callback_data=f"ap:crypto:toggle:{symbol}:0")
        else:
            kb.button(text="✅ Разблокировать", callback_data=f"ap:crypto:toggle:{symbol}:1")
        kb.button(text="◀️ Назад",             callback_data="ap:crypto:main")
        kb.adjust(1)
        try:
            await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
        except Exception:
            pass
    await callback.answer()


@router.callback_query(F.data.startswith("ap:crypto:setprice:"))
async def cb_crypto_setprice(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    symbol = callback.data.split(":")[3]
    await state.set_state(AdminState.set_crypto_price)
    await state.update_data(crypto_symbol=symbol)
    await callback.message.edit_text(
        f"✏️ Введите новую цену для <b>{symbol}</b> в $:\n\n"
        f"Пример: <code>95000</code> или <code>0.0000001</code>\n\n"
        f"<i>⚠️ Цена немедленно применится на рынке</i>",
        parse_mode="HTML",
        reply_markup=_cancel_kb("ap:crypto:main")
    )
    await callback.answer()


@router.message(AdminState.set_crypto_price)
async def input_crypto_price(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    symbol = data.get("crypto_symbol")
    await state.clear()

    try:
        new_price = float(message.text.strip().replace(",", "."))
        if new_price <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Некорректная цена! Введите положительное число.")
        return

    from services.crypto_service import get_price, seed_crypto_prices
    from sqlalchemy.orm.attributes import flag_modified as _fm
    async with get_db() as session:
        await seed_crypto_prices(session)
        cp = await get_price(session, symbol)
        if not cp:
            await message.answer("❌ Монета не найдена!")
            return

        old_price = cp.price
        hist = (cp.price_history or {}).get("prices", [])
        hist.append(new_price)
        if len(hist) > 48:
            hist = hist[-48:]
        cp.price = new_price
        cp.price_history = {"prices": hist}
        from datetime import datetime
        cp.updated_at = datetime.utcnow()
        await session.commit()

    await message.answer(
        f"✅ <b>{symbol}</b> цена обновлена!\n\n"
        f"Было: {old_price:.10g}$\n"
        f"Стало: {new_price:.10g}$",
        parse_mode="HTML",
        reply_markup=_back_kb("ap:crypto:main")
    )


@router.callback_query(F.data.startswith("ap:crypto:toggle:"))
async def cb_crypto_toggle(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split(":")
    symbol = parts[3]
    enable = parts[4] == "1"

    from services.crypto_service import get_price, seed_crypto_prices
    async with get_db() as session:
        await seed_crypto_prices(session)
        cp = await get_price(session, symbol)
        if not cp:
            await callback.answer("Не найдено", show_alert=True)
            return
        cp.admin_enabled = enable
        await session.commit()

    status = "✅ разблокирована" if enable else "🔒 заблокирована"
    await callback.answer(f"{symbol} {status}", show_alert=True)
    # Refresh edit page
    await cb_crypto_edit(callback, None)


@router.callback_query(F.data == "ap:crypto:add")
async def cb_crypto_add(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminState.add_crypto_sym)
    await callback.message.edit_text(
        "➕ <b>Добавление новой криптовалюты</b>\n\n"
        "Введите данные в формате:\n"
        "<code>СИМВОЛ | Название | emoji | начальная_цена | волатильность%</code>\n\n"
        "Пример:\n"
        "<code>MEME | Meme Coin | 🐸 | 0.001 | 20</code>",
        parse_mode="HTML",
        reply_markup=_cancel_kb("ap:crypto:main")
    )
    await callback.answer()


@router.message(AdminState.add_crypto_sym)
async def input_new_crypto(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.clear()

    try:
        parts = [p.strip() for p in message.text.split("|")]
        if len(parts) < 5:
            raise ValueError("Нужно 5 полей")
        symbol = parts[0].upper()[:10]
        name = parts[1][:100]
        emoji = parts[2][:10]
        price = float(parts[3].replace(",", "."))
        vol = float(parts[4].replace(",", ".").replace("%", "")) / 100
        if price <= 0 or vol <= 0:
            raise ValueError
    except Exception as e:
        await message.answer(f"❌ Ошибка формата: {e}\n\nПример: <code>MEME | Meme Coin | 🐸 | 0.001 | 20</code>", parse_mode="HTML")
        return

    from services.crypto_service import get_price, seed_crypto_prices
    from models.database import CryptoPrice
    from datetime import datetime
    async with get_db() as session:
        await seed_crypto_prices(session)
        existing = await get_price(session, symbol)
        if existing:
            await message.answer(f"❌ Монета <b>{symbol}</b> уже существует!", parse_mode="HTML")
            return

        cp = CryptoPrice(
            symbol=symbol,
            name=name,
            emoji=emoji,
            price=price,
            volatility=vol,
            is_tradeable=True,
            admin_enabled=True,
            price_history={"prices": [price]},
            change_24h=0.0,
            updated_at=datetime.utcnow()
        )
        session.add(cp)
        await session.commit()

    await message.answer(
        f"✅ <b>Монета {emoji} {symbol} добавлена!</b>\n\n"
        f"Название: {name}\n"
        f"Начальная цена: {price:.10g}$\n"
        f"Волатильность: {vol*100:.0f}%\n"
        f"Статус: ✅ Торги открыты",
        parse_mode="HTML",
        reply_markup=_back_kb("ap:crypto:main")
    )


# ── utils ─────────────────────────────────────────────────────────────────────

def _cancel_kb(back_cb: str = "ap:menu") -> object:
    kb = InlineKeyboardBuilder()
    kb.button(text="❌ Отмена", callback_data=back_cb)
    return kb.as_markup()


def _back_kb(back_cb: str = "ap:menu") -> object:
    kb = InlineKeyboardBuilder()
    kb.button(text="◀️ Назад", callback_data=back_cb)
    return kb.as_markup()


# ── Standalone admin bot runner ───────────────────────────────────────────────

async def run_admin_bot():
    """Запускает отдельный бот-админку. Вызывается из main.py если задан ADMIN_BOT_TOKEN."""
    token = settings.ADMIN_BOT_TOKEN
    if not token:
        return

    from loguru import logger
    logger.info("Starting admin bot...")

    bot = Bot(token=token)
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    try:
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    except Exception as e:
        logger.error(f"Admin bot error: {e}")
    finally:
        await bot.session.close()
