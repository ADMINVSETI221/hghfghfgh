"""
Cryptocurrency trading & market handlers
"""
import math
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from services.database import get_db, UserService
from services.crypto_service import (
    get_all_prices, get_price, fluctuate_price,
    seed_crypto_prices, make_price_chart,
    get_top_by_crypto_value, _fmt_price, _fmt_amount
)
from models.database import CRYPTO_DEFAULTS
from sqlalchemy.orm.attributes import flag_modified

router = Router()


# ── Helpers ────────────────────────────────────────────────────────────────────

def _coins_per_usd(price: float, usd_amount: float) -> float:
    if price == 0:
        return 0
    return usd_amount / price


# ── Market overview ────────────────────────────────────────────────────────────

@router.message(F.text.lower().in_(["крипто", "криптовалюта", "рынок", "рынок крипты"]))
@router.message(Command("crypto", "market"))
async def cmd_crypto_market(message: Message):
    async with get_db() as session:
        await seed_crypto_prices(session)
        prices = await get_all_prices(session)

        text = "💹 <b>КРИПТО-РЫНОК</b>\n\n"
        tradeable = [p for p in prices if p.admin_enabled]
        locked = [p for p in prices if not p.admin_enabled]

        for cp in tradeable:
            arrow = "📈" if cp.change_24h >= 0 else "📉"
            change_str = f"{cp.change_24h:+.2f}%"
            text += f"{cp.emoji} <b>{cp.symbol}</b> {_fmt_price(cp.price)}  {arrow}{change_str}\n"

        if locked:
            text += "\n🔒 <i>Заблокировано администратором:</i>\n"
            for cp in locked:
                text += f"  {cp.emoji} {cp.symbol} — <i>недоступно для торговли</i>\n"

        text += "\n<b>Команды:</b>\n"
        text += "📊 <code>курс [символ]</code> — подробно\n"
        text += "💰 <code>купить крипту [символ] [сумма]</code>\n"
        text += "💸 <code>продать крипту [символ] [кол-во]</code>\n"
        text += "👛 <code>кошелёк</code> — ваш портфель\n"
        text += "🏆 <code>топ крипто</code> — топ по портфелю\n"

        kb = InlineKeyboardBuilder()
        kb.button(text="🔄 Обновить", callback_data="crypto:market")
        kb.button(text="👛 Кошелёк",  callback_data="crypto:wallet")
        kb.adjust(2)
        await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())


@router.callback_query(F.data == "crypto:market")
async def cb_market_refresh(callback: CallbackQuery):
    async with get_db() as session:
        await seed_crypto_prices(session)
        prices = await get_all_prices(session)

        text = "💹 <b>КРИПТО-РЫНОК</b>\n\n"
        for cp in prices:
            if not cp.admin_enabled:
                continue
            arrow = "📈" if cp.change_24h >= 0 else "📉"
            text += f"{cp.emoji} <b>{cp.symbol}</b> {_fmt_price(cp.price)}  {arrow}{cp.change_24h:+.2f}%\n"

        text += "\n💡 Команда <code>курс [символ]</code> — подробный график"

        kb = InlineKeyboardBuilder()
        kb.button(text="🔄 Обновить", callback_data="crypto:market")
        kb.button(text="👛 Кошелёк",  callback_data="crypto:wallet")
        kb.adjust(2)
        try:
            await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
        except Exception:
            pass
        await callback.answer("Обновлено!")


# ── Coin detail + chart ────────────────────────────────────────────────────────

@router.message(F.text.lower().startswith("курс "))
@router.message(Command("курс"))
async def cmd_coin_detail(message: Message):
    parts = message.text.strip().split()
    if len(parts) < 2:
        # курс без аргумента — показываем полный список рынка из БД
        async with get_db() as session:
            await seed_crypto_prices(session)
            prices = await get_all_prices(session)
            tradeable = [p for p in prices if p.admin_enabled]
            locked = [p for p in prices if not p.admin_enabled]
            text = "💹 <b>КРИПТО-РЫНОК</b>\n\n"
            for cp in tradeable:
                arrow = "📈" if cp.change_24h >= 0 else "📉"
                text += f"{cp.emoji} <b>{cp.symbol}</b> {_fmt_price(cp.price)}  {arrow}{cp.change_24h:+.2f}%\n"
            if locked:
                text += "\n🔒 <i>Заблокировано администратором:</i>\n"
                for cp in locked:
                    text += f"  {cp.emoji} {cp.symbol} — <i>недоступно</i>\n"
            text += "\n💡 <code>курс [символ]</code> — подробный график"
            kb = InlineKeyboardBuilder()
            kb.button(text="🔄 Обновить", callback_data="crypto:market")
            kb.button(text="👛 Кошелёк",  callback_data="crypto:wallet")
            kb.adjust(2)
            await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())
        return
    symbol = parts[-1].upper()

    async with get_db() as session:
        await seed_crypto_prices(session)
        cp = await get_price(session, symbol)
        if not cp:
            # Монета не найдена — показываем доступные
            prices = await get_all_prices(session)
            tradeable = [p for p in prices if p.admin_enabled]
            available = ", ".join(f"{p.emoji}{p.symbol}" for p in tradeable)
            await message.answer(
                f"❌ Монета <b>{symbol}</b> не найдена.\n\n"
                f"Доступные монеты:\n{available}\n\n"
                f"Используйте <code>рынок</code> для полного списка.",
                parse_mode="HTML"
            )
            return

        hist = (cp.price_history or {}).get("prices", [cp.price])
        chart = make_price_chart(hist, symbol)

        arrow = "📈" if cp.change_24h >= 0 else "📉"
        lock_str = "\n🔒 <i>Торговля заблокирована администратором</i>" if not cp.admin_enabled else ""
        text = (
            f"{cp.emoji} <b>{cp.name} ({cp.symbol})</b>\n\n"
            f"💵 Текущая цена: <b>{_fmt_price(cp.price)}</b>\n"
            f"{arrow} Изменение: <b>{cp.change_24h:+.2f}%</b>\n"
            f"📉 Волатильность: {cp.volatility*100:.0f}%\n"
            f"{lock_str}\n\n"
            f"<b>График цены:</b>\n{chart}\n\n"
            f"💡 <code>купить крипту {symbol} [сумма в $]</code>\n"
            f"💡 <code>продать крипту {symbol} [кол-во]</code>"
        )
        kb = InlineKeyboardBuilder()
        kb.button(text="🔄 Обновить", callback_data=f"crypto:detail:{symbol}")
        kb.button(text="◀️ Рынок",    callback_data="crypto:market")
        kb.adjust(2)
        await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("crypto:detail:"))
async def cb_coin_detail(callback: CallbackQuery):
    symbol = callback.data.split(":")[2]
    async with get_db() as session:
        cp = await get_price(session, symbol)
        if not cp:
            await callback.answer("Монета не найдена", show_alert=True)
            return

        hist = (cp.price_history or {}).get("prices", [cp.price])
        chart = make_price_chart(hist, symbol)
        arrow = "📈" if cp.change_24h >= 0 else "📉"
        text = (
            f"{cp.emoji} <b>{cp.name} ({cp.symbol})</b>\n\n"
            f"💵 Цена: <b>{_fmt_price(cp.price)}</b>\n"
            f"{arrow} Изменение: <b>{cp.change_24h:+.2f}%</b>\n\n"
            f"{chart}"
        )
        kb = InlineKeyboardBuilder()
        kb.button(text="🔄 Обновить", callback_data=f"crypto:detail:{symbol}")
        kb.button(text="◀️ Рынок",    callback_data="crypto:market")
        kb.adjust(2)
        try:
            await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
        except Exception:
            pass
    await callback.answer()


# ── Buy crypto ────────────────────────────────────────────────────────────────

@router.message(F.text.lower().startswith("купить крипту"))
async def cmd_buy_crypto(message: Message):
    """купить крипту BTC 1000"""
    parts = message.text.strip().split()
    if len(parts) < 4:
        await message.answer(
            "❌ Формат: <code>купить крипту [символ] [сумма в $]</code>\n"
            "Пример: <code>купить крипту BTC 1000</code>",
            parse_mode="HTML"
        )
        return

    symbol = parts[2].upper()
    try:
        spend = float(parts[3].replace(",", "."))
    except ValueError:
        await message.answer("❌ Некорректная сумма.")
        return

    if spend <= 0:
        await message.answer("❌ Сумма должна быть больше нуля.")
        return

    async with get_db() as session:
        await seed_crypto_prices(session)
        cp = await get_price(session, symbol)
        if not cp:
            await message.answer(f"❌ Монета <b>{symbol}</b> не найдена.", parse_mode="HTML")
            return
        if not cp.admin_enabled:
            await message.answer(f"🔒 <b>{symbol}</b> заблокирован администратором для торговли.", parse_mode="HTML")
            return

        user = await UserService.get_or_create(
            session, message.from_user.id,
            message.from_user.username, message.from_user.first_name
        )

        # Discount from market_insider item
        discount = 0.0
        inv = user.inventory or {}
        if "market_insider" in inv and inv["market_insider"].get("quantity", 0) > 0:
            discount = 0.10
            inv["market_insider"]["quantity"] -= 1
            if inv["market_insider"]["quantity"] <= 0:
                del inv["market_insider"]
            flag_modified(user, "inventory")

        effective_spend = spend * (1 - discount)

        if user.balance < effective_spend:
            await message.answer(
                f"❌ Недостаточно средств!\n"
                f"Нужно: {effective_spend:,.2f}$\n"
                f"Баланс: {user.balance:,.2f}$"
            )
            return

        coins_bought = effective_spend / cp.price

        # Update wallet
        wallet = user.crypto_wallet or {}
        wallet[symbol] = wallet.get(symbol, 0) + coins_bought
        user.crypto_wallet = wallet
        flag_modified(user, "crypto_wallet")

        user, _ = await UserService.update_balance(
            session, user, -effective_spend, "crypto_buy",
            f"Покупка {_fmt_amount(coins_bought)} {symbol}"
        )

        # Slight price increase on buy
        await fluctuate_price(session, cp, side="buy")

        discount_str = f"\n🎁 Скидка инсайдера: -10% (сэкономлено {spend*0.10:,.2f}$)" if discount else ""
        await message.answer(
            f"✅ <b>Куплено {symbol}!</b>\n\n"
            f"{cp.emoji} Количество: <b>{_fmt_amount(coins_bought)} {symbol}</b>\n"
            f"💵 Потрачено: <b>{effective_spend:,.2f}$</b>\n"
            f"📊 Цена за единицу: {_fmt_price(cp.price)}\n"
            f"💼 Баланс: {user.balance:,.2f}${discount_str}",
            parse_mode="HTML"
        )


# ── Sell crypto ───────────────────────────────────────────────────────────────

@router.message(F.text.lower().startswith("продать крипту"))
async def cmd_sell_crypto(message: Message):
    """продать крипту BTC 0.5  |  продать крипту BTC все"""
    parts = message.text.strip().split()
    if len(parts) < 4:
        await message.answer(
            "❌ Формат: <code>продать крипту [символ] [кол-во / все]</code>\n"
            "Пример: <code>продать крипту BTC 0.5</code>",
            parse_mode="HTML"
        )
        return

    symbol = parts[2].upper()
    sell_all = parts[3].lower() in ("все", "all", "всё")

    if not sell_all:
        try:
            amount = float(parts[3].replace(",", "."))
        except ValueError:
            await message.answer("❌ Некорректное количество.")
            return
        if amount <= 0:
            await message.answer("❌ Количество должно быть > 0.")
            return

    async with get_db() as session:
        await seed_crypto_prices(session)
        cp = await get_price(session, symbol)
        if not cp:
            await message.answer(f"❌ Монета <b>{symbol}</b> не найдена.", parse_mode="HTML")
            return
        if not cp.admin_enabled:
            await message.answer(f"🔒 <b>{symbol}</b> заблокирован администратором.", parse_mode="HTML")
            return

        user = await UserService.get_or_create(
            session, message.from_user.id,
            message.from_user.username, message.from_user.first_name
        )

        wallet = user.crypto_wallet or {}
        held = wallet.get(symbol, 0)

        if held <= 0:
            await message.answer(f"❌ У вас нет <b>{symbol}</b>.", parse_mode="HTML")
            return

        if sell_all:
            amount = held
        elif amount > held:
            await message.answer(
                f"❌ Недостаточно {symbol}!\n"
                f"У вас: {_fmt_amount(held)}\n"
                f"Запрошено: {_fmt_amount(amount)}"
            )
            return

        earned = amount * cp.price

        wallet[symbol] = held - amount
        if wallet[symbol] <= 0:
            del wallet[symbol]
        user.crypto_wallet = wallet
        flag_modified(user, "crypto_wallet")

        user, _ = await UserService.update_balance(
            session, user, earned, "crypto_sell",
            f"Продажа {_fmt_amount(amount)} {symbol}"
        )

        # Slight price decrease on sell
        await fluctuate_price(session, cp, side="sell")

        await message.answer(
            f"💸 <b>Продано {symbol}!</b>\n\n"
            f"{cp.emoji} Продано: <b>{_fmt_amount(amount)} {symbol}</b>\n"
            f"💰 Получено: <b>{earned:,.2f}$</b>\n"
            f"📊 Цена: {_fmt_price(cp.price)}\n"
            f"💼 Баланс: {user.balance:,.2f}$",
            parse_mode="HTML"
        )


# ── Wallet ────────────────────────────────────────────────────────────────────

@router.message(F.text.lower().in_(["кошелёк", "кошелек", "криптокошелёк", "криптокошелек"]))
@router.message(Command("wallet"))
@router.callback_query(F.data == "crypto:wallet")
async def cmd_wallet(event):
    message = event if isinstance(event, Message) else event.message
    uid = event.from_user.id if isinstance(event, Message) else event.from_user.id

    async with get_db() as session:
        await seed_crypto_prices(session)
        prices = await get_all_prices(session)
        price_map = {cp.symbol: cp for cp in prices}

        user = await UserService.get_or_create(
            session, uid,
            event.from_user.username if isinstance(event, Message) else event.from_user.username,
            event.from_user.first_name if isinstance(event, Message) else event.from_user.first_name
        )

        wallet = user.crypto_wallet or {}
        if not wallet:
            text = "👛 <b>Ваш крипто-кошелёк пуст!</b>\n\nИспользуйте <code>рынок</code> для покупки."
        else:
            text = "👛 <b>КРИПТО-КОШЕЛЁК</b>\n\n"
            total_usd = 0.0
            for sym, amt in sorted(wallet.items()):
                if amt <= 0:
                    continue
                cp = price_map.get(sym)
                if not cp:
                    continue
                usd_val = amt * cp.price
                total_usd += usd_val
                text += f"{cp.emoji} <b>{sym}</b>: {_fmt_amount(amt)} (≈{usd_val:,.4f}$)\n"
            text += f"\n💎 <b>Итого: ≈{total_usd:,.4f}$</b>\n"
            text += f"💼 Баланс: {user.balance:,.2f}$"

        kb = InlineKeyboardBuilder()
        kb.button(text="🔄 Обновить", callback_data="crypto:wallet")
        kb.button(text="💹 Рынок",    callback_data="crypto:market")
        kb.adjust(2)

        if isinstance(event, Message):
            await message.answer(text, parse_mode="HTML", reply_markup=kb.as_markup())
        else:
            try:
                await message.edit_text(text, parse_mode="HTML", reply_markup=kb.as_markup())
            except Exception:
                pass
            await event.answer()


# ── Top by crypto ─────────────────────────────────────────────────────────────

@router.message(F.text.lower().in_(["топ крипто", "топ криптовалюта", "топ крипты"]))
@router.message(Command("topcrypto"))
async def cmd_top_crypto(message: Message):
    async with get_db() as session:
        await seed_crypto_prices(session)
        top = await get_top_by_crypto_value(session, limit=15)

        if not top:
            await message.answer("🏆 Пока нет игроков с криптовалютой.")
            return

        text = "🏆 <b>ТОП-15 ПО КРИПТО-ПОРТФЕЛЮ</b>\n\n"
        medals = ["🥇", "🥈", "🥉"]
        for i, (u, usd) in enumerate(top, 1):
            medal = medals[i - 1] if i <= 3 else f"{i}."
            name = u.first_name or u.username or f"ID:{u.telegram_id}"
            if usd < 0.01:
                continue
            text += f"{medal} <b>{name}</b> — ≈{usd:,.4f}$\n"

        await message.answer(text, parse_mode="HTML")


# ── Crypto Analyzer (crypto_signal item) ──────────────────────────────────────

@router.message(F.text.lower().in_(["анализ", "крипто анализ", "анализ рынка"]))
@router.message(Command("analyze"))
async def cmd_crypto_analyze(message: Message):
    """Use crypto_analyzer item to see next price trend."""
    async with get_db() as session:
        user = await UserService.get_or_create(
            session, message.from_user.id,
            message.from_user.username, message.from_user.first_name
        )
        inv = user.inventory or {}
        if "crypto_analyzer" not in inv or inv["crypto_analyzer"].get("quantity", 0) <= 0:
            await message.answer(
                "❌ У вас нет 📊 <b>Крипто-анализатора</b>!\n"
                "Купите его в 🏪 магазине.",
                parse_mode="HTML"
            )
            return

        # Consume one analyzer
        inv["crypto_analyzer"]["quantity"] -= 1
        if inv["crypto_analyzer"]["quantity"] <= 0:
            del inv["crypto_analyzer"]
        flag_modified(user, "inventory")

        await seed_crypto_prices(session)
        prices = await get_all_prices(session)

        import random
        text = "📊 <b>КРИПТО-АНАЛИЗАТОР</b>\n\n"
        text += "🔮 <i>Прогноз движения цен на следующий период:</i>\n\n"
        for cp in prices:
            if not cp.admin_enabled:
                continue
            # Simulate trend prediction based on current change + random factor
            predicted = cp.change_24h + random.uniform(-5, 5)
            arrow = "📈" if predicted >= 0 else "📉"
            text += f"{cp.emoji} <b>{cp.symbol}</b>: {arrow} {predicted:+.1f}%\n"

        text += "\n⚠️ <i>Анализатор использован. Прогноз носит ознакомительный характер.</i>"
        await message.answer(text, parse_mode="HTML")

        await session.commit()
