#!/usr/bin/env python3
"""
Быстрая установка исправлений
Quick fix installer
"""
import os
import shutil
from pathlib import Path

def main():
    print("=" * 60)
    print("УСТАНОВКА ИСПРАВЛЕНИЙ / INSTALLING FIXES")
    print("=" * 60)
    print()
    
    # Определяем текущую директорию
    current_dir = Path.cwd()
    print(f"📁 Текущая директория: {current_dir}")
    print()
    
    # Проверяем наличие необходимых файлов
    required_files = [
        "handlers/business.py",
        "handlers/shop.py",
        "services/database.py",
        "bot.db"
    ]
    
    print("🔍 Проверка файлов...")
    all_exist = True
    for file in required_files:
        file_path = current_dir / file
        if file_path.exists():
            print(f"  ✅ {file}")
        else:
            print(f"  ❌ {file} - НЕ НАЙДЕН")
            all_exist = False
    
    if not all_exist:
        print("\n❌ Некоторые файлы не найдены!")
        print("   Убедитесь, что вы находитесь в директории с ботом.")
        return
    
    print("\n" + "=" * 60)
    print("СОЗДАНИЕ РЕЗЕРВНОЙ КОПИИ / CREATING BACKUP")
    print("=" * 60)
    
    # Создаем резервные копии
    backup_files = [
        "handlers/business.py",
        "handlers/shop.py",
        "services/database.py",
        "bot.db"
    ]
    
    backup_dir = current_dir / "backup_before_fix"
    backup_dir.mkdir(exist_ok=True)
    
    print(f"\n📦 Создание резервных копий в: {backup_dir}")
    for file in backup_files:
        src = current_dir / file
        dst = backup_dir / file
        dst.parent.mkdir(parents=True, exist_ok=True)
        
        if src.exists():
            shutil.copy2(src, dst)
            print(f"  ✅ Скопирован: {file}")
    
    print("\n✅ Резервные копии созданы!")
    
    print("\n" + "=" * 60)
    print("СЛЕДУЮЩИЕ ШАГИ / NEXT STEPS")
    print("=" * 60)
    print("""
1. ⚠️  ОСТАНОВИТЕ БОТА (Ctrl+C)

2. 🔧 Запустите скрипт исправления БД:
   python fix_businesses_structure.py

3. 📝 Замените файлы на исправленные версии:
   - handlers/business.py
   - handlers/shop.py
   - services/database.py

4. ▶️  Запустите бота снова:
   Windows: start_bot.bat
   Linux:   ./start_bot.sh

5. ✅ Проверьте работу команды /business

📖 Подробная информация в файле ИСПРАВЛЕНИЯ.md

⚠️  В случае проблем восстановите из backup_before_fix/
    """)

if __name__ == "__main__":
    main()
