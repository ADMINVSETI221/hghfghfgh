#!/usr/bin/env python3
"""
Script to fix businesses structure in database
Converts list to dict if needed
"""
import asyncio
import sys
from sqlalchemy import select
from sqlalchemy.orm.attributes import flag_modified

from models.database import Base, User
from services.database import async_engine, async_session_maker


async def fix_businesses():
    """Fix businesses structure for all users"""
    print("🔧 Starting businesses structure fix...")
    
    async with async_session_maker() as session:
        # Get all users
        result = await session.execute(select(User))
        users = result.scalars().all()
        
        fixed_count = 0
        
        for user in users:
            if user.businesses is not None:
                # Check if it's a list instead of dict
                if isinstance(user.businesses, list):
                    print(f"  Fixing user {user.telegram_id} ({user.username or user.first_name})")
                    user.businesses = {}
                    flag_modified(user, "businesses")
                    fixed_count += 1
                elif not isinstance(user.businesses, dict):
                    print(f"  Converting invalid type for user {user.telegram_id}")
                    user.businesses = {}
                    flag_modified(user, "businesses")
                    fixed_count += 1
        
        if fixed_count > 0:
            await session.commit()
            print(f"✅ Fixed {fixed_count} users")
        else:
            print("✅ All users already have correct structure")
    
    print("🎉 Businesses structure fix completed!")


async def main():
    """Main function"""
    try:
        await fix_businesses()
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
