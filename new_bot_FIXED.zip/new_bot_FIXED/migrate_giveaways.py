#!/usr/bin/env python3
"""
Migration script to add giveaways table
"""
import asyncio
import sys
from sqlalchemy import inspect

from models.database import Base, Giveaway
from services.database import async_engine


async def migrate():
    """Add giveaways table if it doesn't exist"""
    print("🔧 Starting migration...")
    
    async with async_engine.begin() as conn:
        # Check if table exists
        def check_table(connection):
            inspector = inspect(connection)
            return 'giveaways' in inspector.get_table_names()
        
        table_exists = await conn.run_sync(check_table)
        
        if table_exists:
            print("✅ Giveaways table already exists")
        else:
            print("📦 Creating giveaways table...")
            
            # Create only the giveaways table
            def create_table(connection):
                Giveaway.__table__.create(connection, checkfirst=True)
            
            await conn.run_sync(create_table)
            print("✅ Giveaways table created")
    
    print("🎉 Migration completed!")


async def main():
    """Main function"""
    try:
        await migrate()
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        await async_engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
