#!/usr/bin/env python3
"""
Fix businesses format in database
Converts old list format to new dict format
"""
import sqlite3
import json
from datetime import datetime

def fix_businesses_format(db_path):
    """Convert businesses from list to dict format"""
    
    print("🔧 Исправляем формат businesses в базе данных...")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Business ID mapping
    business_id_map = {
        1: "lemonade_stand",
        2: "car_wash",
        3: "coffee_shop",
        4: "restaurant",
        5: "casino",
        6: "hotel"
    }
    
    # Get all users with businesses
    cursor.execute("SELECT id, telegram_id, username, businesses FROM users WHERE businesses IS NOT NULL AND businesses != '[]' AND businesses != '{}'")
    users = cursor.fetchall()
    
    print(f"📊 Найдено пользователей с бизнесами: {len(users)}")
    
    fixed_count = 0
    for user_id, telegram_id, username, businesses_json in users:
        try:
            businesses = json.loads(businesses_json)
            
            # Check if it's a list (old format)
            if isinstance(businesses, list) and len(businesses) > 0:
                print(f"\n🔄 Конвертирую для {username} (ID: {telegram_id})")
                print(f"  Старый формат: {businesses}")
                
                new_businesses = {}
                
                for business in businesses:
                    if isinstance(business, dict) and 'id' in business:
                        business_key = business_id_map.get(business['id'])
                        if business_key:
                            new_businesses[business_key] = {
                                "level": business.get('level', 1),
                                "last_collect": business.get('last_collect', datetime.utcnow().isoformat()),
                                "total_earned": business.get('total_earned', 0)
                            }
                            print(f"  ✓ {business_key}: уровень {business.get('level', 1)}")
                
                # Update in database
                cursor.execute(
                    "UPDATE users SET businesses = ? WHERE id = ?",
                    (json.dumps(new_businesses), user_id)
                )
                fixed_count += 1
                print(f"  ✅ Обновлено в БД")
            
            elif isinstance(businesses, list) and len(businesses) == 0:
                # Empty list, convert to empty dict
                cursor.execute(
                    "UPDATE users SET businesses = ? WHERE id = ?",
                    ('{}', user_id)
                )
                fixed_count += 1
                print(f"✓ {username}: пустой список → пустой словарь")
                
        except Exception as e:
            print(f"✗ Ошибка для пользователя {username}: {e}")
    
    # Fix empty list inventories
    cursor.execute("UPDATE users SET inventory = '{}' WHERE inventory = '[]'")
    inventory_fixed = cursor.rowcount
    
    # Fix NULL businesses/inventory
    cursor.execute("UPDATE users SET businesses = '{}' WHERE businesses IS NULL")
    cursor.execute("UPDATE users SET inventory = '{}' WHERE inventory IS NULL")
    
    conn.commit()
    conn.close()
    
    print("\n" + "="*60)
    print("✅ ИСПРАВЛЕНИЕ ЗАВЕРШЕНО!")
    print("="*60)
    print(f"🏢 Бизнесов конвертировано: {fixed_count}")
    print(f"🎒 Инвентарей исправлено: {inventory_fixed}")
    print("\n💡 Теперь можете запускать бота!")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 2:
        print("Использование: python fix_businesses.py <путь_к_bot.db>")
        print("Пример: python fix_businesses.py bot.db")
        sys.exit(1)
    
    db_path = sys.argv[1]
    fix_businesses_format(db_path)
