"""
Отдельный Telegram-бот для администраторов.
Запускается командой: python admin_bot.py

Возможности:
  • Поиск игроков (по ID, username, имени)
  • Просмотр и редактирование профиля любого игрока
  • Бан / разбан
  • Ограничение функций (работа, майнинг, казино, переводы)
  • Добавление / снятие VIP
  • Редактирование баланса, уровня, опыта, отметок психиатра
  • Редактирование цен бизнесов и магазина
  • Настройки игры (min/max работы/майнинга/дейли)
  • Рассылка уведомлений
"""
import asyncio
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from loguru import logger

from config import settings
from services.database import get_db, UserService
from services.prices import (
    get_all_businesses, get_business, set_business_price,
    get_shop_item, set_shop_price, get_game_setting, set_game_setting,
    reset_all, DEFAULT_GAME
)
from models.database import BUSINESSES, SHOP_ITEMS
from utils.formatters import format_balance

# ─── FSM ─────────────────────────────────────────────────────────────────────

class AdminState(StatesGroup):
    search       = State()   # ищем игрока
    edit_field   = State()   # вводим новое значение поля
    edit_price   = State()   # вводим новую цену
    broadcast    = State()   # вводим текст рассылки

# ─── helpers ─────────────────────────────────────────────────────────────────

def is_admin(uid: int) -> bool:
    return uid in settings.all_admin_ids


def user_info_text(user) -> str:
    vip = ""
    if user.vip_until and datetime.utcnow() < user.vip_until:
        left = user.vip_until - datetime.utcnow()
        vip = f"  👑 VIP ещё {left.days}д {left.seconds//3600}ч\n"

    restrictions = user.statistics.get("restrictions", {})
    restr_list = [k for k, v in restrictions.items() if v]
    restr_str = ", ".join(restr_list) if restr_list else "нет"

    marks = user.statistics.get("psychiatrist_marks", 0)
    biz_count = len(user.businesses or {})
    card_count = sum(1 for k in (user.inventory or {}) if k.startswith("card_"))

    return (
        f"👤 <b>{user.first_name or 'Без имени'}</b>  "
        f"{'🚫 БАН' if user.is_banned else '✅ Активен'}\n"
        f"🆔 {user.telegram_id}  "
        f"{'@' + user.username if user.username else 'без username'}\n"
        f"💰 Баланс: <b>{format_balance(user.balance)}</b>\n"
        f"⭐ Уровень: {user.level}  Опыт: {user.experience}/{user.level*100}\n"
        f"🧠 Отметки психиатра: {marks}\n"
        f"🏢 Бизнесов: {biz_count}  🎴 Карточек: {card_count}\n"
        f"{vip}"
        f"⛔ Ограничения: {restr_str}\n"
        f"📅 Регистрация: {user.created_at.strftime('%d.%m.%Y') if user.created_at else '?'}"
    )


def player_kb(user) -> InlineKeyboardBuilder:
    uid = user.telegram_id
    banned = user.is_banned
    has_vip = user.vip_until and datetime.utcnow() < user.vip_until

    b = InlineKeyboardBuilder()
    b.button(text="💰 Баланс", callback_data=f"edit:balance:{uid}")
    b.button(text="⭐ Уровень", callback_data=f"edit:level:{uid}")
    b.button(text="📊 Опыт", callback_data=f"edit:exp:{uid}")
    b.button(text="🧠 Психиатр", callback_data=f"edit:psych:{uid}")
    b.button(text="🚫 Забанить" if not banned else "✅ Разбанить", callback_data=f"edit:ban:{uid}")
    b.button(text="👑 Дать VIP" if not has_vip else "❌ Снять VIP", callback_data=f"edit:vip:{uid}")
    b.button(text="⛔ Ограничения", callback_data=f"restr:menu:{uid}")
    b.button(text="🗑 Сбросить прогресс", callback_data=f"edit:reset:{uid}")
    b.button(text="◀️ Назад", callback_data="main_menu")
    b.adjust(2, 2, 2, 2, 1)
    return b


def restr_kb(user) -> InlineKeyboardBuilder:
    uid = user.telegram_id
    r = (user.statistics or {}).get("restrictions", {})

    def label(key, emoji, name):
        active = r.get(key, False)
        return f"{'🔴' if active else '🟢'} {name}"

    b = InlineKeyboardBuilder()
    for key, emoji, name in [
        ("work",     "💼", "Работа"),
        ("mine",     "⛏️", "Майнинг"),
        ("casino",   "🎲", "Казино"),
        ("slots",    "🎰", "Слоты"),
        ("transfer", "💸", "Переводы"),
        ("daily",    "🎁", "Дейли"),
        ("lucky",    "🍀", "Лаки блок"),
        ("business", "🏢", "Бизнесы"),
    ]:
        active = r.get(key, False)
        b.button(
            text=f"{'🔴' if active else '🟢'} {name}",
            callback_data=f"restr:toggle:{uid}:{key}"
        )
    b.button(text="◀️ Назад к игроку", callback_data=f"player:{uid}")
    b.adjust(2, 2, 2, 2, 1)
    return b


def main_menu_kb() -> InlineKeyboardBuilder:
    b = InlineKeyboardBuilder()
    b.button(text="🔍 Найти игрока", callback_data="action:search")
    b.button(text="💰 Цены бизнесов", callback_data="prices:biz:0")
    b.button(text="🛒 Цены магазина", callback_data="prices:shop:0")
    b.button(text="⚙️ Настройки игры", callback_data="prices:game")
    b.button(text="📢 Рассылка", callback_data="action:broadcast")
    b.adjust(1)
    return b

# ─── handlers ────────────────────────────────────────────────────────────────

router_main = __import__("aiogram").Router()


@router_main.message(CommandStart())
@router_main.message(Command("menu"))
@router_main.message(F.text.lower() == "меню")
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа. Этот бот только для администраторов.")
        return
    await message.answer(
        "👑 <b>АДМИН-БОТ</b>\n\nВыберите действие:",
        parse_mode="HTML",
        reply_markup=main_menu_kb().as_markup()
    )


@router_main.callback_query(F.data == "main_menu")
async def back_menu(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return
    await callback.message.edit_text(
        "👑 <b>АДМИН-БОТ</b>\n\nВыберите действие:",
        parse_mode="HTML",
        reply_markup=main_menu_kb().as_markup()
    )
    await callback.answer()


# ─── Поиск игрока ────────────────────────────────────────────────────────────

@router_main.callback_query(F.data == "action:search")
async def start_search(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminState.search)
    await callback.message.edit_text(
        "🔍 <b>Поиск игрока</b>\n\n"
        "Отправь:\n"
        "• Telegram ID (число)\n"
        "• @username\n"
        "• Часть имени",
        parse_mode="HTML"
    )
    await callback.answer()


@router_main.message(AdminState.search)
async def do_search(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    query = message.text.strip().lstrip("@")
    await state.clear()

    async with get_db() as session:
        # По ID
        if query.lstrip("-").isdigit():
            user = await UserService.get_by_telegram_id(session, int(query))
            if user:
                await message.answer(
                    user_info_text(user),
                    parse_mode="HTML",
                    reply_markup=player_kb(user).as_markup()
                )
                return

        # По username или имени — перебираем всех
        all_users = await UserService.get_all_users(session)
        found = [
            u for u in all_users
            if (u.username and query.lower() in u.username.lower())
            or (u.first_name and query.lower() in u.first_name.lower())
        ]

        if not found:
            b = InlineKeyboardBuilder()
            b.button(text="🔍 Снова", callback_data="action:search")
            b.button(text="◀️ Меню", callback_data="main_menu")
            b.adjust(2)
            await message.answer("❌ Игрок не найден.", reply_markup=b.as_markup())
            return

        if len(found) == 1:
            user = found[0]
            await message.answer(
                user_info_text(user),
                parse_mode="HTML",
                reply_markup=player_kb(user).as_markup()
            )
            return

        # Несколько — показываем список
        b = InlineKeyboardBuilder()
        for u in found[:10]:
            name = u.first_name or u.username or str(u.telegram_id)
            b.button(text=f"{name} ({u.telegram_id})", callback_data=f"player:{u.telegram_id}")
        b.button(text="◀️ Меню", callback_data="main_menu")
        b.adjust(1)
        await message.answer(f"Найдено {len(found)} игроков:", reply_markup=b.as_markup())


@router_main.callback_query(F.data.startswith("player:"))
async def show_player(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[1])
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        if not user:
            await callback.answer("❌ Не найден", show_alert=True)
            return
        await callback.message.edit_text(
            user_info_text(user),
            parse_mode="HTML",
            reply_markup=player_kb(user).as_markup()
        )
    await callback.answer()


# ─── Редактирование полей ─────────────────────────────────────────────────────

EDIT_PROMPTS = {
    "balance": ("💰 Новый баланс (число):", float),
    "level":   ("⭐ Новый уровень (1-9999):", int),
    "exp":     ("📊 Новый опыт (0-99999):", int),
    "psych":   ("🧠 Добавить отметок психиатра (число):", int),
}


@router_main.callback_query(F.data.startswith("edit:"))
async def edit_field(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split(":")
    action, uid = parts[1], int(parts[2])

    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        if not user:
            await callback.answer("❌ Не найден", show_alert=True)
            return

        # Немедленные действия
        if action == "ban":
            if user.is_banned:
                user.is_banned = False
                user.ban_reason = None
                msg = "✅ Пользователь разбанен"
            else:
                user.is_banned = True
                user.ban_reason = "Заблокирован администратором"
                msg = "🚫 Пользователь забанен"
                try:
                    await callback.bot.send_message(uid, "🚫 Ваш аккаунт заблокирован администратором.")
                except Exception:
                    pass
            await session.commit()
            await session.refresh(user)
            await callback.message.edit_text(
                user_info_text(user), parse_mode="HTML",
                reply_markup=player_kb(user).as_markup()
            )
            await callback.answer(msg)
            return

        if action == "vip":
            from sqlalchemy.orm.attributes import flag_modified
            if user.vip_until and datetime.utcnow() < user.vip_until:
                user.vip_until = None
                msg = "❌ VIP снят"
            else:
                user.vip_until = datetime.utcnow() + timedelta(days=30)
                msg = "👑 VIP выдан на 30 дней"
                try:
                    await callback.bot.send_message(uid, "👑 Вам выдан VIP на 30 дней!")
                except Exception:
                    pass
            await session.commit()
            await session.refresh(user)
            await callback.message.edit_text(
                user_info_text(user), parse_mode="HTML",
                reply_markup=player_kb(user).as_markup()
            )
            await callback.answer(msg)
            return

        if action == "reset":
            from sqlalchemy.orm.attributes import flag_modified
            user.balance = 100.0
            user.experience = 0
            user.level = 1
            user.businesses = {}
            user.inventory = {}
            user.statistics = {}
            user.vip_until = None
            user.last_work = user.last_mine = user.last_daily = None
            user.last_casino = user.last_slots = user.last_psychiatrist = None
            user.last_lucky_block = None
            flag_modified(user, "businesses")
            flag_modified(user, "inventory")
            flag_modified(user, "statistics")
            await session.commit()
            await session.refresh(user)
            await callback.message.edit_text(
                user_info_text(user), parse_mode="HTML",
                reply_markup=player_kb(user).as_markup()
            )
            await callback.answer("🗑 Прогресс сброшен")
            return

    # Поля с вводом значения
    if action in EDIT_PROMPTS:
        prompt, _ = EDIT_PROMPTS[action]
        await state.set_state(AdminState.edit_field)
        await state.update_data(field=action, uid=uid)
        b = InlineKeyboardBuilder()
        b.button(text="❌ Отмена", callback_data=f"player:{uid}")
        await callback.message.edit_text(
            f"{prompt}\n\nТекущий игрок: {uid}",
            reply_markup=b.as_markup()
        )
    await callback.answer()


@router_main.message(AdminState.edit_field)
async def apply_edit(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    field = data["field"]
    uid = data["uid"]
    await state.clear()

    _, cast = EDIT_PROMPTS[field]
    try:
        value = cast(message.text.strip())
    except ValueError:
        await message.answer("❌ Неверное значение. Отправь число.")
        return

    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, uid)
        if not user:
            await message.answer("❌ Игрок не найден")
            return

        if field == "balance":
            old = user.balance
            user.balance = value
            note = f"💰 Баланс: {format_balance(old)} → {format_balance(value)}"
        elif field == "level":
            old = user.level
            user.level = max(1, min(9999, int(value)))
            note = f"⭐ Уровень: {old} → {user.level}"
        elif field == "exp":
            old = user.experience
            user.experience = max(0, int(value))
            note = f"📊 Опыт: {old} → {user.experience}"
        elif field == "psych":
            if user.statistics is None:
                user.statistics = {}
            old = user.statistics.get("psychiatrist_marks", 0)
            user.statistics["psychiatrist_marks"] = old + int(value)
            flag_modified(user, "statistics")
            note = f"🧠 Психиатр: {old} → {user.statistics['psychiatrist_marks']}"

        await session.commit()
        await session.refresh(user)

        await message.answer(
            f"✅ {note}\n\n" + user_info_text(user),
            parse_mode="HTML",
            reply_markup=player_kb(user).as_markup()
        )


# ─── Ограничения ─────────────────────────────────────────────────────────────

@router_main.callback_query(F.data.startswith("restr:menu:"))
async def restr_menu(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    uid = int(callback.data.split(":")[2])
    async with get_db() as session:
        user = await UserService.get_by_telegram_id(session, uid)
        if not user:
            await callback.answer("❌", show_alert=True)
            return
        r = (user.statistics or {}).get("restrictions", {})
        active = [k for k, v in r.items() if v]
        text = (
            f"⛔ <b>Ограничения</b> — {user.first_name or uid}\n\n"
            f"🔴 Выкл  🟢 Вкл\n\n"
            f"Активных ограничений: {len(active)}"
        )
        await callback.message.edit_text(
            text, parse_mode="HTML", reply_markup=restr_kb(user).as_markup()
        )
    await callback.answer()


@router_main.callback_query(F.data.startswith("restr:toggle:"))
async def restr_toggle(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    _, _, uid_str, key = callback.data.split(":")
    uid = int(uid_str)
    async with get_db() as session:
        from sqlalchemy.orm.attributes import flag_modified
        user = await UserService.get_by_telegram_id(session, uid)
        if not user:
            await callback.answer("❌", show_alert=True)
            return
        if user.statistics is None:
            user.statistics = {}
        if "restrictions" not in user.statistics:
            user.statistics["restrictions"] = {}
        current = user.statistics["restrictions"].get(key, False)
        user.statistics["restrictions"][key] = not current
        flag_modified(user, "statistics")
        await session.commit()
        await session.refresh(user)

        status = "🔴 включено" if not current else "🟢 снято"
        await callback.answer(f"Ограничение '{key}' {status}")
        await callback.message.edit_reply_markup(reply_markup=restr_kb(user).as_markup())


# ─── Цены бизнесов ────────────────────────────────────────────────────────────

@router_main.callback_query(F.data.startswith("prices:biz:"))
async def prices_biz(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    page = int(callback.data.split(":")[2])
    biz_list = list(BUSINESSES.items())
    PAGE = 5
    total_p = max(1, (len(biz_list) + PAGE - 1) // PAGE)
    page = max(0, min(page, total_p - 1))
    chunk = biz_list[page * PAGE: (page + 1) * PAGE]

    text = f"💰 <b>ЦЕНЫ БИЗНЕСОВ</b>  (стр. {page+1}/{total_p})\n\n"
    for bid, biz in chunk:
        cur = get_business(bid)
        text += (
            f"{biz['name']}\n"
            f"  Покупка: {format_balance(cur['base_cost'])}  "
            f"Доход: {format_balance(cur['base_income'])}/ч\n\n"
        )

    b = InlineKeyboardBuilder()
    for bid, biz in chunk:
        b.button(text=f"✏️ {biz['name']}", callback_data=f"pbiz:{bid}:{page}")
    b.adjust(1)
    nav = []
    if page > 0:
        nav.append(("◀️", f"prices:biz:{page-1}"))
    if page < total_p - 1:
        nav.append(("▶️", f"prices:biz:{page+1}"))
    for label, cb in nav:
        b.button(text=label, callback_data=cb)
    if nav:
        b.adjust(*([1]*len(chunk)), len(nav))
    b.button(text="◀️ Меню", callback_data="main_menu")
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=b.as_markup())
    await callback.answer()


@router_main.callback_query(F.data.startswith("pbiz:"))
async def edit_biz_price(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split(":")
    bid = parts[1]
    back_page = int(parts[2])
    biz = BUSINESSES.get(bid)
    if not biz:
        await callback.answer("❌", show_alert=True)
        return

    cur = get_business(bid)
    await state.set_state(AdminState.edit_price)
    await state.update_data(target="biz", bid=bid, back_page=back_page)

    b = InlineKeyboardBuilder()
    b.button(text="❌ Отмена", callback_data=f"prices:biz:{back_page}")
    await callback.message.edit_text(
        f"✏️ <b>{biz['name']}</b>\n\n"
        f"Текущая цена: {format_balance(cur['base_cost'])}\n"
        f"Текущий доход: {format_balance(cur['base_income'])}/ч\n\n"
        f"Отправь в формате:\n"
        f"<code>цена доход</code>\n"
        f"Например: <code>5000 300</code>",
        parse_mode="HTML", reply_markup=b.as_markup()
    )
    await callback.answer()


# ─── Цены магазина ────────────────────────────────────────────────────────────

@router_main.callback_query(F.data.startswith("prices:shop:"))
async def prices_shop(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    page = int(callback.data.split(":")[2])
    item_list = list(SHOP_ITEMS.items())
    PAGE = 5
    total_p = max(1, (len(item_list) + PAGE - 1) // PAGE)
    page = max(0, min(page, total_p - 1))
    chunk = item_list[page * PAGE: (page + 1) * PAGE]

    text = f"🛒 <b>ЦЕНЫ МАГАЗИНА</b>  (стр. {page+1}/{total_p})\n\n"
    for iid, item in chunk:
        cur = get_shop_item(iid)
        text += f"{item['name']}\n  Цена: {format_balance(cur['price'])}\n\n"

    b = InlineKeyboardBuilder()
    for iid, item in chunk:
        b.button(text=f"✏️ {item['name']}", callback_data=f"pshop:{iid}:{page}")
    b.adjust(1)
    nav = []
    if page > 0:
        nav.append(("◀️", f"prices:shop:{page-1}"))
    if page < total_p - 1:
        nav.append(("▶️", f"prices:shop:{page+1}"))
    for label, cb in nav:
        b.button(text=label, callback_data=cb)
    if nav:
        b.adjust(*([1]*len(chunk)), len(nav))
    b.button(text="◀️ Меню", callback_data="main_menu")
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=b.as_markup())
    await callback.answer()


@router_main.callback_query(F.data.startswith("pshop:"))
async def edit_shop_price(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split(":")
    iid = parts[1]
    back_page = int(parts[2])
    item = SHOP_ITEMS.get(iid)
    if not item:
        await callback.answer("❌", show_alert=True)
        return

    cur = get_shop_item(iid)
    await state.set_state(AdminState.edit_price)
    await state.update_data(target="shop", iid=iid, back_page=back_page)

    b = InlineKeyboardBuilder()
    b.button(text="❌ Отмена", callback_data=f"prices:shop:{back_page}")
    await callback.message.edit_text(
        f"✏️ <b>{item['name']}</b>\n\n"
        f"Текущая цена: {format_balance(cur['price'])}\n\n"
        f"Отправь новую цену (число):",
        parse_mode="HTML", reply_markup=b.as_markup()
    )
    await callback.answer()


# ─── Настройки игры ───────────────────────────────────────────────────────────

@router_main.callback_query(F.data == "prices:game")
async def prices_game(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    lines = []
    labels = {
        "work_min": "💼 Работа мин",
        "work_max": "💼 Работа макс",
        "mine_min": "⛏️ Майнинг мин",
        "mine_max": "⛏️ Майнинг макс",
        "daily_min": "🎁 Дейли мин",
        "daily_max": "🎁 Дейли макс",
    }
    for key, label in labels.items():
        val = get_game_setting(key)
        lines.append(f"{label}: <b>{val}</b>")

    b = InlineKeyboardBuilder()
    for key, label in labels.items():
        b.button(text=f"✏️ {label}", callback_data=f"pgame:{key}")
    b.adjust(1)
    b.button(text="◀️ Меню", callback_data="main_menu")
    await callback.message.edit_text(
        "⚙️ <b>НАСТРОЙКИ ИГРЫ</b>\n\n" + "\n".join(lines),
        parse_mode="HTML", reply_markup=b.as_markup()
    )
    await callback.answer()


@router_main.callback_query(F.data.startswith("pgame:"))
async def edit_game_setting(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    key = callback.data.split(":")[1]
    cur = get_game_setting(key)
    await state.set_state(AdminState.edit_price)
    await state.update_data(target="game", gkey=key)
    b = InlineKeyboardBuilder()
    b.button(text="❌ Отмена", callback_data="prices:game")
    await callback.message.edit_text(
        f"✏️ <b>{key}</b>\nТекущее значение: {cur}\n\nОтправь новое число:",
        parse_mode="HTML", reply_markup=b.as_markup()
    )
    await callback.answer()


# ─── Обработчик ввода новых цен ──────────────────────────────────────────────

@router_main.message(AdminState.edit_price)
async def apply_price(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    target = data["target"]
    text = message.text.strip()

    if target == "biz":
        bid = data["bid"]
        back_page = data.get("back_page", 0)
        await state.clear()
        parts = text.split()
        try:
            cost = int(parts[0].replace(",", ""))
            income = int(parts[1].replace(",", "")) if len(parts) > 1 else None
        except (ValueError, IndexError):
            await message.answer("❌ Неверный формат. Пример: <code>5000 300</code>", parse_mode="HTML")
            return
        set_business_price(bid, "base_cost", cost)
        if income is not None:
            set_business_price(bid, "base_income", income)
        biz = BUSINESSES[bid]
        b = InlineKeyboardBuilder()
        b.button(text="💰 Цены бизнесов", callback_data=f"prices:biz:{back_page}")
        b.button(text="◀️ Меню", callback_data="main_menu")
        b.adjust(2)
        await message.answer(
            f"✅ <b>{biz['name']}</b>\n"
            f"Новая цена: {format_balance(cost)}"
            + (f"\nНовый доход: {format_balance(income)}/ч" if income else ""),
            parse_mode="HTML", reply_markup=b.as_markup()
        )

    elif target == "shop":
        iid = data["iid"]
        back_page = data.get("back_page", 0)
        await state.clear()
        try:
            price = int(text.replace(",", ""))
        except ValueError:
            await message.answer("❌ Введи целое число")
            return
        set_shop_price(iid, price)
        item = SHOP_ITEMS[iid]
        b = InlineKeyboardBuilder()
        b.button(text="🛒 Цены магазина", callback_data=f"prices:shop:{back_page}")
        b.button(text="◀️ Меню", callback_data="main_menu")
        b.adjust(2)
        await message.answer(
            f"✅ <b>{item['name']}</b>\nНовая цена: {format_balance(price)}",
            parse_mode="HTML", reply_markup=b.as_markup()
        )

    elif target == "game":
        gkey = data["gkey"]
        await state.clear()
        try:
            val = int(text.replace(",", ""))
        except ValueError:
            await message.answer("❌ Введи целое число")
            return
        set_game_setting(gkey, val)
        b = InlineKeyboardBuilder()
        b.button(text="⚙️ Настройки игры", callback_data="prices:game")
        b.button(text="◀️ Меню", callback_data="main_menu")
        b.adjust(2)
        await message.answer(
            f"✅ <b>{gkey}</b> = {val}",
            parse_mode="HTML", reply_markup=b.as_markup()
        )


# ─── Рассылка ─────────────────────────────────────────────────────────────────

@router_main.callback_query(F.data == "action:broadcast")
async def start_broadcast(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminState.broadcast)
    b = InlineKeyboardBuilder()
    b.button(text="❌ Отмена", callback_data="main_menu")
    await callback.message.edit_text(
        "📢 <b>Рассылка</b>\n\nОтправь текст сообщения (HTML поддерживается):",
        parse_mode="HTML", reply_markup=b.as_markup()
    )
    await callback.answer()


@router_main.message(AdminState.broadcast)
async def do_broadcast(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.clear()
    text = message.text
    await message.answer("⏳ Отправляю рассылку...")

    ok = 0
    fail = 0
    async with get_db() as session:
        users = await UserService.get_all_users(session)
    for user in users:
        try:
            await message.bot.send_message(user.telegram_id, f"📢 {text}", parse_mode="HTML")
            ok += 1
        except Exception:
            fail += 1

    b = InlineKeyboardBuilder()
    b.button(text="◀️ Меню", callback_data="main_menu")
    await message.answer(
        f"✅ Рассылка завершена\n✉️ Успешно: {ok}\n❌ Ошибок: {fail}",
        reply_markup=b.as_markup()
    )


# ─── Запуск ───────────────────────────────────────────────────────────────────

async def main():
    token = settings.ADMIN_BOT_TOKEN
    if not token:
        logger.error("ADMIN_BOT_TOKEN не задан в .env! Добавь ADMIN_BOT_TOKEN=...")
        return

    bot = Bot(token=token)
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router_main)

    logger.info("Admin bot starting...")
    try:
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        await bot.session.close()


if __name__ == "__main__":
    logger.remove()
    logger.add(sys.stdout, level="INFO")
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
